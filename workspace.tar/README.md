# Unified Engineering Workbench

**PASS SCIENCE WORKS R&D Internship 2026–2027 — Assessment Project**

## Overview

A modular engineering workbench combining:
- **Module B**: CAD/ANSYS data visualization (STL mesh + CSV point cloud)
- **Module C**: 1D steady-state thermal finite element analysis
- **Module D**: Multicore performance benchmarking with `std::thread`
- **Module E**: Simulated embedded hardware integration (MCU, FPGA, JTAG)
- **Module F**: Handwritten backpropagation with gradient verification

## Technology Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + Vite + TypeScript + Tailwind CSS |
| 3D Visualization | Three.js (WebGL) |
| Charts | Recharts |
| Backend | **C++17** (GCC/MinGW-w64 or MSVC) |
| Build System | CMake 3.20+ |
| Concurrency | `std::thread` (C++ standard library) |
| Testing | Custom test framework (no external deps) |

## Project Structure

```
UnifiedEngineeringWorkbench/
├── CMakeLists.txt              # Top-level CMake configuration
├── backend/
│   ├── include/                # C++ headers
│   │   ├── thermal_solver.hpp
│   │   ├── backprop.hpp
│   │   ├── stl_parser.hpp
│   │   ├── csv_parser.hpp
│   │   ├── benchmark.hpp
│   │   └── device_adapter.hpp
│   ├── src/
│   │   ├── main.cpp            # Backend entry point (JSON protocol)
│   │   ├── thermal/thermal_solver.cpp
│   │   ├── neural_network/backprop.cpp
│   │   ├── geometry/stl_parser.cpp
│   │   ├── geometry/csv_parser.cpp
│   │   ├── performance/benchmark.cpp
│   │   └── hardware/device_adapter.cpp
│   └── tests/                  # Unit tests
│       ├── test_thermal.cpp
│       ├── test_backprop.cpp
│       ├── test_parsers.cpp
│       ├── test_hardware.cpp
│       └── test_benchmark.cpp
├── src/                        # React frontend
│   ├── App.tsx
│   ├── pages/
│   └── services/               # TypeScript mirrors of C++ algorithms
├── docs/
│   ├── technical_report.md
│   ├── backprop_appendix.md
│   └── ai_use_log.md
├── data/                       # Sample input files
├── results/                    # Output CSV & plots
├── scripts/                    # Build & packaging scripts
├── .vscode/                    # VS Code configuration
├── README.md
└── .gitignore
```

## Quick Start

### Prerequisites

- **Node.js 18+** (for frontend development)
- **CMake 3.20+** (for C++ backend)
- **C++17 compiler**: MinGW-w64 (Windows) or GCC (Linux/macOS) or MSVC (Windows)

### Frontend (Browser Prototype)

```bash
npm install
npm run dev        # Development server
npm run build      # Production build → dist/
```

### C++ Backend (Source Build)

```bash
# Configure (MinGW on Windows)
cmake -B build -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release

# Or MSVC on Windows
cmake -B build -G "Visual Studio 17 2022" -A x64

# Or GCC on Linux
cmake -B build -DCMAKE_BUILD_TYPE=Release

# Build
cmake --build build --config Release

# Run tests
cd build && ctest --output-on-failure

# Run backend
./build/workbench_backend --help
```

### Standalone Launcher (Windows)

After packaging, run `Launch.exe` from the extracted ZIP. No terminal, admin, or installation required.

## Testing

All tests use a minimal assertion framework (no external dependencies):

```bash
cd build
ctest --output-on-failure
```

Tests cover:
- Thermal FEA: BCs, convergence, midpoint error, custom params
- Backpropagation: forward pass, gradient verification (ε=1e-6), training
- Parsers: valid/invalid STL, valid/invalid CSV, empty files, non-finite values
- Hardware: discovery, connect/disconnect, telemetry, JTAG classification
- Benchmark: determinism, serial/parallel agreement (< 1e-8 °C)

## Modules

### Module B — Geometry Visualization
- ASCII STL parser with validation (max 50 MB)
- CSV parser for `node_id,x_m,y_m,z_m,temperature_C` schema
- Three.js 3D viewer with rotation, zoom, pan
- Temperature-colored point cloud with legend

### Module C — Thermal FEA
- Governing equation: `-d/dx(kA dT/dx) = qA`
- Two-node linear elements, Galerkin assembly
- Thomas algorithm (O(n)) tridiagonal solver
- Penalty method for Dirichlet BCs
- Convergence study: N = 10, 20, 40, 80
- Midpoint error calculation via FE interpolation
- Analytical comparison: `T(x) = T₀ + (T_L-T₀)x/L + qx(L-x)/(2k)`

### Module D — Performance Benchmark
- **Actual `std::thread` parallelism** (not simulated)
- Fixed random seed (42) for reproducibility
- Configurable case count and mesh size
- 5 repetitions, median timing
- Speedup = T₁/Tₚ, Efficiency = Speedup/p
- Serial/parallel agreement verified < 1e-8 °C

### Module E — Hardware Integration
- **Simulated** adapters for MCU, FPGA, JTAG
- Device discovery, connect/disconnect, telemetry
- Block diagram with voltage domains and level shifting
- JTAG clearly labeled as debug interface (not compute board)

### Module F — Backpropagation
- Network: `h = tanh(wx+b)`, `ŷ = vh+c`, `J = ½(ŷ-y)²`
- All four chain-rule derivatives hand-derived
- Simultaneous gradient descent update
- Central finite-difference verification (ε=1e-6, tolerance ≤ 1e-5)
- 100-step training with loss convergence plot

## License

Educational assessment project. All code original except third-party libraries listed in package.json.
