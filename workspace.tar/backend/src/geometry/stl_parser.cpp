// stl_parser.cpp — ASCII STL parser implementation
#include "stl_parser.hpp"
#include <fstream>
#include <sstream>
#include <cmath>
#include <limits>
#include <algorithm>

namespace workbench {

STLData parse_stl(const std::string& content) {
    STLData data;

    if (content.empty()) {
        data.error = "File is empty";
        return data;
    }

    // Check size limit (50 MB)
    if (content.size() > 50 * 1024 * 1024) {
        data.error = "File exceeds 50 MB limit";
        return data;
    }

    std::istringstream iss(content);
    std::string line;

    // Parse "solid name"
    if (!std::getline(iss, line)) {
        data.error = "Invalid STL: no solid header";
        return data;
    }

    // Extract name
    if (line.find("solid") == 0 || line.find("SOLID") == 0 || line.find("Solid") == 0) {
        std::size_t pos = line.find_first_of(" \t");
        if (pos != std::string::npos) {
            data.name = line.substr(pos + 1);
            // Trim whitespace
            while (!data.name.empty() && std::isspace(data.name.back()))
                data.name.pop_back();
        }
    }

    // Initialize bounds
    data.min_bound = { std::numeric_limits<double>::max(),
                       std::numeric_limits<double>::max(),
                       std::numeric_limits<double>::max() };
    data.max_bound = { std::numeric_limits<double>::lowest(),
                       std::numeric_limits<double>::lowest(),
                       std::numeric_limits<double>::lowest() };

    // Parse facets
    Triangle current_tri;
    int vertex_count = 0;
    bool in_facet = false;

    while (std::getline(iss, line)) {
        // Trim leading whitespace
        std::size_t start = line.find_first_not_of(" \t\r\n");
        if (start == std::string::npos) continue;
        line = line.substr(start);

        std::istringstream lss(line);
        std::string keyword;
        lss >> keyword;

        if (keyword == "facet") {
            std::string normal_kw;
            lss >> normal_kw;
            if (normal_kw == "normal") {
                lss >> current_tri.normal[0] >> current_tri.normal[1] >> current_tri.normal[2];
                // Validate finite
                for (int i = 0; i < 3; ++i) {
                    if (!std::isfinite(current_tri.normal[i])) {
                        current_tri.normal[i] = 0.0; // Skip invalid normals
                    }
                }
            }
            in_facet = true;
            vertex_count = 0;
        }
        else if (keyword == "vertex" && in_facet) {
            if (vertex_count < 3) {
                lss >> current_tri.vertices[vertex_count][0]
                    >> current_tri.vertices[vertex_count][1]
                    >> current_tri.vertices[vertex_count][2];

                // Validate finite
                bool valid = true;
                for (int i = 0; i < 3; ++i) {
                    if (!std::isfinite(current_tri.vertices[vertex_count][i])) {
                        valid = false;
                        break;
                    }
                    // Update bounds
                    data.min_bound[i] = std::min(data.min_bound[i], current_tri.vertices[vertex_count][i]);
                    data.max_bound[i] = std::max(data.max_bound[i], current_tri.vertices[vertex_count][i]);
                }

                if (valid) {
                    ++vertex_count;
                }
            }
        }
        else if (keyword == "endfacet") {
            if (vertex_count == 3) {
                data.triangles.push_back(current_tri);
            }
            in_facet = false;
            vertex_count = 0;
        }
        else if (keyword == "endsolid") {
            break;
        }
    }

    if (data.triangles.empty()) {
        data.error = "No valid triangles found";
        return data;
    }

    data.is_valid = true;
    return data;
}

STLData parse_stl_file(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) {
        STLData data;
        data.error = "Cannot open file: " + path;
        return data;
    }

    std::ostringstream oss;
    oss << file.rdbuf();
    return parse_stl(oss.str());
}

} // namespace workbench
