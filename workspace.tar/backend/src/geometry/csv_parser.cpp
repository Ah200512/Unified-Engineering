// csv_parser.cpp — CSV temperature file parser implementation
#include "csv_parser.hpp"
#include <fstream>
#include <sstream>
#include <cmath>
#include <limits>
#include <algorithm>
#include <map>

namespace workbench {

static std::vector<std::string> split_csv_line(const std::string& line) {
    std::vector<std::string> fields;
    std::string field;
    for (char c : line) {
        if (c == ',') {
            fields.push_back(field);
            field.clear();
        } else {
            field += c;
        }
    }
    fields.push_back(field);
    return fields;
}

static std::string to_lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(),
                   [](unsigned char c) { return std::tolower(c); });
    return s;
}

static std::string trim(const std::string& s) {
    auto start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    auto end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

CSVData parse_temperature_csv(const std::string& content) {
    CSVData data;

    if (content.empty()) {
        data.error = "File is empty";
        return data;
    }

    std::istringstream iss(content);
    std::string line;

    // Read header
    if (!std::getline(iss, line)) {
        data.error = "No header line";
        return data;
    }

    line = trim(line);
    auto header_fields = split_csv_line(line);

    // Map column names to indices
    std::map<std::string, int> col_map;
    for (std::size_t i = 0; i < header_fields.size(); ++i) {
        col_map[to_lower(trim(header_fields[i]))] = static_cast<int>(i);
    }

    // Check required columns
    const std::vector<std::string> required = {
        "node_id", "x_m", "y_m", "z_m", "temperature_c"
    };
    for (const auto& col : required) {
        if (col_map.find(col) == col_map.end()) {
            data.error = "Missing required column: " + col;
            return data;
        }
    }

    const int idx_id = col_map["node_id"];
    const int idx_x = col_map["x_m"];
    const int idx_y = col_map["y_m"];
    const int idx_z = col_map["z_m"];
    const int idx_t = col_map["temperature_c"];

    // Initialize bounds
    data.min_temp = std::numeric_limits<double>::max();
    data.max_temp = std::numeric_limits<double>::lowest();
    data.min_bound = { std::numeric_limits<double>::max(),
                       std::numeric_limits<double>::max(),
                       std::numeric_limits<double>::max() };
    data.max_bound = { std::numeric_limits<double>::lowest(),
                       std::numeric_limits<double>::lowest(),
                       std::numeric_limits<double>::lowest() };

    int line_num = 1;
    int skipped = 0;

    while (std::getline(iss, line)) {
        ++line_num;
        line = trim(line);
        if (line.empty()) continue;

        auto fields = split_csv_line(line);
        const int min_cols = std::max({idx_id, idx_x, idx_y, idx_z, idx_t}) + 1;

        if (static_cast<int>(fields.size()) < min_cols) {
            data.warnings.push_back("Row " + std::to_string(line_num) + ": insufficient columns, skipped");
            ++skipped;
            continue;
        }

        try {
            TemperatureNode node;
            node.node_id = std::stoi(trim(fields[idx_id]));
            node.x = std::stod(trim(fields[idx_x]));
            node.y = std::stod(trim(fields[idx_y]));
            node.z = std::stod(trim(fields[idx_z]));
            node.temperature = std::stod(trim(fields[idx_t]));

            // Validate finite
            if (!std::isfinite(node.x) || !std::isfinite(node.y) ||
                !std::isfinite(node.z) || !std::isfinite(node.temperature)) {
                data.warnings.push_back("Row " + std::to_string(line_num) + ": non-finite values, skipped");
                ++skipped;
                continue;
            }

            data.nodes.push_back(node);

            // Update stats
            data.min_temp = std::min(data.min_temp, node.temperature);
            data.max_temp = std::max(data.max_temp, node.temperature);
            data.min_bound[0] = std::min(data.min_bound[0], node.x);
            data.min_bound[1] = std::min(data.min_bound[1], node.y);
            data.min_bound[2] = std::min(data.min_bound[2], node.z);
            data.max_bound[0] = std::max(data.max_bound[0], node.x);
            data.max_bound[1] = std::max(data.max_bound[1], node.y);
            data.max_bound[2] = std::max(data.max_bound[2], node.z);
        }
        catch (const std::exception&) {
            data.warnings.push_back("Row " + std::to_string(line_num) + ": parse error, skipped");
            ++skipped;
        }
    }

    if (skipped > 0) {
        data.warnings.push_back(std::to_string(skipped) + " rows skipped total");
    }

    if (data.nodes.empty()) {
        data.error = "No valid data rows found";
        return data;
    }

    data.is_valid = true;
    return data;
}

CSVData parse_temperature_csv_file(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) {
        CSVData data;
        data.error = "Cannot open file: " + path;
        return data;
    }
    std::ostringstream oss;
    oss << file.rdbuf();
    return parse_temperature_csv(oss.str());
}

} // namespace workbench
