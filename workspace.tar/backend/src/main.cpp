// main.cpp — Backend entry point
// Accepts JSON commands on stdin, returns JSON results on stdout
// This allows the React frontend to invoke C++ computations
#include "thermal_solver.hpp"
#include "backprop.hpp"
#include "stl_parser.hpp"
#include "csv_parser.hpp"
#include "benchmark.hpp"
#include "device_adapter.hpp"

#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <cmath>
#include <iomanip>

// Simple JSON helpers (avoid external dependency)
static std::string json_escape(const std::string& s) {
    std::string out;
    for (char c : s) {
        if (c == '"') out += "\\\"";
        else if (c == '\\') out += "\\\\";
        else if (c == '\n') out += "\\n";
        else out += c;
    }
    return out;
}

static void handle_thermal_solve(std::istream& in) {
    workbench::ThermalParams params;
    int N = 40;

    // Read parameters (simple key=value format)
    std::string line;
    while (std::getline(in, line) && line != "END") {
        if (line.find("N=") == 0) N = std::stoi(line.substr(2));
        else if (line.find("L=") == 0) params.L = std::stod(line.substr(2));
        else if (line.find("A=") == 0) params.A = std::stod(line.substr(2));
        else if (line.find("k=") == 0) params.k = std::stod(line.substr(2));
        else if (line.find("q=") == 0) params.q = std::stod(line.substr(2));
        else if (line.find("T_left=") == 0) params.T_left = std::stod(line.substr(7));
        else if (line.find("T_right=") == 0) params.T_right = std::stod(line.substr(8));
    }

    auto result = workbench::solve_thermal(params, N);

    // Output JSON
    std::cout << "{\"type\":\"thermal_result\",\"N\":" << result.N
              << ",\"h\":" << std::scientific << std::setprecision(6) << result.h
              << ",\"max_midpoint_error\":" << result.max_midpoint_error
              << ",\"nodes\":[";
    for (std::size_t i = 0; i < result.nodes.size(); ++i) {
        if (i > 0) std::cout << ",";
        std::cout << result.nodes[i];
    }
    std::cout << "],\"temperatures\":[";
    for (std::size_t i = 0; i < result.temperatures.size(); ++i) {
        if (i > 0) std::cout << ",";
        std::cout << result.temperatures[i];
    }
    std::cout << "],\"exact\":[";
    for (std::size_t i = 0; i < result.exact.size(); ++i) {
        if (i > 0) std::cout << ",";
        std::cout << result.exact[i];
    }
    std::cout << "]}\n" << std::flush;
}

static void handle_backprop_train(std::istream& in) {
    int steps = 100;
    double lr = 0.1;
    std::string line;
    while (std::getline(in, line) && line != "END") {
        if (line.find("steps=") == 0) steps = std::stoi(line.substr(6));
        else if (line.find("lr=") == 0) lr = std::stod(line.substr(3));
    }

    workbench::NetworkParams p0{0.5, 0.0, 1.0, 0.0};
    auto history = workbench::train(1.0, 2.0, p0, lr, steps);

    std::cout << "{\"type\":\"backprop_result\",\"history\":[";
    for (std::size_t i = 0; i < history.size(); ++i) {
        if (i > 0) std::cout << ",";
        const auto& s = history[i];
        std::cout << "{\"step\":" << s.step
                  << ",\"w\":" << std::setprecision(8) << s.params.w
                  << ",\"b\":" << s.params.b
                  << ",\"v\":" << s.params.v
                  << ",\"c\":" << s.params.c
                  << ",\"y_hat\":" << s.y_hat
                  << ",\"loss\":" << s.loss << "}";
    }
    std::cout << "]}\n" << std::flush;
}

static void handle_benchmark(std::istream& in) {
    workbench::BenchmarkConfig cfg;
    std::string line;
    while (std::getline(in, line) && line != "END") {
        if (line.find("cases=") == 0) cfg.case_count = std::stoi(line.substr(6));
        else if (line.find("mesh=") == 0) cfg.mesh_size = std::stoi(line.substr(5));
    }

    std::vector<int> workers = {1, 2, 3, 4};
    unsigned int hw = std::thread::hardware_concurrency();
    if (hw > 0) {
        workers.clear();
        for (unsigned int w = 1; w <= std::min(4u, hw); ++w)
            workers.push_back(static_cast<int>(w));
    }

    auto results = workbench::run_benchmark_suite(cfg, workers);
    double max_diff = workbench::verify_agreement(
        workbench::generate_cases(cfg.case_count, cfg.seed), cfg, 2);

    std::cout << "{\"type\":\"benchmark_result\",\"results\":[";
    for (std::size_t i = 0; i < results.size(); ++i) {
        if (i > 0) std::cout << ",";
        const auto& r = results[i];
        std::cout << "{\"workers\":" << r.workers
                  << ",\"median_ms\":" << std::setprecision(4) << r.median_ms
                  << ",\"speedup\":" << r.speedup
                  << ",\"efficiency\":" << r.efficiency
                  << ",\"times\":[";
        for (std::size_t j = 0; j < r.times_ms.size(); ++j) {
            if (j > 0) std::cout << ",";
            std::cout << r.times_ms[j];
        }
        std::cout << "]}";
    }
    std::cout << "],\"max_diff\":" << std::scientific << std::setprecision(4) << max_diff
              << ",\"system_info\":" << workbench::get_system_info()
              << "}\n" << std::flush;
}

static void handle_gradient_verify() {
    workbench::NetworkParams p{0.5, 0.0, 1.0, 0.0};
    auto checks = workbench::verify_gradients(1.0, 2.0, p, 1e-6);

    const char* names[] = {"dJ_dw", "dJ_db", "dJ_dv", "dJ_dc"};
    std::cout << "{\"type\":\"gradient_verify\",\"results\":[";
    for (int i = 0; i < 4; ++i) {
        if (i > 0) std::cout << ",";
        std::cout << "{\"name\":\"" << names[i] << "\""
                  << ",\"analytical\":" << std::setprecision(10) << checks[i].analytical
                  << ",\"numerical\":" << checks[i].numerical
                  << ",\"error\":" << std::scientific << checks[i].error
                  << ",\"passed\":" << (checks[i].passed ? "true" : "false") << "}";
    }
    std::cout << "]}\n" << std::flush;
}

static void print_help() {
    std::cout << "Unified Engineering Workbench — C++17 Backend\n"
              << "Commands (send on stdin, one per line, end with END):\n"
              << "  THERMAL_SOLVE   — Solve 1D thermal FEA\n"
              << "  BACKPROP_TRAIN  — Train neural network\n"
              << "  BENCHMARK       — Run multicore benchmark\n"
              << "  GRADIENT_VERIFY — Verify backprop gradients\n"
              << "  SYSTEM_INFO     — Print system information\n"
              << "  HELP            — Show this message\n"
              << "  QUIT            — Exit\n";
}

int main(int argc, char* argv[]) {
    if (argc > 1 && std::string(argv[1]) == "--help") {
        print_help();
        return 0;
    }

    std::string command;
    while (std::getline(std::cin, command)) {
        if (command == "QUIT" || command == "quit") break;
        else if (command == "HELP" || command == "help") print_help();
        else if (command == "THERMAL_SOLVE") handle_thermal_solve(std::cin);
        else if (command == "BACKPROP_TRAIN") handle_backprop_train(std::cin);
        else if (command == "BENCHMARK") handle_benchmark(std::cin);
        else if (command == "GRADIENT_VERIFY") handle_gradient_verify();
        else if (command == "SYSTEM_INFO") std::cout << workbench::get_system_info() << std::flush;
        else std::cout << "{\"error\":\"Unknown command: " << json_escape(command) << "\"}\n" << std::flush;
    }

    return 0;
}
