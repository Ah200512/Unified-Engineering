// device_adapter.cpp — Simulated embedded device adapters
// IMPORTANT: All behavior is SIMULATED. No physical hardware is accessed.
#include "device_adapter.hpp"
#include <random>
#include <chrono>
#include <sstream>
#include <iomanip>

namespace workbench {

// ============ MCU Adapter ============
MCUAdapter::MCUAdapter(const std::string& id) {
    info_.id = id;
    info_.name = "STM32F407 Discovery";
    info_.type = DeviceType::MCU;
    info_.status = DeviceStatus::DISCONNECTED;
    info_.capabilities = {
        {"architecture", "ARM Cortex-M4"},
        {"clock_mhz", "168"},
        {"flash_kb", "1024"},
        {"sram_kb", "192"},
        {"voltage", "3.3V"},
        {"peripherals", "GPIO,ADC,SPI,I2C,UART"}
    };
}

DeviceInfo MCUAdapter::discover() { return info_; }

bool MCUAdapter::connect() {
    info_.status = DeviceStatus::CONNECTING;
    // Simulate connection (always succeeds in simulation)
    info_.status = DeviceStatus::CONNECTED;
    info_.error_message.clear();
    return true;
}

void MCUAdapter::disconnect() {
    info_.status = DeviceStatus::DISCONNECTED;
    info_.last_telemetry.clear();
}

std::string MCUAdapter::get_telemetry() {
    if (info_.status != DeviceStatus::CONNECTED) return "Not connected";
    std::mt19937 rng(static_cast<unsigned>(
        std::chrono::steady_clock::now().time_since_epoch().count()));
    std::uniform_real_distribution<double> cpu_dist(30.0, 70.0);
    std::uniform_real_distribution<double> temp_dist(25.0, 40.0);
    std::uniform_int_distribution<int> uptime_dist(0, 3600);

    std::ostringstream oss;
    oss << std::fixed << std::setprecision(1);
    oss << "MCU: CPU=" << cpu_dist(rng) << "%, Temp=" << temp_dist(rng)
        << "C, Uptime=" << uptime_dist(rng) << "s";
    info_.last_telemetry = oss.str();
    return oss.str();
}

DeviceInfo MCUAdapter::get_info() const { return info_; }

// ============ FPGA Adapter ============
FPGAAdapter::FPGAAdapter(const std::string& id) {
    info_.id = id;
    info_.name = "Xilinx Artix-7 (Simulated)";
    info_.type = DeviceType::FPGA;
    info_.status = DeviceStatus::DISCONNECTED;
    info_.capabilities = {
        {"logic_cells", "100000"},
        {"block_ram_kb", "4900"},
        {"clock_mhz", "100"},
        {"core_voltage", "1.0V"},
        {"io_voltage", "3.3V"}
    };
}

DeviceInfo FPGAAdapter::discover() { return info_; }

bool FPGAAdapter::connect() {
    info_.status = DeviceStatus::CONNECTING;
    info_.status = DeviceStatus::CONNECTED;
    info_.error_message.clear();
    return true;
}

void FPGAAdapter::disconnect() {
    info_.status = DeviceStatus::DISCONNECTED;
    info_.last_telemetry.clear();
}

std::string FPGAAdapter::get_telemetry() {
    if (info_.status != DeviceStatus::CONNECTED) return "Not connected";
    std::mt19937 rng(static_cast<unsigned>(
        std::chrono::steady_clock::now().time_since_epoch().count()));
    std::uniform_real_distribution<double> logic_dist(20.0, 80.0);
    std::uniform_real_distribution<double> bram_dist(10.0, 90.0);

    std::ostringstream oss;
    oss << std::fixed << std::setprecision(0);
    oss << "FPGA: Logic=" << logic_dist(rng) << "%, BRAM=" << bram_dist(rng) << "%, CLK=100MHz";
    info_.last_telemetry = oss.str();
    return oss.str();
}

DeviceInfo FPGAAdapter::get_info() const { return info_; }

// ============ JTAG Adapter ============
JTAGAdapter::JTAGAdapter(const std::string& id) {
    info_.id = id;
    info_.name = "SEGGER J-Link EDU";
    info_.type = DeviceType::JTAG;
    info_.status = DeviceStatus::DISCONNECTED;
    info_.capabilities = {
        {"type", "Debug interface (NOT a compute board)"},
        {"protocol", "SWD + JTAG (IEEE 1149.1)"},
        {"signals", "SWCLK,SWDIO,TCK,TMS,TDI,TDO,TRST"},
        {"max_swd_clock_mhz", "50"},
        {"target_voltage", "3.3V"}
    };
}

DeviceInfo JTAGAdapter::discover() { return info_; }

bool JTAGAdapter::connect() {
    info_.status = DeviceStatus::CONNECTING;
    info_.status = DeviceStatus::CONNECTED;
    info_.error_message.clear();
    return true;
}

void JTAGAdapter::disconnect() {
    info_.status = DeviceStatus::DISCONNECTED;
    info_.last_telemetry.clear();
}

std::string JTAGAdapter::get_telemetry() {
    if (info_.status != DeviceStatus::CONNECTED) return "Not connected";
    info_.last_telemetry = "JTAG: Target halted at 0x08001234, SWD clock=4MHz, Flash: 1MB";
    return info_.last_telemetry;
}

DeviceInfo JTAGAdapter::get_info() const { return info_; }

// ============ Device Manager ============
DeviceManager::DeviceManager() {
    adapters_.push_back(std::make_unique<MCUAdapter>());
    adapters_.push_back(std::make_unique<FPGAAdapter>());
    adapters_.push_back(std::make_unique<JTAGAdapter>());
}

void DeviceManager::discover_all() {
    for (auto& adapter : adapters_) {
        adapter->discover();
    }
}

std::vector<DeviceInfo> DeviceManager::get_all_devices() const {
    std::vector<DeviceInfo> devices;
    for (const auto& adapter : adapters_) {
        devices.push_back(adapter->get_info());
    }
    return devices;
}

DeviceAdapter* DeviceManager::get_device(const std::string& id) {
    for (auto& adapter : adapters_) {
        if (adapter->get_info().id == id) return adapter.get();
    }
    return nullptr;
}

} // namespace workbench
