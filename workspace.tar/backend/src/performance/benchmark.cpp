// benchmark.cpp — Multicore performance benchmark with std::thread
#include "benchmark.hpp"
#include "thermal_solver.hpp"
#include <thread>
#include <mutex>
#include <chrono>
#include <algorithm>
#include <random>
#include <cmath>
#include <sstream>
#include <atomic>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#include <sys/sysinfo.h>
#endif

namespace workbench {

std::vector<TestCase> generate_cases(std::size_t count, unsigned int seed) {
    std::mt19937 rng(seed);
    std::uniform_real_distribution<double> dist_k(1.0, 51.0);
    std::uniform_real_distribution<double> dist_q(1000.0, 51000.0);

    std::vector<TestCase> cases;
    cases.reserve(count);
    for (std::size_t i = 0; i < count; ++i) {
        cases.push_back({ dist_k(rng), dist_q(rng) });
    }
    return cases;
}

// Serial execution: solve all cases sequentially
static void run_serial_batch(const std::vector<TestCase>& cases,
                              const BenchmarkConfig& cfg,
                              std::vector<std::vector<double>>& results)
{
    results.resize(cases.size());
    for (std::size_t i = 0; i < cases.size(); ++i) {
        results[i] = solve_thermal_custom(
            cfg.L, cfg.A, cases[i].k, cases[i].q,
            cfg.T_left, cfg.T_right, cfg.mesh_size);
    }
}

// Parallel execution: partition cases across worker threads
static void run_parallel_batch(const std::vector<TestCase>& cases,
                                const BenchmarkConfig& cfg,
                                int workers,
                                std::vector<std::vector<double>>& results)
{
    results.resize(cases.size());
    const std::size_t total = cases.size();
    const std::size_t chunk = (total + workers - 1) / workers;

    std::vector<std::thread> threads;
    threads.reserve(workers);

    for (int w = 0; w < workers; ++w) {
        const std::size_t start = static_cast<std::size_t>(w) * chunk;
        const std::size_t end = std::min(start + chunk, total);

        threads.emplace_back([&, start, end]() {
            for (std::size_t i = start; i < end; ++i) {
                results[i] = solve_thermal_custom(
                    cfg.L, cfg.A, cases[i].k, cases[i].q,
                    cfg.T_left, cfg.T_right, cfg.mesh_size);
            }
        });
    }

    for (auto& t : threads) {
        t.join();
    }
}

BenchmarkResult benchmark_serial(const std::vector<TestCase>& cases,
                                  const BenchmarkConfig& cfg,
                                  int repetitions)
{
    BenchmarkResult result;
    result.workers = 1;
    result.times_ms.resize(repetitions);

    std::vector<std::vector<double>> output;

    for (int r = 0; r < repetitions; ++r) {
        auto t0 = std::chrono::high_resolution_clock::now();
        run_serial_batch(cases, cfg, output);
        auto t1 = std::chrono::high_resolution_clock::now();
        result.times_ms[r] = std::chrono::duration<double, std::milli>(t1 - t0).count();
    }

    // Median
    std::vector<double> sorted = result.times_ms;
    std::sort(sorted.begin(), sorted.end());
    result.median_ms = sorted[sorted.size() / 2];
    result.speedup = 1.0;
    result.efficiency = 1.0;

    return result;
}

BenchmarkResult benchmark_parallel(const std::vector<TestCase>& cases,
                                    const BenchmarkConfig& cfg,
                                    int workers,
                                    int repetitions)
{
    BenchmarkResult result;
    result.workers = workers;
    result.times_ms.resize(repetitions);

    std::vector<std::vector<double>> output;

    for (int r = 0; r < repetitions; ++r) {
        auto t0 = std::chrono::high_resolution_clock::now();
        run_parallel_batch(cases, cfg, workers, output);
        auto t1 = std::chrono::high_resolution_clock::now();
        result.times_ms[r] = std::chrono::duration<double, std::milli>(t1 - t0).count();
    }

    // Median
    std::vector<double> sorted = result.times_ms;
    std::sort(sorted.begin(), sorted.end());
    result.median_ms = sorted[sorted.size() / 2];

    return result;  // speedup/efficiency filled by caller
}

std::vector<BenchmarkResult> run_benchmark_suite(
    const BenchmarkConfig& cfg,
    const std::vector<int>& worker_counts)
{
    const auto cases = generate_cases(cfg.case_count, cfg.seed);

    // Warm-up run (excluded from timing)
    {
        std::vector<std::vector<double>> warmup;
        run_serial_batch(cases, cfg, warmup);
    }

    std::vector<BenchmarkResult> results;

    // Serial baseline
    BenchmarkResult serial = benchmark_serial(cases, cfg, cfg.repetitions);
    results.push_back(serial);

    // Parallel runs
    for (int w : worker_counts) {
        if (w == 1) continue;  // Already have serial
        BenchmarkResult par = benchmark_parallel(cases, cfg, w, cfg.repetitions);
        par.speedup = serial.median_ms / par.median_ms;
        par.efficiency = par.speedup / static_cast<double>(w);
        results.push_back(par);
    }

    return results;
}

double verify_agreement(const std::vector<TestCase>& cases,
                        const BenchmarkConfig& cfg,
                        int workers)
{
    // Use first 5 cases for verification
    std::vector<TestCase> sub(cases.begin(), cases.begin() + std::min<std::size_t>(5, cases.size()));

    std::vector<std::vector<double>> serial_out, parallel_out;
    run_serial_batch(sub, cfg, serial_out);
    run_parallel_batch(sub, cfg, workers, parallel_out);

    double max_diff = 0.0;
    for (std::size_t i = 0; i < sub.size(); ++i) {
        for (std::size_t j = 0; j < serial_out[i].size(); ++j) {
            double diff = std::abs(serial_out[i][j] - parallel_out[i][j]);
            max_diff = std::max(max_diff, diff);
        }
    }
    return max_diff;
}

std::string get_system_info() {
    std::ostringstream oss;
    unsigned int hw_threads = std::thread::hardware_concurrency();

    oss << "{\n";
    oss << "  \"hw_threads\": " << hw_threads << ",\n";
    oss << "  \"compiler\": \"";
#ifdef __GNUC__
    oss << "GCC " << __GNUC__ << "." << __GNUC_MINOR__ << "." << __GNUC_PATCHLEVEL__;
#elif defined(_MSC_VER)
    oss << "MSVC " << _MSC_VER;
#else
    oss << "unknown";
#endif
    oss << "\",\n";
    oss << "  \"cpp_standard\": " << __cplusplus << ",\n";
    oss << "  \"optimization\": \"";
#ifdef NDEBUG
    oss << "Release (-O2)";
#else
    oss << "Debug";
#endif
    oss << "\"\n";
    oss << "}\n";
    return oss.str();
}

} // namespace workbench
