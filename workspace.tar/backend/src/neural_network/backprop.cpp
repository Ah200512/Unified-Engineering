// backprop.cpp — Handwritten backpropagation implementation
// All derivatives derived by hand using chain rule; no autodiff
#include "backprop.hpp"
#include <cmath>
#include <stdexcept>

namespace workbench {

void forward(double x, const NetworkParams& p, double& h, double& y_hat) {
    const double z = p.w * x + p.b;
    h = std::tanh(z);
    y_hat = p.v * h + p.c;
}

double compute_loss(double y_hat, double y) {
    const double diff = y_hat - y;
    return 0.5 * diff * diff;
}

Gradients compute_gradients(double x, double y, const NetworkParams& p,
                            double h, double y_hat)
{
    // Chain rule derivation:
    //   delta_out = dJ/dy_hat = (y_hat - y)
    //   dJ/dv = delta_out * h
    //   dJ/dc = delta_out
    //   dtanh_dz = 1 - h^2  (derivative of tanh at z)
    //   delta_hid = delta_out * v * (1 - h^2)
    //   dJ/dw = delta_hid * x
    //   dJ/db = delta_hid

    const double delta_out = y_hat - y;
    const double dJ_dv = delta_out * h;
    const double dJ_dc = delta_out;

    const double dtanh_dz = 1.0 - h * h;
    const double delta_hid = delta_out * p.v * dtanh_dz;

    const double dJ_dw = delta_hid * x;
    const double dJ_db = delta_hid;

    return { dJ_dw, dJ_db, dJ_dv, dJ_dc };
}

TrainingStep gradient_step(double x, double y, const NetworkParams& p, double lr) {
    double h, y_hat;
    forward(x, p, h, y_hat);
    const double loss = compute_loss(y_hat, y);
    const Gradients g = compute_gradients(x, y, p, h, y_hat);

    // Simultaneous update: all gradients computed from original params
    NetworkParams p_new;
    p_new.w = p.w - lr * g.dJ_dw;
    p_new.b = p.b - lr * g.dJ_db;
    p_new.v = p.v - lr * g.dJ_dv;
    p_new.c = p.c - lr * g.dJ_dc;

    return { 0, p_new, h, y_hat, loss, g };
}

std::vector<TrainingStep> train(double x, double y, NetworkParams p0,
                                double lr, std::size_t num_steps)
{
    std::vector<TrainingStep> history;
    history.reserve(num_steps + 1);

    NetworkParams p = p0;

    // Record initial state
    double h, y_hat;
    forward(x, p, h, y_hat);
    const double loss0 = compute_loss(y_hat, y);
    const Gradients g0 = compute_gradients(x, y, p, h, y_hat);
    history.push_back({ 0, p, h, y_hat, loss0, g0 });

    for (std::size_t i = 1; i <= num_steps; ++i) {
        TrainingStep step = gradient_step(x, y, p, lr);
        step.step = i;
        history.push_back(step);
        p = step.params;
    }

    return history;
}

std::array<GradientCheckResult, 4> verify_gradients(
    double x, double y, const NetworkParams& p, double epsilon)
{
    double h, y_hat;
    forward(x, p, h, y_hat);
    const Gradients analytical = compute_gradients(x, y, p, h, y_hat);

    std::array<GradientCheckResult, 4> results;

    // Helper lambda: compute loss with one parameter perturbed
    auto loss_with = [&](double w, double b, double v, double c) {
        NetworkParams pp{ w, b, v, c };
        double hh, yy;
        forward(x, pp, hh, yy);
        return compute_loss(yy, y);
    };

    // dJ/dw
    {
        const double Jp = loss_with(p.w + epsilon, p.b, p.v, p.c);
        const double Jm = loss_with(p.w - epsilon, p.b, p.v, p.c);
        const double num = (Jp - Jm) / (2.0 * epsilon);
        const double err = std::abs(analytical.dJ_dw - num);
        results[0] = { analytical.dJ_dw, num, err, err <= 1e-5 };
    }

    // dJ/db
    {
        const double Jp = loss_with(p.w, p.b + epsilon, p.v, p.c);
        const double Jm = loss_with(p.w, p.b - epsilon, p.v, p.c);
        const double num = (Jp - Jm) / (2.0 * epsilon);
        const double err = std::abs(analytical.dJ_db - num);
        results[1] = { analytical.dJ_db, num, err, err <= 1e-5 };
    }

    // dJ/dv
    {
        const double Jp = loss_with(p.w, p.b, p.v + epsilon, p.c);
        const double Jm = loss_with(p.w, p.b, p.v - epsilon, p.c);
        const double num = (Jp - Jm) / (2.0 * epsilon);
        const double err = std::abs(analytical.dJ_dv - num);
        results[2] = { analytical.dJ_dv, num, err, err <= 1e-5 };
    }

    // dJ/dc
    {
        const double Jp = loss_with(p.w, p.b, p.v, p.c + epsilon);
        const double Jm = loss_with(p.w, p.b, p.v, p.c - epsilon);
        const double num = (Jp - Jm) / (2.0 * epsilon);
        const double err = std::abs(analytical.dJ_dc - num);
        results[3] = { analytical.dJ_dc, num, err, err <= 1e-5 };
    }

    return results;
}

} // namespace workbench
