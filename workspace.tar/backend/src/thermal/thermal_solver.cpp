// thermal_solver.cpp — 1D steady-state thermal FEA implementation
// Uses two-node linear elements with Thomas algorithm (O(n) tridiagonal solver)
#include "thermal_solver.hpp"
#include <cmath>
#include <sstream>
#include <iomanip>
#include <stdexcept>
#include <algorithm>

namespace workbench {

double analytical_solution(double x, const ThermalParams& p) {
    // T(x) = T_left + (T_right - T_left) * (x/L) + [q/(2k)] * x * (L - x)
    return p.T_left
         + (p.T_right - p.T_left) * (x / p.L)
         + (p.q / (2.0 * p.k)) * x * (p.L - x);
}

// Thomas algorithm for tridiagonal system Ax = d
// a = sub-diagonal (size n, a[0] unused)
// b = main diagonal  (size n)
// c = super-diagonal (size n, c[n-1] unused)
// d = right-hand side (size n), modified in place
// Returns solution x (size n)
static std::vector<double> thomas_solve(
    const std::vector<double>& a,
    std::vector<double> b,
    const std::vector<double>& c,
    std::vector<double> d)
{
    const std::size_t n = b.size();
    if (n == 0) throw std::invalid_argument("Thomas: empty system");

    std::vector<double> c_star(n, 0.0);
    std::vector<double> d_star(n, 0.0);

    // Forward sweep
    if (std::abs(b[0]) < 1e-300)
        throw std::runtime_error("Thomas: zero pivot at row 0");
    c_star[0] = c[0] / b[0];
    d_star[0] = d[0] / b[0];

    for (std::size_t i = 1; i < n; ++i) {
        const double m = b[i] - a[i] * c_star[i - 1];
        if (std::abs(m) < 1e-300)
            throw std::runtime_error("Thomas: zero pivot at row " + std::to_string(i));
        c_star[i] = (i < n - 1) ? c[i] / m : 0.0;
        d_star[i] = (d[i] - a[i] * d_star[i - 1]) / m;
    }

    // Back substitution
    std::vector<double> x(n);
    x[n - 1] = d_star[n - 1];
    for (std::ptrdiff_t i = static_cast<std::ptrdiff_t>(n) - 2; i >= 0; --i) {
        x[i] = d_star[i] - c_star[i] * x[i + 1];
    }
    return x;
}

ThermalResult solve_thermal(const ThermalParams& params, std::size_t N) {
    if (N == 0) throw std::invalid_argument("N must be >= 1");
    if (params.L <= 0 || params.A <= 0 || params.k <= 0)
        throw std::invalid_argument("Parameters L, A, k must be positive");

    ThermalResult result;
    result.N = N;
    result.h = params.L / static_cast<double>(N);
    const double h = result.h;
    const std::size_t nNodes = N + 1;

    // Build tridiagonal system
    // Global stiffness K and load vector F assembled from element contributions
    std::vector<double> sub_diag(nNodes, 0.0);   // lower diagonal
    std::vector<double> main_diag(nNodes, 0.0);  // main diagonal
    std::vector<double> sup_diag(nNodes, 0.0);   // upper diagonal
    std::vector<double> rhs(nNodes, 0.0);

    // Assembly loop: identical structure to any standard FEA code
    for (std::size_t e = 0; e < N; ++e) {
        // Element stiffness coefficient: k*A/h
        const double ke = (params.k * params.A) / h;
        // Element load: q*A*h/2 per node
        const double fe = (params.q * params.A * h) / 2.0;

        const std::size_t i = e;
        const std::size_t j = e + 1;

        // Assemble into global tridiagonal structure
        main_diag[i] += ke;
        if (j > 0 && i < nNodes - 1) sup_diag[i] += -ke;
        if (i > 0) sub_diag[j] += -ke;
        main_diag[j] += ke;

        rhs[i] += fe;
        rhs[j] += fe;
    }

    // Apply Dirichlet BCs via penalty method
    // This preserves the tridiagonal structure (no fill-in)
    const double penalty = 1e20;

    // Left BC: T[0] = T_left
    main_diag[0] = penalty;
    sup_diag[0]  = 0.0;
    rhs[0]       = penalty * params.T_left;

    // Right BC: T[N] = T_right
    main_diag[N] = penalty;
    sub_diag[N]  = 0.0;
    rhs[N]       = penalty * params.T_right;

    // Solve the tridiagonal system
    const std::vector<double> T = thomas_solve(sub_diag, main_diag, sup_diag, rhs);

    // Populate result
    result.nodes.resize(nNodes);
    result.temperatures.resize(nNodes);
    result.exact.resize(nNodes);
    result.errors.resize(nNodes);

    for (std::size_t i = 0; i < nNodes; ++i) {
        const double x = static_cast<double>(i) * h;
        result.nodes[i] = x;
        result.temperatures[i] = T[i];
        result.exact[i] = analytical_solution(x, params);
        result.errors[i] = std::abs(T[i] - result.exact[i]);
    }

    // Compute max error at element midpoints using FE interpolation
    // At midpoint of element e: x_mid = (e + 0.5)*h
    // FE interpolation: T_mid = 0.5*(T[e] + T[e+1])  (linear shape functions at xi=0.5)
    result.max_midpoint_error = 0.0;
    for (std::size_t e = 0; e < N; ++e) {
        const double x_mid = (static_cast<double>(e) + 0.5) * h;
        const double T_fe_mid = 0.5 * (T[e] + T[e + 1]);
        const double T_exact_mid = analytical_solution(x_mid, params);
        const double err = std::abs(T_fe_mid - T_exact_mid);
        if (err > result.max_midpoint_error) {
            result.max_midpoint_error = err;
        }
    }

    return result;
}

std::vector<double> solve_thermal_custom(
    double L, double A, double k, double q,
    double T_left, double T_right, std::size_t N)
{
    ThermalParams p;
    p.L = L; p.A = A; p.k = k; p.q = q;
    p.T_left = T_left; p.T_right = T_right;
    return solve_thermal(p, N).temperatures;
}

std::string export_results_csv(const std::vector<ThermalResult>& results,
                                const ThermalParams& params)
{
    std::ostringstream oss;
    oss << std::scientific << std::setprecision(6);
    oss << "# Thermal FEA Results\n";
    oss << "# L=" << params.L << " m, A=" << params.A
        << " m^2, k=" << params.k << " W/(m K), q=" << params.q << " W/m^3\n";
    oss << "# T(0)=" << params.T_left << " C, T(L)=" << params.T_right << " C\n\n";

    for (const auto& r : results) {
        oss << "# N=" << r.N << " elements, h=" << r.h
            << " m, max_midpoint_error=" << r.max_midpoint_error << " C\n";
        oss << "node_id,x_m,T_FE_C,T_exact_C,error_C\n";
        for (std::size_t i = 0; i < r.nodes.size(); ++i) {
            oss << i << "," << r.nodes[i] << "," << r.temperatures[i]
                << "," << r.exact[i] << "," << r.errors[i] << "\n";
        }
        oss << "\n";
    }
    return oss.str();
}

} // namespace workbench
