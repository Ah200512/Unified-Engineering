// test_thermal.cpp — Unit tests for thermal FEA solver
#include "thermal_solver.hpp"
#include <iostream>
#include <cmath>
#include <cassert>

static int tests_passed = 0;
static int tests_failed = 0;

#define TEST(name) void name()
#define RUN_TEST(name) do { \
    std::cout << "  " << #name << "... "; \
    try { name(); std::cout << "PASS\n"; ++tests_passed; } \
    catch (const std::exception& e) { std::cout << "FAIL: " << e.what() << "\n"; ++tests_failed; } \
} while(0)

#define ASSERT_NEAR(a, b, tol) do { \
    double _a = (a), _b = (b), _t = (tol); \
    if (std::abs(_a - _b) > _t) { \
        throw std::runtime_error(std::string("ASSERT_NEAR failed: ") + \
            std::to_string(_a) + " vs " + std::to_string(_b) + " (tol=" + std::to_string(_t) + ")"); \
    } \
} while(0)

#define ASSERT_TRUE(cond) do { \
    if (!(cond)) throw std::runtime_error("ASSERT_TRUE failed: " #cond); \
} while(0)

using namespace workbench;

// Test: analytical solution at boundaries
TEST(test_analytical_bc) {
    ThermalParams p;
    ASSERT_NEAR(analytical_solution(0.0, p), 100.0, 1e-10);
    ASSERT_NEAR(analytical_solution(1.0, p), 20.0, 1e-10);
}

// Test: FE solution matches BCs
TEST(test_fe_boundary_conditions) {
    ThermalParams p;
    auto result = solve_thermal(p, 10);
    ASSERT_NEAR(result.temperatures[0], 100.0, 1e-6);
    ASSERT_NEAR(result.temperatures[10], 20.0, 1e-6);
}

// Test: FE solution converges to analytical with mesh refinement
TEST(test_mesh_convergence) {
    ThermalParams p;
    auto r10 = solve_thermal(p, 10);
    auto r20 = solve_thermal(p, 20);
    auto r40 = solve_thermal(p, 40);
    auto r80 = solve_thermal(p, 80);

    // Error should decrease with refinement
    ASSERT_TRUE(r20.max_midpoint_error < r10.max_midpoint_error);
    ASSERT_TRUE(r40.max_midpoint_error < r20.max_midpoint_error);
    ASSERT_TRUE(r80.max_midpoint_error < r40.max_midpoint_error);

    // For linear elements, error ~ O(h^2), so halving h reduces error by ~4x
    double ratio1 = r10.max_midpoint_error / r20.max_midpoint_error;
    double ratio2 = r20.max_midpoint_error / r40.max_midpoint_error;
    // Ratios should be approximately 4 (within factor of 2)
    ASSERT_TRUE(ratio1 > 2.0 && ratio1 < 8.0);
    ASSERT_TRUE(ratio2 > 2.0 && ratio2 < 8.0);
}

// Test: FE solution at midpoints is close to analytical
TEST(test_midpoint_accuracy) {
    ThermalParams p;
    auto result = solve_thermal(p, 80);
    // With 80 elements, max midpoint error should be very small
    ASSERT_TRUE(result.max_midpoint_error < 0.01); // Less than 0.01 °C
}

// Test: custom parameters
TEST(test_custom_params) {
    auto T = solve_thermal_custom(1.0, 1e-4, 10.0, 10000.0, 100.0, 20.0, 20);
    ASSERT_TRUE(T.size() == 21); // N+1 nodes
    ASSERT_NEAR(T[0], 100.0, 1e-6);
    ASSERT_NEAR(T[20], 20.0, 1e-6);
}

// Test: CSV export
TEST(test_csv_export) {
    ThermalParams p;
    auto r = solve_thermal(p, 10);
    std::vector<ThermalResult> results = {r};
    std::string csv = export_results_csv(results, p);
    ASSERT_TRUE(csv.find("node_id") != std::string::npos);
    ASSERT_TRUE(csv.find("T_FE_C") != std::string::npos);
}

// Test: invalid parameters
TEST(test_invalid_params) {
    ThermalParams p;
    p.L = -1.0;
    bool threw = false;
    try { solve_thermal(p, 10); } catch (...) { threw = true; }
    ASSERT_TRUE(threw);
}

int main() {
    std::cout << "=== Thermal FEA Solver Tests ===\n";
    RUN_TEST(test_analytical_bc);
    RUN_TEST(test_fe_boundary_conditions);
    RUN_TEST(test_mesh_convergence);
    RUN_TEST(test_midpoint_accuracy);
    RUN_TEST(test_custom_params);
    RUN_TEST(test_csv_export);
    RUN_TEST(test_invalid_params);

    std::cout << "\nResults: " << tests_passed << " passed, " << tests_failed << " failed\n";
    return tests_failed > 0 ? 1 : 0;
}
