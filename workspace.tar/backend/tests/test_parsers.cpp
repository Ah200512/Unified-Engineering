// test_parsers.cpp — Unit tests for STL and CSV parsers
#include "stl_parser.hpp"
#include "csv_parser.hpp"
#include <iostream>
#include <cmath>

static int tests_passed = 0;
static int tests_failed = 0;

#define TEST(name) void name()
#define RUN_TEST(name) do { \
    std::cout << "  " << #name << "... "; \
    try { name(); std::cout << "PASS\n"; ++tests_passed; } \
    catch (const std::exception& e) { std::cout << "FAIL: " << e.what() << "\n"; ++tests_failed; } \
} while(0)

#define ASSERT_TRUE(cond) do { \
    if (!(cond)) throw std::runtime_error("ASSERT_TRUE failed: " #cond); \
} while(0)

using namespace workbench;

// Valid STL
TEST(test_valid_stl) {
    std::string stl =
        "solid test\n"
        "  facet normal 0 0 1\n"
        "    outer loop\n"
        "      vertex 0 0 0\n"
        "      vertex 1 0 0\n"
        "      vertex 0 1 0\n"
        "    endloop\n"
        "  endfacet\n"
        "endsolid test\n";
    auto data = parse_stl(stl);
    ASSERT_TRUE(data.is_valid);
    ASSERT_TRUE(data.triangles.size() == 1);
    ASSERT_TRUE(data.name == "test");
}

// Invalid STL (empty)
TEST(test_empty_stl) {
    auto data = parse_stl("");
    ASSERT_TRUE(!data.is_valid);
    ASSERT_TRUE(!data.error.empty());
}

// Invalid STL (no triangles)
TEST(test_stl_no_triangles) {
    std::string stl = "solid empty\nendsolid empty\n";
    auto data = parse_stl(stl);
    ASSERT_TRUE(!data.is_valid);
}

// Valid CSV
TEST(test_valid_csv) {
    std::string csv =
        "node_id,x_m,y_m,z_m,temperature_C\n"
        "0,0.0,0.0,0.0,100.0\n"
        "1,1.0,0.0,0.0,50.0\n"
        "2,0.5,0.5,0.0,75.0\n";
    auto data = parse_temperature_csv(csv);
    ASSERT_TRUE(data.is_valid);
    ASSERT_TRUE(data.nodes.size() == 3);
    ASSERT_TRUE(std::abs(data.min_temp - 50.0) < 1e-10);
    ASSERT_TRUE(std::abs(data.max_temp - 100.0) < 1e-10);
}

// Missing column
TEST(test_csv_missing_column) {
    std::string csv =
        "node_id,x_m,y_m,temperature_C\n"  // missing z_m
        "0,0.0,0.0,100.0\n";
    auto data = parse_temperature_csv(csv);
    ASSERT_TRUE(!data.is_valid);
    ASSERT_TRUE(data.error.find("z_m") != std::string::npos);
}

// Non-finite values
TEST(test_csv_nonfinite) {
    std::string csv =
        "node_id,x_m,y_m,z_m,temperature_C\n"
        "0,0.0,0.0,0.0,100.0\n"
        "1,inf,0.0,0.0,50.0\n"  // non-finite x
        "2,0.5,0.5,0.0,75.0\n";
    auto data = parse_temperature_csv(csv);
    ASSERT_TRUE(data.is_valid);
    ASSERT_TRUE(data.nodes.size() == 2);  // row 1 skipped
    ASSERT_TRUE(!data.warnings.empty());
}

// Empty CSV
TEST(test_empty_csv) {
    auto data = parse_temperature_csv("");
    ASSERT_TRUE(!data.is_valid);
}

// CSV with only header
TEST(test_csv_header_only) {
    std::string csv = "node_id,x_m,y_m,z_m,temperature_C\n";
    auto data = parse_temperature_csv(csv);
    ASSERT_TRUE(!data.is_valid);
}

int main() {
    std::cout << "=== Parser Tests ===\n";
    RUN_TEST(test_valid_stl);
    RUN_TEST(test_empty_stl);
    RUN_TEST(test_stl_no_triangles);
    RUN_TEST(test_valid_csv);
    RUN_TEST(test_csv_missing_column);
    RUN_TEST(test_csv_nonfinite);
    RUN_TEST(test_empty_csv);
    RUN_TEST(test_csv_header_only);

    std::cout << "\nResults: " << tests_passed << " passed, " << tests_failed << " failed\n";
    return tests_failed > 0 ? 1 : 0;
}
