// test_backprop.cpp — Unit tests for backpropagation
#include "backprop.hpp"
#include <iostream>
#include <cmath>

static int tests_passed = 0;
static int tests_failed = 0;

#define TEST(name) void name()
#define RUN_TEST(name) do { \
    std::cout << "  " << #name << "... "; \
    try { name(); std::cout << "PASS\n"; ++tests_passed; } \
    catch (const std::exception& e) { std::cout << "FAIL: " << e.what() << "\n"; ++tests_failed; } \
} while(0)

#define ASSERT_NEAR(a, b, tol) do { \
    double _a = (a), _b = (b), _t = (tol); \
    if (std::abs(_a - _b) > _t) { \
        throw std::runtime_error(std::string("ASSERT_NEAR failed: ") + \
            std::to_string(_a) + " vs " + std::to_string(_b)); \
    } \
} while(0)

#define ASSERT_TRUE(cond) do { \
    if (!(cond)) throw std::runtime_error("ASSERT_TRUE failed: " #cond); \
} while(0)

using namespace workbench;

// Test: forward pass
TEST(test_forward) {
    NetworkParams p{0.5, 0.0, 1.0, 0.0};
    double h, y_hat;
    forward(1.0, p, h, y_hat);
    // h = tanh(0.5*1 + 0) = tanh(0.5) ≈ 0.4621
    ASSERT_NEAR(h, std::tanh(0.5), 1e-10);
    // y_hat = 1.0 * h + 0 = h
    ASSERT_NEAR(y_hat, h, 1e-10);
}

// Test: loss computation
TEST(test_loss) {
    ASSERT_NEAR(compute_loss(2.0, 2.0), 0.0, 1e-15);
    ASSERT_NEAR(compute_loss(3.0, 2.0), 0.5, 1e-15);
    ASSERT_NEAR(compute_loss(0.0, 2.0), 2.0, 1e-15);
}

// Test: gradient verification (central finite differences)
TEST(test_gradient_verification) {
    NetworkParams p{0.5, 0.0, 1.0, 0.0};
    auto checks = verify_gradients(1.0, 2.0, p, 1e-6);

    for (int i = 0; i < 4; ++i) {
        ASSERT_TRUE(checks[i].passed);
        ASSERT_TRUE(checks[i].error <= 1e-5);
    }
}

// Test: training reduces loss
TEST(test_training_reduces_loss) {
    NetworkParams p0{0.5, 0.0, 1.0, 0.0};
    auto history = train(1.0, 2.0, p0, 0.1, 100);

    ASSERT_TRUE(history.size() == 101); // initial + 100 steps
    ASSERT_TRUE(history.back().loss < history.front().loss);
}

// Test: first step matches hand calculation
TEST(test_first_step) {
    NetworkParams p{0.5, 0.0, 1.0, 0.0};
    auto step = gradient_step(1.0, 2.0, p, 0.1);

    // h = tanh(0.5) ≈ 0.4621
    double h = std::tanh(0.5);
    ASSERT_NEAR(step.h, h, 1e-10);

    // y_hat = 1.0 * h + 0 = h
    ASSERT_NEAR(step.y_hat, h, 1e-10);

    // loss = 0.5 * (h - 2)^2
    double expected_loss = 0.5 * (h - 2.0) * (h - 2.0);
    ASSERT_NEAR(step.loss, expected_loss, 1e-10);

    // Gradients should be non-zero (target != prediction)
    ASSERT_TRUE(std::abs(step.grads.dJ_dw) > 1e-10);
    ASSERT_TRUE(std::abs(step.grads.dJ_dc) > 1e-10);
}

// Test: simultaneous update (all gradients from same forward pass)
TEST(test_simultaneous_update) {
    NetworkParams p{0.5, 0.0, 1.0, 0.0};
    auto step = gradient_step(1.0, 2.0, p, 0.1);

    // Verify all parameters changed
    ASSERT_TRUE(step.params.w != p.w);
    ASSERT_TRUE(step.params.b != p.b);
    ASSERT_TRUE(step.params.v != p.v);
    ASSERT_TRUE(step.params.c != p.c);
}

int main() {
    std::cout << "=== Backpropagation Tests ===\n";
    RUN_TEST(test_forward);
    RUN_TEST(test_loss);
    RUN_TEST(test_gradient_verification);
    RUN_TEST(test_training_reduces_loss);
    RUN_TEST(test_first_step);
    RUN_TEST(test_simultaneous_update);

    std::cout << "\nResults: " << tests_passed << " passed, " << tests_failed << " failed\n";
    return tests_failed > 0 ? 1 : 0;
}
