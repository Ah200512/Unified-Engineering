// test_hardware.cpp — Unit tests for device adapters
#include "device_adapter.hpp"
#include <iostream>

static int tests_passed = 0;
static int tests_failed = 0;

#define TEST(name) void name()
#define RUN_TEST(name) do { \
    std::cout << "  " << #name << "... "; \
    try { name(); std::cout << "PASS\n"; ++tests_passed; } \
    catch (const std::exception& e) { std::cout << "FAIL: " << e.what() << "\n"; ++tests_failed; } \
} while(0)

#define ASSERT_TRUE(cond) do { \
    if (!(cond)) throw std::runtime_error("ASSERT_TRUE failed: " #cond); \
} while(0)

using namespace workbench;

TEST(test_device_discovery) {
    DeviceManager mgr;
    mgr.discover_all();
    auto devices = mgr.get_all_devices();
    ASSERT_TRUE(devices.size() == 3);
}

TEST(test_mcu_connect_disconnect) {
    MCUAdapter mcu;
    auto info = mcu.discover();
    ASSERT_TRUE(info.status == DeviceStatus::DISCONNECTED);
    ASSERT_TRUE(mcu.connect());
    info = mcu.get_info();
    ASSERT_TRUE(info.status == DeviceStatus::CONNECTED);
    mcu.disconnect();
    info = mcu.get_info();
    ASSERT_TRUE(info.status == DeviceStatus::DISCONNECTED);
}

TEST(test_telemetry_requires_connection) {
    MCUAdapter mcu;
    std::string tel = mcu.get_telemetry();
    ASSERT_TRUE(tel == "Not connected");
    mcu.connect();
    tel = mcu.get_telemetry();
    ASSERT_TRUE(tel != "Not connected");
}

TEST(test_jtag_is_debug_interface) {
    JTAGAdapter jtag;
    auto info = jtag.discover();
    bool found_debug_note = false;
    for (const auto& cap : info.capabilities) {
        if (cap.name == "type" && cap.value.find("Debug interface") != std::string::npos) {
            found_debug_note = true;
        }
    }
    ASSERT_TRUE(found_debug_note);
}

TEST(test_device_manager_get_by_id) {
    DeviceManager mgr;
    auto* dev = mgr.get_device("mcu-001");
    ASSERT_TRUE(dev != nullptr);
    auto* missing = mgr.get_device("nonexistent");
    ASSERT_TRUE(missing == nullptr);
}

int main() {
    std::cout << "=== Hardware Adapter Tests ===\n";
    RUN_TEST(test_device_discovery);
    RUN_TEST(test_mcu_connect_disconnect);
    RUN_TEST(test_telemetry_requires_connection);
    RUN_TEST(test_jtag_is_debug_interface);
    RUN_TEST(test_device_manager_get_by_id);

    std::cout << "\nResults: " << tests_passed << " passed, " << tests_failed << " failed\n";
    return tests_failed > 0 ? 1 : 0;
}
