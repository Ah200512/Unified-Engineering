// test_benchmark.cpp — Unit tests for multicore benchmark
#include "benchmark.hpp"
#include <iostream>
#include <cmath>

static int tests_passed = 0;
static int tests_failed = 0;

#define TEST(name) void name()
#define RUN_TEST(name) do { \
    std::cout << "  " << #name << "... "; \
    try { name(); std::cout << "PASS\n"; ++tests_passed; } \
    catch (const std::exception& e) { std::cout << "FAIL: " << e.what() << "\n"; ++tests_failed; } \
} while(0)

#define ASSERT_TRUE(cond) do { \
    if (!(cond)) throw std::runtime_error("ASSERT_TRUE failed: " #cond); \
} while(0)

using namespace workbench;

TEST(test_generate_cases_deterministic) {
    auto c1 = generate_cases(10, 42);
    auto c2 = generate_cases(10, 42);
    ASSERT_TRUE(c1.size() == 10);
    ASSERT_TRUE(c2.size() == 10);
    for (std::size_t i = 0; i < 10; ++i) {
        ASSERT_TRUE(std::abs(c1[i].k - c2[i].k) < 1e-15);
        ASSERT_TRUE(std::abs(c1[i].q - c2[i].q) < 1e-15);
    }
}

TEST(test_generate_cases_positive) {
    auto cases = generate_cases(100, 42);
    for (const auto& c : cases) {
        ASSERT_TRUE(c.k > 0);
        ASSERT_TRUE(c.q > 0);
    }
}

TEST(test_serial_benchmark) {
    BenchmarkConfig cfg;
    cfg.case_count = 5;
    cfg.mesh_size = 100;
    cfg.repetitions = 2;
    auto cases = generate_cases(5, 42);
    auto result = benchmark_serial(cases, cfg, 2);
    ASSERT_TRUE(result.workers == 1);
    ASSERT_TRUE(result.times_ms.size() == 2);
    ASSERT_TRUE(result.median_ms > 0);
}

TEST(test_parallel_benchmark) {
    BenchmarkConfig cfg;
    cfg.case_count = 10;
    cfg.mesh_size = 100;
    cfg.repetitions = 2;
    auto cases = generate_cases(10, 42);
    auto result = benchmark_parallel(cases, cfg, 2, 2);
    ASSERT_TRUE(result.workers == 2);
    ASSERT_TRUE(result.median_ms > 0);
}

TEST(test_serial_parallel_agreement) {
    BenchmarkConfig cfg;
    cfg.case_count = 5;
    cfg.mesh_size = 100;
    auto cases = generate_cases(5, 42);
    double max_diff = verify_agreement(cases, cfg, 2);
    // Must agree within 1e-8 °C
    ASSERT_TRUE(max_diff < 1e-8);
}

TEST(test_system_info) {
    std::string info = get_system_info();
    ASSERT_TRUE(info.find("hw_threads") != std::string::npos);
    ASSERT_TRUE(info.find("compiler") != std::string::npos);
}

int main() {
    std::cout << "=== Benchmark Tests ===\n";
    RUN_TEST(test_generate_cases_deterministic);
    RUN_TEST(test_generate_cases_positive);
    RUN_TEST(test_serial_benchmark);
    RUN_TEST(test_parallel_benchmark);
    RUN_TEST(test_serial_parallel_agreement);
    RUN_TEST(test_system_info);

    std::cout << "\nResults: " << tests_passed << " passed, " << tests_failed << " failed\n";
    return tests_failed > 0 ? 1 : 0;
}
