// thermal_solver.hpp — 1D steady-state thermal FEA
// Governing equation: -d/dx(kA dT/dx) = qA
// Two-node linear elements, Thomas algorithm solver
#ifndef THERMAL_SOLVER_HPP
#define THERMAL_SOLVER_HPP

#include <vector>
#include <string>
#include <cstddef>

namespace workbench {

struct ThermalParams {
    double L        = 1.0;      // Domain length [m]
    double A        = 1e-4;     // Cross-section area [m²]
    double k        = 10.0;     // Thermal conductivity [W/(m·K)]
    double q        = 10000.0;  // Volumetric heat generation [W/m³]
    double T_left   = 100.0;    // Left BC [°C]
    double T_right  = 20.0;     // Right BC [°C]
};

struct ThermalResult {
    std::size_t N;                       // Number of elements
    double h;                            // Element size
    std::vector<double> nodes;           // x-coordinates [m]
    std::vector<double> temperatures;    // FE solution [°C]
    std::vector<double> exact;           // Analytical solution [°C]
    std::vector<double> errors;          // |T_FE - T_exact| [°C]
    double max_midpoint_error;           // Max error at element midpoints
};

// Analytical solution: T(x) = T_left + (T_right-T_left)x/L + q*x*(L-x)/(2k)
double analytical_solution(double x, const ThermalParams& p);

// Solve the 1D thermal FEA problem for N elements
ThermalResult solve_thermal(const ThermalParams& params, std::size_t N);

// Solve with custom parameters (for benchmarking)
std::vector<double> solve_thermal_custom(
    double L, double A, double k, double q,
    double T_left, double T_right, std::size_t N);

// Export results as CSV string
std::string export_results_csv(const std::vector<ThermalResult>& results,
                               const ThermalParams& params);

} // namespace workbench

#endif // THERMAL_SOLVER_HPP
