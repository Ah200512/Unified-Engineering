// stl_parser.hpp — ASCII STL file parser
#ifndef STL_PARSER_HPP
#define STL_PARSER_HPP

#include <vector>
#include <array>
#include <string>
#include <cstddef>

namespace workbench {

struct Triangle {
    std::array<double, 3> normal;
    std::array<std::array<double, 3>, 3> vertices;
};

struct STLData {
    std::string name;
    std::vector<Triangle> triangles;
    bool is_valid = false;
    std::string error;
    std::array<double, 3> min_bound{0, 0, 0};
    std::array<double, 3> max_bound{0, 0, 0};
};

// Parse ASCII STL from string content
// Max file size: 50 MB
STLData parse_stl(const std::string& content);

// Parse ASCII STL from file path
STLData parse_stl_file(const std::string& path);

} // namespace workbench

#endif // STL_PARSER_HPP
