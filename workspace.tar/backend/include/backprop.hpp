// backprop.hpp — Handwritten backpropagation for 2-layer regression network
// Network: h = tanh(w*x + b), y_hat = v*h + c, J = 0.5*(y_hat - y)^2
#ifndef BACKPROP_HPP
#define BACKPROP_HPP

#include <array>
#include <vector>
#include <cstddef>

namespace workbench {

struct NetworkParams {
    double w = 0.5;
    double b = 0.0;
    double v = 1.0;
    double c = 0.0;
};

struct Gradients {
    double dJ_dw;
    double dJ_db;
    double dJ_dv;
    double dJ_dc;
};

struct TrainingStep {
    std::size_t step;
    NetworkParams params;
    double h;
    double y_hat;
    double loss;
    Gradients grads;
};

struct GradientCheckResult {
    double analytical;
    double numerical;
    double error;
    bool passed;
};

// Forward pass
void forward(double x, const NetworkParams& p, double& h, double& y_hat);

// Compute loss
double compute_loss(double y_hat, double y);

// Compute gradients by hand-derived chain rule
Gradients compute_gradients(double x, double y, const NetworkParams& p,
                            double h, double y_hat);

// One gradient descent step (simultaneous update)
TrainingStep gradient_step(double x, double y, const NetworkParams& p, double lr);

// Train for N steps
std::vector<TrainingStep> train(double x, double y, NetworkParams p0,
                                double lr, std::size_t num_steps);

// Verify gradients using central finite differences
// Returns array of 4 results: [dJ_dw, dJ_db, dJ_dv, dJ_dc]
std::array<GradientCheckResult, 4> verify_gradients(
    double x, double y, const NetworkParams& p, double epsilon = 1e-6);

} // namespace workbench

#endif // BACKPROP_HPP
