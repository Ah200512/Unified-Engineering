// benchmark.hpp — Multicore performance benchmark (Module D)
// Uses std::thread for actual parallel execution
#ifndef BENCHMARK_HPP
#define BENCHMARK_HPP

#include <vector>
#include <cstddef>
#include <string>

namespace workbench {

struct TestCase {
    double k;  // Thermal conductivity [W/(m·K)]
    double q;  // Heat generation [W/m³]
};

struct BenchmarkResult {
    int workers;
    std::vector<double> times_ms;  // One per repetition
    double median_ms;
    double speedup;
    double efficiency;
};

struct BenchmarkConfig {
    std::size_t case_count = 50;
    std::size_t mesh_size = 1000;
    int repetitions = 5;
    unsigned int seed = 42;
    double L = 1.0;
    double A = 1e-4;
    double T_left = 100.0;
    double T_right = 20.0;
};

// Generate deterministic test cases with fixed seed
std::vector<TestCase> generate_cases(std::size_t count, unsigned int seed);

// Run serial benchmark
BenchmarkResult benchmark_serial(const std::vector<TestCase>& cases,
                                  const BenchmarkConfig& cfg,
                                  int repetitions);

// Run parallel benchmark with specified worker count
// Uses std::thread for actual CPU parallelism
BenchmarkResult benchmark_parallel(const std::vector<TestCase>& cases,
                                    const BenchmarkConfig& cfg,
                                    int workers,
                                    int repetitions);

// Run full benchmark suite for worker counts [1, 2, 3, 4, ...]
std::vector<BenchmarkResult> run_benchmark_suite(
    const BenchmarkConfig& cfg,
    const std::vector<int>& worker_counts);

// Verify serial/parallel numerical agreement
// Returns max absolute difference between serial and parallel results
double verify_agreement(const std::vector<TestCase>& cases,
                        const BenchmarkConfig& cfg,
                        int workers);

// Get system info as JSON string
std::string get_system_info();

} // namespace workbench

#endif // BENCHMARK_HPP
