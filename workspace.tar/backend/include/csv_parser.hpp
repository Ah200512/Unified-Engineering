// csv_parser.hpp — CSV temperature file parser
// Schema: node_id,x_m,y_m,z_m,temperature_C
#ifndef CSV_PARSER_HPP
#define CSV_PARSER_HPP

#include <vector>
#include <array>
#include <string>

namespace workbench {

struct TemperatureNode {
    int node_id;
    double x, y, z;
    double temperature;
};

struct CSVData {
    std::vector<TemperatureNode> nodes;
    bool is_valid = false;
    std::string error;
    std::vector<std::string> warnings;
    double min_temp = 0, max_temp = 0;
    std::array<double, 3> min_bound{0, 0, 0};
    std::array<double, 3> max_bound{0, 0, 0};
};

// Parse CSV temperature file from string
CSVData parse_temperature_csv(const std::string& content);

// Parse CSV temperature file from path
CSVData parse_temperature_csv_file(const std::string& path);

} // namespace workbench

#endif // CSV_PARSER_HPP
