// device_adapter.hpp — Simulated embedded device adapters (Module E)
#ifndef DEVICE_ADAPTER_HPP
#define DEVICE_ADAPTER_HPP

#include <string>
#include <vector>
#include <memory>

namespace workbench {

enum class DeviceType { MCU, FPGA, JTAG };
enum class DeviceStatus { DISCONNECTED, CONNECTING, CONNECTED, ERROR };

struct DeviceCapability {
    std::string name;
    std::string value;
};

struct DeviceInfo {
    std::string id;
    std::string name;
    DeviceType type;
    DeviceStatus status;
    std::vector<DeviceCapability> capabilities;
    std::string last_telemetry;
    std::string error_message;
};

// Abstract base class for device adapters
class DeviceAdapter {
public:
    virtual ~DeviceAdapter() = default;
    virtual DeviceInfo discover() = 0;
    virtual bool connect() = 0;
    virtual void disconnect() = 0;
    virtual std::string get_telemetry() = 0;
    virtual DeviceInfo get_info() const = 0;
};

// Simulated MCU adapter (STM32F407)
class MCUAdapter : public DeviceAdapter {
public:
    MCUAdapter(const std::string& id = "mcu-001");
    DeviceInfo discover() override;
    bool connect() override;
    void disconnect() override;
    std::string get_telemetry() override;
    DeviceInfo get_info() const override;
private:
    DeviceInfo info_;
};

// Simulated FPGA adapter (Xilinx Artix-7)
class FPGAAdapter : public DeviceAdapter {
public:
    FPGAAdapter(const std::string& id = "fpga-001");
    DeviceInfo discover() override;
    bool connect() override;
    void disconnect() override;
    std::string get_telemetry() override;
    DeviceInfo get_info() const override;
private:
    DeviceInfo info_;
};

// Simulated JTAG debug adapter (SEGGER J-Link)
class JTAGAdapter : public DeviceAdapter {
public:
    JTAGAdapter(const std::string& id = "jtag-001");
    DeviceInfo discover() override;
    bool connect() override;
    void disconnect() override;
    std::string get_telemetry() override;
    DeviceInfo get_info() const override;
private:
    DeviceInfo info_;
};

// Device manager: discovers and manages all adapters
class DeviceManager {
public:
    DeviceManager();
    void discover_all();
    std::vector<DeviceInfo> get_all_devices() const;
    DeviceAdapter* get_device(const std::string& id);
private:
    std::vector<std::unique_ptr<DeviceAdapter>> adapters_;
};

} // namespace workbench

#endif // DEVICE_ADAPTER_HPP
