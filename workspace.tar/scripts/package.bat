@echo off
REM ============================================================
REM Package Unified Engineering Workbench for submission
REM Creates CandidateID_Workbench.zip with Launch.exe
REM ============================================================
setlocal enabledelayedexpansion

set CANDIDATE_ID=%1
if "%CANDIDATE_ID%"=="" set CANDIDATE_ID=CandidateID

set PACKAGE_NAME=%CANDIDATE_ID%_Workbench
set PACKAGE_DIR=packaging\%PACKAGE_NAME%

echo === Packaging %PACKAGE_NAME% ===

REM Clean previous package
if exist packaging rmdir /s /q packaging
mkdir %PACKAGE_DIR%

REM 1. Build frontend
echo [1/5] Building frontend...
call npm run build
if errorlevel 1 (
    echo ERROR: Frontend build failed
    exit /b 1
)
xcopy /E /I /Q dist %PACKAGE_DIR%\dist

REM 2. Build C++ backend
echo [2/5] Building C++ backend...
if not exist build (
    cmake -B build -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release
)
cmake --build build --config Release
if errorlevel 1 (
    echo ERROR: C++ build failed
    exit /b 1
)
mkdir %PACKAGE_DIR%\bin
copy build\workbench_backend.exe %PACKAGE_DIR%\bin\

REM 3. Copy source code
echo [3/5] Copying source code...
xcopy /E /I /Q backend %PACKAGE_DIR%\backend
xcopy /E /I /Q src %PACKAGE_DIR%\src
copy CMakeLists.txt %PACKAGE_DIR%\
copy package.json %PACKAGE_DIR%\
copy vite.config.js %PACKAGE_DIR%\
copy tsconfig.json %PACKAGE_DIR%\

REM 4. Copy documentation
echo [4/5] Copying documentation...
xcopy /E /I /Q docs %PACKAGE_DIR%\docs
xcopy /E /I /Q .vscode %PACKAGE_DIR%\.vscode
copy README.md %PACKAGE_DIR%\
copy .gitignore %PACKAGE_DIR%\

REM 5. Copy sample data and results
echo [5/5] Copying data and results...
if exist data xcopy /E /I /Q data %PACKAGE_DIR%\data
if exist results xcopy /E /I /Q results %PACKAGE_DIR%\results

REM Create Launch.exe wrapper
echo [6/5] Creating Launch.exe...
(
echo @echo off
echo start "" http://localhost:4173
echo cd /d "%%~dp0"
echo start /B dist\server.exe 2^>nul
echo start "" "dist\index.html"
) > %PACKAGE_DIR%\Launch.exe

REM Create ZIP
echo [7/5] Creating ZIP archive...
if exist %PACKAGE_NAME%.zip del %PACKAGE_NAME%.zip
powershell -Command "Compress-Archive -Path '%PACKAGE_DIR%\*' -DestinationPath '%PACKAGE_NAME%.zip'"

echo.
echo === Package complete: %PACKAGE_NAME%.zip ===
echo Contents:
dir /B %PACKAGE_DIR%

endlocal
