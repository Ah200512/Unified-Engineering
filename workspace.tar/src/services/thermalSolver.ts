/**
 * Thermal Finite Element Analysis Solver
 * 
 * Implements steady-state 1D thermal FEA using two-node linear elements.
 * 
 * Governing equation: -d/dx(kA dT/dx) = qA
 * 
 * Parameters:
 *   L = 1 m (domain length)
 *   A = 1e-4 m² (cross-sectional area)
 *   k = 10 W/(m·K) (thermal conductivity)
 *   q = 10000 W/m³ (volumetric heat generation)
 *   T(0) = 100 °C (left BC)
 *   T(L) = 20 °C (right BC)
 * 
 * Analytical solution:
 *   T_exact(x) = 100 - 80x/L + [q/(2k)]x(L-x)
 * 
 * C++ Equivalent: This algorithm maps directly to C++17 using Eigen or
 * hand-assembled sparse matrices. The assembly loop is identical.
 */

export interface ThermalParams {
  L: number;    // Domain length [m]
  A: number;    // Cross-section area [m²]
  k: number;    // Thermal conductivity [W/(m·K)]
  q: number;    // Volumetric heat generation [W/m³]
  T_left: number;  // Left boundary temperature [°C]
  T_right: number; // Right boundary temperature [°C]
}

export interface ThermalResult {
  N: number;
  h: number;
  nodes: number[];
  temperatures: number[];
  exactTemperatures: number[];
  errors: number[];
  maxError: number;
  stiffnessMatrix: number[][];
  loadVector: number[];
}

export const DEFAULT_PARAMS: ThermalParams = {
  L: 1.0,
  A: 1e-4,
  k: 10.0,
  q: 10000.0,
  T_left: 100.0,
  T_right: 20.0,
};

/**
 * Analytical solution for verification
 * T_exact(x) = T_left + (T_right - T_left)*x/L + [q/(2k)]*x*(L-x)
 */
export function analyticalSolution(x: number, params: ThermalParams): number {
  const { L, k, q, T_left, T_right } = params;
  return T_left + (T_right - T_left) * (x / L) + (q / (2 * k)) * x * (L - x);
}

/**
 * Assemble element stiffness matrix for a single 2-node linear element
 * 
 * For element e with length h_e:
 *   K_e = (k*A/h_e) * [[1, -1], [-1, 1]]
 * 
 * This is the standard 1D Laplacian element stiffness matrix.
 */
function elementStiffness(ke: number, Ae: number, he: number): number[][] {
  const coeff = (ke * Ae) / he;
  return [
    [coeff, -coeff],
    [-coeff, coeff],
  ];
}

/**
 * Assemble element load vector for uniform source term
 * 
 * f_e = (q*A*h_e/2) * [1, 1]^T
 * 
 * This comes from integrating qA*Ni over the element length.
 */
function elementLoad(qe: number, Ae: number, he: number): number[] {
  const val = (qe * Ae * he) / 2.0;
  return [val, val];
}

/**
 * Solve tridiagonal system using Thomas algorithm (O(n) complexity)
 * 
 * Solves Ax = b where A is tridiagonal.
 * In C++, this would use Eigen::SparseLU or a custom Thomas solver.
 */
function solveTridiagonal(
  lower: number[],
  diag: number[],
  upper: number[],
  rhs: number[]
): number[] {
  const n = diag.length;
  const c = [...upper];
  const d = [...rhs];
  const x = new Array(n).fill(0);

  // Forward elimination
  for (let i = 1; i < n; i++) {
    const m = lower[i] / diag[i - 1];
    diag[i] -= m * upper[i - 1];
    d[i] -= m * d[i - 1];
  }

  // Back substitution
  x[n - 1] = d[n - 1] / diag[n - 1];
  for (let i = n - 2; i >= 0; i--) {
    x[i] = (d[i] - c[i] * x[i + 1]) / diag[i];
  }

  return x;
}

/**
 * Main FEA solver
 * 
 * Assembles global stiffness matrix K and load vector F,
 * applies Dirichlet BCs, and solves the system.
 */
export function solveThermalFEA(params: ThermalParams, N: number): ThermalResult {
  const { L, A, k, q, T_left, T_right } = params;
  const h = L / N; // Element length (uniform mesh)
  const nNodes = N + 1;

  // Initialize global stiffness matrix (stored as dense for clarity)
  // In C++, use Eigen::SparseMatrix<double> for large N
  const K: number[][] = Array.from({ length: nNodes }, () => new Array(nNodes).fill(0));
  const F: number[] = new Array(nNodes).fill(0);

  // Assembly loop: identical to C++ implementation
  for (let e = 0; e < N; e++) {
    const he = h;
    const Ke = elementStiffness(k, A, he);
    const Fe = elementLoad(q, A, he);

    // Global node indices for this element
    const i = e;
    const j = e + 1;

    // Assemble element stiffness into global matrix
    K[i][i] += Ke[0][0];
    K[i][j] += Ke[0][1];
    K[j][i] += Ke[1][0];
    K[j][j] += Ke[1][1];

    // Assemble element load into global vector
    F[i] += Fe[0];
    F[j] += Fe[1];
  }

  // Apply Dirichlet boundary conditions using penalty method
  // T[0] = T_left, T[nNodes-1] = T_right
  // Method: Set row/col to identity, modify RHS
  const penalty = 1e20;

  // Left BC: node 0
  K[0][0] = penalty;
  F[0] = penalty * T_left;

  // Right BC: node nNodes-1
  const lastNode = nNodes - 1;
  K[lastNode][lastNode] = penalty;
  F[lastNode] = penalty * T_right;

  // Solve the system K*T = F
  // Extract tridiagonal structure
  const lower: number[] = new Array(nNodes).fill(0);
  const diag: number[] = new Array(nNodes).fill(0);
  const upper: number[] = new Array(nNodes).fill(0);

  for (let i = 0; i < nNodes; i++) {
    diag[i] = K[i][i];
    if (i > 0) lower[i] = K[i][i - 1];
    if (i < nNodes - 1) upper[i] = K[i][i + 1];
  }

  const temperatures = solveTridiagonal(lower, diag, upper, F);

  // Calculate nodes and errors
  const nodes: number[] = [];
  const exactTemperatures: number[] = [];
  const errors: number[] = [];

  for (let i = 0; i < nNodes; i++) {
    const x = i * h;
    nodes.push(x);
    const T_exact = analyticalSolution(x, params);
    exactTemperatures.push(T_exact);
    errors.push(Math.abs(temperatures[i] - T_exact));
  }

  // Calculate max error at element midpoints (using FE interpolation)
  let maxError = 0;
  for (let e = 0; e < N; e++) {
    const x_mid = (e + 0.5) * h;
    const T_fe_mid = 0.5 * (temperatures[e] + temperatures[e + 1]); // Linear interpolation
    const T_exact_mid = analyticalSolution(x_mid, params);
    const err = Math.abs(T_fe_mid - T_exact_mid);
    if (err > maxError) maxError = err;
  }

  return {
    N,
    h,
    nodes,
    temperatures,
    exactTemperatures,
    errors,
    maxError,
    stiffnessMatrix: K,
    loadVector: F,
  };
}

/**
 * Run convergence study for multiple mesh sizes
 */
export function convergenceStudy(params: ThermalParams, meshSizes: number[]): ThermalResult[] {
  return meshSizes.map(N => solveThermalFEA(params, N));
}

/**
 * Export results as CSV string
 */
export function exportResultsCSV(results: ThermalResult[], params: ThermalParams): string {
  let csv = '# Thermal FEA Results\n';
  csv += `# L=${params.L} m, A=${params.A} m², k=${params.k} W/(m·K), q=${params.q} W/m³\n`;
  csv += `# T(0)=${params.T_left}°C, T(L)=${params.T_right}°C\n\n`;

  for (const result of results) {
    csv += `# N=${result.N} elements, h=${result.h.toFixed(6)} m, max_error=${result.maxError.toExponential(4)}°C\n`;
    csv += 'node_id,x_m,T_FE_C,T_exact_C,error_C\n';
    for (let i = 0; i < result.nodes.length; i++) {
      csv += `${i},${result.nodes[i].toFixed(6)},${result.temperatures[i].toFixed(6)},${result.exactTemperatures[i].toFixed(6)},${result.errors[i].toExponential(4)}\n`;
    }
    csv += '\n';
  }

  return csv;
}

/**
 * Solve with custom k and q (for performance benchmarking)
 */
export function solveThermalCustom(L: number, A: number, k: number, q: number, T_left: number, T_right: number, N: number): number[] {
  const h = L / N;
  const nNodes = N + 1;

  const K: number[][] = Array.from({ length: nNodes }, () => new Array(nNodes).fill(0));
  const F: number[] = new Array(nNodes).fill(0);

  for (let e = 0; e < N; e++) {
    const coeff = (k * A) / h;
    const load = (q * A * h) / 2.0;
    K[e][e] += coeff;
    K[e][e + 1] -= coeff;
    K[e + 1][e] -= coeff;
    K[e + 1][e + 1] += coeff;
    F[e] += load;
    F[e + 1] += load;
  }

  const penalty = 1e20;
  K[0][0] = penalty;
  F[0] = penalty * T_left;
  K[nNodes - 1][nNodes - 1] = penalty;
  F[nNodes - 1] = penalty * T_right;

  const lower: number[] = new Array(nNodes).fill(0);
  const diag: number[] = new Array(nNodes).fill(0);
  const upper: number[] = new Array(nNodes).fill(0);

  for (let i = 0; i < nNodes; i++) {
    diag[i] = K[i][i];
    if (i > 0) lower[i] = K[i][i - 1];
    if (i < nNodes - 1) upper[i] = K[i][i + 1];
  }

  return solveTridiagonal(lower, diag, upper, F);
}
