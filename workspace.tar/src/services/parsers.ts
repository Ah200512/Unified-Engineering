/**
 * STL and CSV File Parsers
 * 
 * Implements parsers for:
 * 1. ASCII STL files (triangle mesh)
 * 2. CSV temperature files (node_id,x_m,y_m,z_m,temperature_C)
 * 
 * These parsers validate input data and handle edge cases.
 * C++ equivalent: std::ifstream with string parsing, or use
 * a library like libcsv for CSV parsing.
 */

export interface Triangle {
  normal: [number, number, number];
  vertices: [[number, number, number], [number, number, number], [number, number, number]];
}

export interface STLData {
  triangles: Triangle[];
  name: string;
  isValid: boolean;
  error?: string;
  stats: {
    triangleCount: number;
    minBound: [number, number, number];
    maxBound: [number, number, number];
  };
}

export interface TemperatureNode {
  nodeId: number;
  x: number;
  y: number;
  z: number;
  temperature: number;
}

export interface CSVData {
  nodes: TemperatureNode[];
  isValid: boolean;
  error?: string;
  warnings: string[];
  stats: {
    nodeCount: number;
    minTemp: number;
    maxTemp: number;
    minBound: [number, number, number];
    maxBound: [number, number, number];
  };
}

/**
 * Parse ASCII STL file content
 * 
 * Format:
 *   solid name
 *     facet normal ni nj nk
 *       outer loop
 *         vertex v1x v1y v1z
 *         vertex v2x v2y v2z
 *         vertex v3x v3y v3z
 *       endloop
 *     endfacet
 *   endsolid name
 * 
 * Max file size: 50 MB (ASCII)
 */
export function parseSTL(content: string): STLData {
  const result: STLData = {
    triangles: [],
    name: 'unknown',
    isValid: false,
    stats: {
      triangleCount: 0,
      minBound: [Infinity, Infinity, Infinity],
      maxBound: [-Infinity, -Infinity, -Infinity],
    },
  };

  if (!content || content.trim().length === 0) {
    result.error = 'File is empty';
    return result;
  }

  // Check file size (approximate)
  if (content.length > 50 * 1024 * 1024) {
    result.error = 'File exceeds 50 MB limit';
    return result;
  }

  const lines = content.split('\n').map(l => l.trim()).filter(l => l.length > 0);

  if (lines.length < 2) {
    result.error = 'Invalid STL format: insufficient lines';
    return result;
  }

  // Parse solid name
  const solidMatch = lines[0].match(/^solid\s*(.*)/i);
  if (solidMatch) {
    result.name = solidMatch[1] || 'unnamed';
  }

  // Parse facets
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];

    if (line.startsWith('facet normal')) {
      const normalMatch = line.match(/facet normal\s+([\d.eE+-]+)\s+([\d.eE+-]+)\s+([\d.eE+-]+)/i);
      if (!normalMatch) {
        i++;
        continue;
      }

      const normal: [number, number, number] = [
        parseFloat(normalMatch[1]),
        parseFloat(normalMatch[2]),
        parseFloat(normalMatch[3]),
      ];

      // Check for non-finite values
      if (normal.some(v => !isFinite(v))) {
        i++;
        continue;
      }

      // Find vertices
      const vertices: [number, number, number][] = [];
      let j = i + 1;
      while (j < lines.length && !lines[j].startsWith('endfacet')) {
        const vertexMatch = lines[j].match(/vertex\s+([\d.eE+-]+)\s+([\d.eE+-]+)\s+([\d.eE+-]+)/i);
        if (vertexMatch) {
          const v: [number, number, number] = [
            parseFloat(vertexMatch[1]),
            parseFloat(vertexMatch[2]),
            parseFloat(vertexMatch[3]),
          ];
          if (v.every(val => isFinite(val))) {
            vertices.push(v);
          }
        }
        j++;
      }

      if (vertices.length === 3) {
        result.triangles.push({ normal, vertices: [vertices[0], vertices[1], vertices[2]] });

        // Update bounds
        for (const v of vertices) {
          for (let d = 0; d < 3; d++) {
            result.stats.minBound[d] = Math.min(result.stats.minBound[d], v[d]);
            result.stats.maxBound[d] = Math.max(result.stats.maxBound[d], v[d]);
          }
        }
      }

      i = j + 1;
    } else {
      i++;
    }
  }

  result.stats.triangleCount = result.triangles.length;

  if (result.triangles.length === 0) {
    result.error = 'No valid triangles found in STL file';
    return result;
  }

  result.isValid = true;
  return result;
}

/**
 * Parse CSV temperature file
 * 
 * Expected schema:
 *   node_id,x_m,y_m,z_m,temperature_C
 * 
 * Validates:
 * - Required columns present
 * - All values are finite numbers
 * - Non-empty file
 */
export function parseTemperatureCSV(content: string): CSVData {
  const result: CSVData = {
    nodes: [],
    isValid: false,
    warnings: [],
    stats: {
      nodeCount: 0,
      minTemp: Infinity,
      maxTemp: -Infinity,
      minBound: [Infinity, Infinity, Infinity],
      maxBound: [-Infinity, -Infinity, -Infinity],
    },
  };

  if (!content || content.trim().length === 0) {
    result.error = 'File is empty';
    return result;
  }

  const lines = content.split('\n').map(l => l.trim()).filter(l => l.length > 0);

  if (lines.length < 2) {
    result.error = 'File must contain header and at least one data row';
    return result;
  }

  // Parse header
  const header = lines[0].split(',').map(h => h.trim().toLowerCase());
  const requiredCols = ['node_id', 'x_m', 'y_m', 'z_m', 'temperature_c'];
  const colIndices: Record<string, number> = {};

  for (const col of requiredCols) {
    const idx = header.indexOf(col);
    if (idx === -1) {
      result.error = `Missing required column: ${col}`;
      return result;
    }
    colIndices[col] = idx;
  }

  // Parse data rows
  let skippedRows = 0;
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim());

    if (values.length < requiredCols.length) {
      skippedRows++;
      result.warnings.push(`Row ${i + 1}: insufficient columns, skipped`);
      continue;
    }

    const nodeId = parseInt(values[colIndices['node_id']]);
    const x = parseFloat(values[colIndices['x_m']]);
    const y = parseFloat(values[colIndices['y_m']]);
    const z = parseFloat(values[colIndices['z_m']]);
    const temp = parseFloat(values[colIndices['temperature_c']]);

    // Validate finite values
    if (!isFinite(x) || !isFinite(y) || !isFinite(z) || !isFinite(temp)) {
      skippedRows++;
      result.warnings.push(`Row ${i + 1}: non-finite values detected, skipped`);
      continue;
    }

    if (isNaN(nodeId)) {
      skippedRows++;
      result.warnings.push(`Row ${i + 1}: invalid node_id, skipped`);
      continue;
    }

    result.nodes.push({ nodeId, x, y, z, temperature: temp });

    // Update stats
    result.stats.minTemp = Math.min(result.stats.minTemp, temp);
    result.stats.maxTemp = Math.max(result.stats.maxTemp, temp);
    result.stats.minBound[0] = Math.min(result.stats.minBound[0], x);
    result.stats.minBound[1] = Math.min(result.stats.minBound[1], y);
    result.stats.minBound[2] = Math.min(result.stats.minBound[2], z);
    result.stats.maxBound[0] = Math.max(result.stats.maxBound[0], x);
    result.stats.maxBound[1] = Math.max(result.stats.maxBound[1], y);
    result.stats.maxBound[2] = Math.max(result.stats.maxBound[2], z);
  }

  if (skippedRows > 0) {
    result.warnings.push(`${skippedRows} rows skipped due to validation errors`);
  }

  result.stats.nodeCount = result.nodes.length;

  if (result.nodes.length === 0) {
    result.error = 'No valid data rows found';
    return result;
  }

  result.isValid = true;
  return result;
}

/**
 * Generate sample STL data (a simple cube)
 * Clearly labeled as synthetic, not from any CAD export
 */
export function generateSampleSTL(): string {
  const s = 0.5; // half-size
  // 12 triangles for a cube (2 per face, 6 faces)
  const vertices = [
    [-s, -s, -s], [s, -s, -s], [s, s, -s], [-s, s, -s],
    [-s, -s, s], [s, -s, s], [s, s, s], [-s, s, s],
  ];

  const faces = [
    [0, 1, 2, 0, 0, -1], // front
    [0, 2, 3, 0, 0, -1],
    [4, 6, 5, 0, 0, 1],  // back
    [4, 7, 6, 0, 0, 1],
    [0, 4, 5, 0, -1, 0], // bottom
    [0, 5, 1, 0, -1, 0],
    [3, 2, 6, 0, 1, 0],  // top
    [3, 6, 7, 0, 1, 0],
    [0, 3, 7, -1, 0, 0], // left
    [0, 7, 4, -1, 0, 0],
    [1, 5, 6, 1, 0, 0],  // right
    [1, 6, 2, 1, 0, 0],
  ];

  let stl = 'solid sample_cube\n';
  for (const face of faces) {
    stl += `  facet normal ${face[3]} ${face[4]} ${face[5]}\n`;
    stl += '    outer loop\n';
    stl += `      vertex ${vertices[face[0]].join(' ')}\n`;
    stl += `      vertex ${vertices[face[1]].join(' ')}\n`;
    stl += `      vertex ${vertices[face[2]].join(' ')}\n`;
    stl += '    endloop\n';
    stl += '  endfacet\n';
  }
  stl += 'endsolid sample_cube\n';

  return stl;
}

/**
 * Generate sample CSV temperature data
 * Clearly labeled as synthetic demonstration data
 */
export function generateSampleCSV(): string {
  let csv = 'node_id,x_m,y_m,z_m,temperature_C\n';
  const n = 10;
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      for (let k = 0; k < n; k++) {
        const x = (i / (n - 1)) * 1.0;
        const y = (j / (n - 1)) * 0.5;
        const z = (k / (n - 1)) * 0.3;
        // Synthetic temperature distribution (NOT actual ANSYS output)
        const temp = 100 - 80 * x + 20 * Math.sin(Math.PI * y) * Math.cos(Math.PI * z);
        const nodeId = i * n * n + j * n + k;
        csv += `${nodeId},${x.toFixed(4)},${y.toFixed(4)},${z.toFixed(4)},${temp.toFixed(2)}\n`;
      }
    }
  }
  return csv;
}
