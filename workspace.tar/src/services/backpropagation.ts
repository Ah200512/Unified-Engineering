/**
 * Handwritten Backpropagation — Neural Network Training
 * 
 * Network architecture:
 *   x = 1 (input)
 *   y = 2 (target)
 *   h = tanh(w*x + b)  (hidden activation)
 *   y_hat = v*h + c     (output)
 *   J = 0.5 * (y_hat - y)²  (loss)
 * 
 * Initial parameters:
 *   w = 0.5, b = 0, v = 1, c = 0
 *   Learning rate η = 0.1
 * 
 * Chain rule derivatives (computed by hand):
 *   ∂J/∂y_hat = y_hat - y
 *   ∂J/∂v = (y_hat - y) * h
 *   ∂J/∂c = (y_hat - y)
 *   ∂J/∂h = (y_hat - y) * v
 *   ∂h/∂(wx+b) = 1 - h²  (tanh derivative)
 *   ∂J/∂w = (y_hat - y) * v * (1 - h²) * x
 *   ∂J/∂b = (y_hat - y) * v * (1 - h²)
 * 
 * C++ Implementation: This maps directly to C++17 without any
 * automatic differentiation library. All derivatives are hand-coded.
 */

export interface NetworkParams {
  w: number;
  b: number;
  v: number;
  c: number;
}

export interface TrainingStep {
  step: number;
  w: number;
  b: number;
  v: number;
  c: number;
  h: number;
  y_hat: number;
  loss: number;
  dJ_dw: number;
  dJ_db: number;
  dJ_dv: number;
  dJ_dc: number;
}

export const INITIAL_PARAMS: NetworkParams = {
  w: 0.5,
  b: 0.0,
  v: 1.0,
  c: 0.0,
};

export const X_INPUT = 1.0;
export const Y_TARGET = 2.0;
export const LEARNING_RATE = 0.1;

/**
 * Forward propagation
 * Computes h = tanh(w*x + b) and y_hat = v*h + c
 */
export function forward(x: number, params: NetworkParams): { h: number; y_hat: number } {
  const z = params.w * x + params.b;
  const h = Math.tanh(z);
  const y_hat = params.v * h + params.c;
  return { h, y_hat };
}

/**
 * Compute loss J = 0.5 * (y_hat - y)²
 */
export function computeLoss(y_hat: number, y: number): number {
  return 0.5 * Math.pow(y_hat - y, 2);
}

/**
 * Compute all gradients using chain rule (hand-derived)
 * 
 * Derivation:
 *   δ_output = ∂J/∂y_hat = (y_hat - y)
 *   ∂J/∂v = δ_output * h
 *   ∂J/∂c = δ_output * 1 = δ_output
 *   δ_hidden = δ_output * v * (1 - h²)  [backprop through tanh]
 *   ∂J/∂w = δ_hidden * x
 *   ∂J/∂b = δ_hidden * 1 = δ_hidden
 */
export function computeGradients(
  x: number,
  y: number,
  params: NetworkParams,
  h: number,
  y_hat: number
): { dJ_dw: number; dJ_db: number; dJ_dv: number; dJ_dc: number } {
  // Output layer gradient
  const delta_output = y_hat - y;

  // Gradients for output parameters
  const dJ_dv = delta_output * h;
  const dJ_dc = delta_output;

  // Hidden layer gradient (backprop through tanh)
  // dtanh/dz = 1 - tanh²(z) = 1 - h²
  const dtanh = 1.0 - h * h;
  const delta_hidden = delta_output * params.v * dtanh;

  // Gradients for hidden parameters
  const dJ_dw = delta_hidden * x;
  const dJ_db = delta_hidden;

  return { dJ_dw, dJ_db, dJ_dv, dJ_dc };
}

/**
 * Perform one gradient descent step
 * Uses SIMULTANEOUS update: all gradients computed from original params
 */
export function gradientDescentStep(
  x: number,
  y: number,
  params: NetworkParams,
  lr: number
): TrainingStep {
  // Forward pass
  const { h, y_hat } = forward(x, params);
  const loss = computeLoss(y_hat, y);

  // Compute gradients
  const grads = computeGradients(x, y, params, h, y_hat);

  // Simultaneous parameter update (use original gradients for all params)
  const newParams: NetworkParams = {
    w: params.w - lr * grads.dJ_dw,
    b: params.b - lr * grads.dJ_db,
    v: params.v - lr * grads.dJ_dv,
    c: params.c - lr * grads.dJ_dc,
  };

  return {
    step: 0, // Will be set by caller
    w: newParams.w,
    b: newParams.b,
    v: newParams.v,
    c: newParams.c,
    h,
    y_hat,
    loss,
    dJ_dw: grads.dJ_dw,
    dJ_db: grads.dJ_db,
    dJ_dv: grads.dJ_dv,
    dJ_dc: grads.dJ_dc,
  };
}

/**
 * Train for N steps and record history
 */
export function train(
  x: number,
  y: number,
  initialParams: NetworkParams,
  lr: number,
  numSteps: number
): TrainingStep[] {
  const history: TrainingStep[] = [];
  let params = { ...initialParams };

  // Record initial state
  const { h: h0, y_hat: yh0 } = forward(x, params);
  const loss0 = computeLoss(yh0, y);
  const grads0 = computeGradients(x, y, params, h0, yh0);
  history.push({
    step: 0,
    w: params.w,
    b: params.b,
    v: params.v,
    c: params.c,
    h: h0,
    y_hat: yh0,
    loss: loss0,
    dJ_dw: grads0.dJ_dw,
    dJ_db: grads0.dJ_db,
    dJ_dv: grads0.dJ_dv,
    dJ_dc: grads0.dJ_dc,
  });

  for (let i = 1; i <= numSteps; i++) {
    const step = gradientDescentStep(x, y, params, lr);
    step.step = i;
    history.push(step);

    // Update params for next iteration
    params = { w: step.w, b: step.b, v: step.v, c: step.c };
  }

  return history;
}

/**
 * Verify gradients using central finite differences
 * 
 * ∂J/∂w ≈ [J(w+ε, ...) - J(w-ε, ...)] / (2ε)
 * 
 * This is the standard numerical gradient check.
 * C++ equivalent: identical algorithm, just use double precision.
 */
export function verifyGradients(
  x: number,
  y: number,
  params: NetworkParams,
  epsilon: number = 1e-6
): { analytical: number; numerical: number; error: number; passed: boolean }[] {
  const { h, y_hat } = forward(x, params);
  const analyticalGrads = computeGradients(x, y, params, h, y_hat);

  const results: { analytical: number; numerical: number; error: number; passed: boolean }[] = [];

  // Check ∂J/∂w
  const Jw_plus = computeLoss(forward(x, { ...params, w: params.w + epsilon }).y_hat, y);
  const Jw_minus = computeLoss(forward(x, { ...params, w: params.w - epsilon }).y_hat, y);
  const num_dw = (Jw_plus - Jw_minus) / (2 * epsilon);
  results.push({
    analytical: analyticalGrads.dJ_dw,
    numerical: num_dw,
    error: Math.abs(analyticalGrads.dJ_dw - num_dw),
    passed: Math.abs(analyticalGrads.dJ_dw - num_dw) <= 1e-5,
  });

  // Check ∂J/∂b
  const Jb_plus = computeLoss(forward(x, { ...params, b: params.b + epsilon }).y_hat, y);
  const Jb_minus = computeLoss(forward(x, { ...params, b: params.b - epsilon }).y_hat, y);
  const num_db = (Jb_plus - Jb_minus) / (2 * epsilon);
  results.push({
    analytical: analyticalGrads.dJ_db,
    numerical: num_db,
    error: Math.abs(analyticalGrads.dJ_db - num_db),
    passed: Math.abs(analyticalGrads.dJ_db - num_db) <= 1e-5,
  });

  // Check ∂J/∂v
  const Jv_plus = computeLoss(forward(x, { ...params, v: params.v + epsilon }).y_hat, y);
  const Jv_minus = computeLoss(forward(x, { ...params, v: params.v - epsilon }).y_hat, y);
  const num_dv = (Jv_plus - Jv_minus) / (2 * epsilon);
  results.push({
    analytical: analyticalGrads.dJ_dv,
    numerical: num_dv,
    error: Math.abs(analyticalGrads.dJ_dv - num_dv),
    passed: Math.abs(analyticalGrads.dJ_dv - num_dv) <= 1e-5,
  });

  // Check ∂J/∂c
  const Jc_plus = computeLoss(forward(x, { ...params, c: params.c + epsilon }).y_hat, y);
  const Jc_minus = computeLoss(forward(x, { ...params, c: params.c - epsilon }).y_hat, y);
  const num_dc = (Jc_plus - Jc_minus) / (2 * epsilon);
  results.push({
    analytical: analyticalGrads.dJ_dc,
    numerical: num_dc,
    error: Math.abs(analyticalGrads.dJ_dc - num_dc),
    passed: Math.abs(analyticalGrads.dJ_dc - num_dc) <= 1e-5,
  });

  return results;
}

/**
 * Generate step-by-step derivation for the first training step
 */
export function getFirstStepDerivation(): string {
  const x = X_INPUT;
  const y = Y_TARGET;
  const p = INITIAL_PARAMS;

  const z = p.w * x + p.b;
  const h = Math.tanh(z);
  const y_hat = p.v * h + p.c;
  const J = computeLoss(y_hat, y);

  const delta_out = y_hat - y;
  const dJ_dv = delta_out * h;
  const dJ_dc = delta_out;
  const dtanh = 1 - h * h;
  const delta_hid = delta_out * p.v * dtanh;
  const dJ_dw = delta_hid * x;
  const dJ_db = delta_hid;

  return `
=== HANDWRITTEN BACKPROPAGATION DERIVATION ===

Given:
  x = ${x}, y = ${y}
  w = ${p.w}, b = ${p.b}, v = ${p.v}, c = ${p.c}
  η = ${LEARNING_RATE}

--- FORWARD PASS ---
  z = w·x + b = ${p.w}·${x} + ${p.b} = ${z.toFixed(6)}
  h = tanh(z) = tanh(${z.toFixed(6)}) = ${h.toFixed(6)}
  ŷ = v·h + c = ${p.v}·${h.toFixed(6)} + ${p.c} = ${y_hat.toFixed(6)}
  J = ½(ŷ - y)² = ½(${y_hat.toFixed(6)} - ${y})² = ${J.toFixed(6)}

--- BACKWARD PASS (Chain Rule) ---
  δ_out = ∂J/∂ŷ = ŷ - y = ${y_hat.toFixed(6)} - ${y} = ${delta_out.toFixed(6)}

  ∂J/∂v = δ_out · h = ${delta_out.toFixed(6)} · ${h.toFixed(6)} = ${dJ_dv.toFixed(6)}
  ∂J/∂c = δ_out = ${dJ_dc.toFixed(6)}

  dtanh/dz = 1 - h² = 1 - ${h.toFixed(6)}² = ${dtanh.toFixed(6)}
  δ_hid = δ_out · v · (1-h²) = ${delta_out.toFixed(6)} · ${p.v} · ${dtanh.toFixed(6)} = ${delta_hid.toFixed(6)}

  ∂J/∂w = δ_hid · x = ${delta_hid.toFixed(6)} · ${x} = ${dJ_dw.toFixed(6)}
  ∂J/∂b = δ_hid = ${dJ_db.toFixed(6)}

--- PARAMETER UPDATE (simultaneous) ---
  w_new = w - η·∂J/∂w = ${p.w} - ${LEARNING_RATE}·${dJ_dw.toFixed(6)} = ${(p.w - LEARNING_RATE * dJ_dw).toFixed(6)}
  b_new = b - η·∂J/∂b = ${p.b} - ${LEARNING_RATE}·${dJ_db.toFixed(6)} = ${(p.b - LEARNING_RATE * dJ_db).toFixed(6)}
  v_new = v - η·∂J/∂v = ${p.v} - ${LEARNING_RATE}·${dJ_dv.toFixed(6)} = ${(p.v - LEARNING_RATE * dJ_dv).toFixed(6)}
  c_new = c - η·∂J/∂c = ${p.c} - ${LEARNING_RATE}·${dJ_dc.toFixed(6)} = ${(p.c - LEARNING_RATE * dJ_dc).toFixed(6)}
`;
}
