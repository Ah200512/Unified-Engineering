import type { ReactNode } from 'react';

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  glow?: 'blue' | 'cyan' | 'purple' | 'pink' | 'green' | 'amber' | 'none';
}

export function GlassCard({ children, className = '', hover = false, glow = 'none' }: GlassCardProps) {
  const glowClass = glow !== 'none' ? `neon-${glow}` : '';
  return (
    <div className={`glass ${hover ? 'glass-hover' : ''} ${glowClass} ${className}`}>
      {children}
    </div>
  );
}

interface GaugeProps {
  value: number;       // 0-100
  max?: number;
  label: string;
  unit?: string;
  color?: string;
  size?: number;
}

export function Gauge({ value, max = 100, label, unit = '%', color = '#3b82f6', size = 100 }: GaugeProps) {
  const radius = (size - 16) / 2;
  const circumference = 2 * Math.PI * radius;
  const percent = Math.min(100, Math.max(0, (value / max) * 100));
  const dashOffset = circumference - (percent / 100) * circumference * 0.75; // 270° arc

  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size} className="gauge-ring">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          className="gauge-track"
          strokeDasharray={`${circumference * 0.75} ${circumference * 0.25}`}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          className="gauge-fill"
          stroke={color}
          strokeDasharray={`${circumference * 0.75} ${circumference * 0.25}`}
          strokeDashoffset={dashOffset}
        />
      </svg>
      <div className="text-center -mt-2">
        <div className="text-lg font-bold" style={{ color }}>{value.toFixed(1)}{unit}</div>
        <div className="text-[10px] text-[var(--text-muted)] uppercase tracking-wider">{label}</div>
      </div>
    </div>
  );
}

interface StatusLightProps {
  status: 'online' | 'warning' | 'error' | 'idle';
  label?: string;
}

export function StatusLight({ status, label }: StatusLightProps) {
  return (
    <div className="flex items-center gap-2">
      <div className={`status-dot status-${status}`} />
      {label && <span className="text-xs text-[var(--text-secondary)]">{label}</span>}
    </div>
  );
}

interface TerminalOutputProps {
  lines: string[];
  title?: string;
}

export function TerminalOutput({ lines, title }: TerminalOutputProps) {
  return (
    <div className="terminal">
      {title && <div className="text-[10px] text-[var(--text-muted)] mb-2 uppercase tracking-wider">{title}</div>}
      <div className="terminal-content">
        {lines.map((line, i) => (
          <div key={i} className="slide-in" style={{ animationDelay: `${i * 30}ms` }}>
            <span className="text-[var(--neon-cyan)] mr-2">›</span>
            {line}
          </div>
        ))}
      </div>
    </div>
  );
}

interface MetricProps {
  label: string;
  value: string | number;
  unit?: string;
  trend?: 'up' | 'down' | 'flat';
  color?: string;
}

export function Metric({ label, value, unit, trend, color = 'var(--neon-blue)' }: MetricProps) {
  return (
    <div className="flex flex-col">
      <div className="text-[10px] uppercase tracking-wider text-[var(--text-muted)] mb-1">{label}</div>
      <div className="flex items-baseline gap-1">
        <span className="text-xl font-bold" style={{ color }}>{value}</span>
        {unit && <span className="text-xs text-[var(--text-muted)]">{unit}</span>}
        {trend && (
          <span className={`text-xs ml-1 ${
            trend === 'up' ? 'text-[var(--neon-green)]' :
            trend === 'down' ? 'text-[var(--neon-red)]' :
            'text-[var(--text-muted)]'
          }`}>
            {trend === 'up' ? '▲' : trend === 'down' ? '▼' : '●'}
          </span>
        )}
      </div>
    </div>
  );
}
