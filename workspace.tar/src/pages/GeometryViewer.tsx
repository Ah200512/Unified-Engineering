import { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { Upload, RotateCcw, Maximize2, Eye, Info, Box } from 'lucide-react';
import { parseSTL, parseTemperatureCSV, generateSampleSTL, generateSampleCSV } from '../services/parsers';
import type { STLData, CSVData, TemperatureNode } from '../services/parsers';

type ViewMode = 'stl' | 'csv' | 'none';

export default function GeometryViewer() {
  const canvasRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const meshGroupRef = useRef<THREE.Group | null>(null);
  const animFrameRef = useRef<number>(0);

  const [viewMode, setViewMode] = useState<ViewMode>('none');
  const [stlData, setStlData] = useState<STLData | null>(null);
  const [csvData, setCsvData] = useState<CSVData | null>(null);
  const [selectedNode, setSelectedNode] = useState<TemperatureNode | null>(null);
  const [isRotating, setIsRotating] = useState(true);
  const [error, setError] = useState<string>('');

  // Initialize Three.js scene
  useEffect(() => {
    if (!canvasRef.current) return;

    const width = canvasRef.current.clientWidth;
    const height = canvasRef.current.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0f1a);

    const camera = new THREE.PerspectiveCamera(60, width / height, 0.01, 100);
    camera.position.set(2, 1.5, 2);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio);
    canvasRef.current.appendChild(renderer.domElement);

    // Lights
    const ambient = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambient);
    const directional = new THREE.DirectionalLight(0xffffff, 0.8);
    directional.position.set(5, 5, 5);
    scene.add(directional);

    // Grid
    const grid = new THREE.GridHelper(4, 20, 0x334155, 0x1e293b);
    scene.add(grid);

    // Axes
    const axes = new THREE.AxesHelper(1);
    scene.add(axes);

    const group = new THREE.Group();
    scene.add(group);

    sceneRef.current = scene;
    cameraRef.current = camera;
    rendererRef.current = renderer;
    meshGroupRef.current = group;

    // Animation loop
    const animate = () => {
      animFrameRef.current = requestAnimationFrame(animate);
      if (isRotating && group) {
        group.rotation.y += 0.005;
      }
      renderer.render(scene, camera);
    };
    animate();

    // Resize handler
    const handleResize = () => {
      if (!canvasRef.current) return;
      const w = canvasRef.current.clientWidth;
      const h = canvasRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animFrameRef.current);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (canvasRef.current && renderer.domElement.parentNode === canvasRef.current) {
        canvasRef.current.removeChild(renderer.domElement);
      }
    };
  }, [isRotating]);

  // Load STL into scene
  const loadSTL = useCallback((data: STLData) => {
    if (!meshGroupRef.current) return;

    // Clear previous
    while (meshGroupRef.current.children.length > 0) {
      meshGroupRef.current.remove(meshGroupRef.current.children[0]);
    }

    const geometry = new THREE.BufferGeometry();
    const vertices: number[] = [];
    const normals: number[] = [];

    for (const tri of data.triangles) {
      for (const v of tri.vertices) {
        vertices.push(v[0], v[1], v[2]);
        normals.push(tri.normal[0], tri.normal[1], tri.normal[2]);
      }
    }

    geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));

    const material = new THREE.MeshPhongMaterial({
      color: 0x3b82f6,
      specular: 0x111111,
      shininess: 30,
      side: THREE.DoubleSide,
      flatShading: true,
    });

    const mesh = new THREE.Mesh(geometry, material);

    // Wireframe overlay
    const wireGeo = new THREE.WireframeGeometry(geometry);
    const wireMat = new THREE.LineBasicMaterial({ color: 0x60a5fa, opacity: 0.3, transparent: true });
    const wireframe = new THREE.LineSegments(wireGeo, wireMat);

    meshGroupRef.current.add(mesh);
    meshGroupRef.current.add(wireframe);

    // Center and scale
    const box = new THREE.Box3().setFromObject(meshGroupRef.current);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const maxDim = Math.max(size.x, size.y, size.z);
    const scale = 2 / maxDim;
    meshGroupRef.current.scale.setScalar(scale);
    meshGroupRef.current.position.sub(center.multiplyScalar(scale));

    setViewMode('stl');
  }, []);

  // Load CSV point cloud
  const loadCSV = useCallback((data: CSVData) => {
    if (!meshGroupRef.current) return;

    while (meshGroupRef.current.children.length > 0) {
      meshGroupRef.current.remove(meshGroupRef.current.children[0]);
    }

    const positions: number[] = [];
    const colors: number[] = [];

    const { minTemp, maxTemp } = data.stats;
    const tempRange = maxTemp - minTemp || 1;

    for (const node of data.nodes) {
      positions.push(node.x, node.y, node.z);

      // Temperature color mapping (blue=cold, red=hot)
      const t = (node.temperature - minTemp) / tempRange;
      const r = t;
      const g = 0.2 * (1 - Math.abs(2 * t - 1));
      const b = 1 - t;
      colors.push(r, g, b);
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: 0.05,
      vertexColors: true,
      sizeAttenuation: true,
    });

    const points = new THREE.Points(geometry, material);
    meshGroupRef.current.add(points);

    // Center
    const box = new THREE.Box3().setFromObject(points);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const maxDim = Math.max(size.x, size.y, size.z);
    const scale = 2 / (maxDim || 1);
    meshGroupRef.current.scale.setScalar(scale);
    meshGroupRef.current.position.sub(center.multiplyScalar(scale));

    setViewMode('csv');
  }, []);

  // File upload handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError('');

    const reader = new FileReader();
    reader.onload = (ev) => {
      const content = ev.target?.result as string;
      if (file.name.endsWith('.stl')) {
        const data = parseSTL(content);
        if (data.isValid) {
          setStlData(data);
          loadSTL(data);
        } else {
          setError(data.error || 'Invalid STL file');
        }
      } else if (file.name.endsWith('.csv')) {
        const data = parseTemperatureCSV(content);
        if (data.isValid) {
          setCsvData(data);
          loadCSV(data);
        } else {
          setError(data.error || 'Invalid CSV file');
        }
      } else {
        setError('Unsupported file format. Use .stl or .csv');
      }
    };
    reader.readAsText(file);
  };

  // Load sample data
  const loadSampleSTL = () => {
    const content = generateSampleSTL();
    const data = parseSTL(content);
    if (data.isValid) {
      setStlData(data);
      loadSTL(data);
    }
  };

  const loadSampleCSV = () => {
    const content = generateSampleCSV();
    const data = parseTemperatureCSV(content);
    if (data.isValid) {
      setCsvData(data);
      loadCSV(data);
    }
  };

  // Fit to view
  const fitToView = () => {
    if (!cameraRef.current || !meshGroupRef.current) return;
    cameraRef.current.position.set(2, 1.5, 2);
    cameraRef.current.lookAt(0, 0, 0);
  };

  // Temperature to color for legend
  const tempToColor = (t: number, min: number, max: number): string => {
    const norm = (t - min) / ((max - min) || 1);
    const r = Math.round(norm * 255);
    const b = Math.round((1 - norm) * 255);
    return `rgb(${r}, ${Math.round(50 * (1 - Math.abs(2 * norm - 1)))}, ${b})`;
  };

  return (
    <div className="p-6 h-full flex flex-col fade-in-up">
      {/* Header */}
      <div className="relative mb-4 overflow-hidden rounded-2xl">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-600/20 via-blue-600/10 to-indigo-600/20" />
        <div className="glass p-5 relative border border-[var(--border)] rounded-2xl">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg" style={{ boxShadow: '0 8px 24px rgba(6, 182, 212, 0.4)' }}>
                <Box size={28} className="text-white" />
              </div>
              <div>
                <div className="badge badge-neon-blue mb-1">MODULE B</div>
                <h1 className="text-2xl font-bold">Geometry Lab</h1>
                <p className="text-xs text-[var(--text-secondary)]">
                  STL mesh & CSV point cloud • Three.js WebGL
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <label className="btn-neon cursor-pointer flex items-center gap-2">
                <Upload size={14} />
                <span>Upload File</span>
                <input type="file" accept=".stl,.csv" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>
          </div>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 rounded bg-red-900/20 border border-red-800 text-red-400 text-sm">
          {error}
        </div>
      )}

      <div className="flex-1 flex gap-4 min-h-0">
        {/* 3D Viewer */}
        <div className="flex-1 flex flex-col">
          <div className="flex gap-2 mb-2">
            <button onClick={loadSampleSTL} className="btn-secondary text-xs flex items-center gap-1">
              <Box size={12} /> Sample STL (Cube)
            </button>
            <button onClick={loadSampleCSV} className="btn-secondary text-xs flex items-center gap-1">
              <Eye size={12} /> Sample CSV (Point Cloud)
            </button>
            <button onClick={() => setIsRotating(!isRotating)} className="btn-secondary text-xs flex items-center gap-1">
              <RotateCcw size={12} /> {isRotating ? 'Stop' : 'Rotate'}
            </button>
            <button onClick={fitToView} className="btn-secondary text-xs flex items-center gap-1">
              <Maximize2 size={12} /> Fit View
            </button>
          </div>
          <div ref={canvasRef} className="canvas-container flex-1" />
        </div>

        {/* Info Panel */}
        <div className="w-72 flex flex-col gap-4 overflow-y-auto">
          {/* View mode indicator */}
          <div className="card">
            <h3 className="text-xs font-medium text-[var(--text-secondary)] mb-2">VIEW MODE</h3>
            <span className={`badge ${viewMode === 'stl' ? 'badge-info' : viewMode === 'csv' ? 'badge-success' : 'badge-warning'}`}>
              {viewMode === 'none' ? 'No data loaded' : viewMode === 'stl' ? 'STL Mesh' : 'CSV Point Cloud'}
            </span>
          </div>

          {/* STL Info */}
          {stlData && viewMode === 'stl' && (
            <div className="card">
              <h3 className="text-xs font-medium text-[var(--text-secondary)] mb-2">STL MESH INFO</h3>
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">Name:</span>
                  <span>{stlData.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">Triangles:</span>
                  <span>{stlData.stats.triangleCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">Min bound:</span>
                  <span>{stlData.stats.minBound.map(v => v.toFixed(3)).join(', ')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">Max bound:</span>
                  <span>{stlData.stats.maxBound.map(v => v.toFixed(3)).join(', ')}</span>
                </div>
              </div>
            </div>
          )}

          {/* CSV Info */}
          {csvData && viewMode === 'csv' && (
            <div className="card">
              <h3 className="text-xs font-medium text-[var(--text-secondary)] mb-2">POINT CLOUD INFO</h3>
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">Nodes:</span>
                  <span>{csvData.stats.nodeCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">T min:</span>
                  <span>{csvData.stats.minTemp.toFixed(2)} °C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">T max:</span>
                  <span>{csvData.stats.maxTemp.toFixed(2)} °C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">X range:</span>
                  <span>[{csvData.stats.minBound[0].toFixed(3)}, {csvData.stats.maxBound[0].toFixed(3)}]</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">Y range:</span>
                  <span>[{csvData.stats.minBound[1].toFixed(3)}, {csvData.stats.maxBound[1].toFixed(3)}]</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">Z range:</span>
                  <span>[{csvData.stats.minBound[2].toFixed(3)}, {csvData.stats.maxBound[2].toFixed(3)}]</span>
                </div>
              </div>

              {/* Temperature Legend */}
              <div className="mt-3">
                <div className="text-[10px] text-[var(--text-secondary)] mb-1">Temperature Legend</div>
                <div className="h-3 rounded" style={{
                  background: 'linear-gradient(to right, rgb(0,0,255), rgb(128,50,128), rgb(255,0,0))'
                }} />
                <div className="flex justify-between text-[10px] text-[var(--text-secondary)] mt-0.5">
                  <span>{csvData.stats.minTemp.toFixed(1)} °C</span>
                  <span>{csvData.stats.maxTemp.toFixed(1)} °C</span>
                </div>
              </div>

              {/* Node inspector */}
              {selectedNode && (
                <div className="mt-3 p-2 bg-[var(--bg-primary)] rounded text-xs">
                  <div className="font-medium mb-1">Selected Node #{selectedNode.nodeId}</div>
                  <div>Position: ({selectedNode.x.toFixed(4)}, {selectedNode.y.toFixed(4)}, {selectedNode.z.toFixed(4)})</div>
                  <div>Temperature: {selectedNode.temperature.toFixed(2)} °C</div>
                </div>
              )}

              {/* Warnings */}
              {csvData.warnings.length > 0 && (
                <div className="mt-3">
                  <div className="text-[10px] text-[var(--warning)] mb-1 flex items-center gap-1">
                    <Info size={10} /> Warnings
                  </div>
                  {csvData.warnings.map((w, i) => (
                    <div key={i} className="text-[10px] text-[var(--text-secondary)]">{w}</div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Documentation */}
          <div className="card">
            <h3 className="text-xs font-medium text-[var(--text-secondary)] mb-2">SUPPORTED FORMATS</h3>
            <div className="text-xs text-[var(--text-secondary)] space-y-2">
              <div>
                <strong className="text-[var(--text-primary)]">ASCII STL</strong>
                <p className="mt-0.5">Triangle mesh. Max 50 MB. Validates normals and vertex positions.</p>
              </div>
              <div>
                <strong className="text-[var(--text-primary)]">CSV Temperature</strong>
                <p className="mt-0.5">Schema: node_id,x_m,y_m,z_m,temperature_C. Validates finite values.</p>
              </div>
              <div className="p-2 bg-yellow-900/20 rounded border border-yellow-800/30">
                <p className="text-[10px] text-yellow-400">
                  <strong>Note:</strong> Sample data is synthetically generated for demonstration. 
                  It is NOT actual ANSYS or CAD export data.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
