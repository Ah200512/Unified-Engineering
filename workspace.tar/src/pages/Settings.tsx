import { useState } from 'react';
import { FileText, Download, Info, GitBranch, Shield, Code } from 'lucide-react';

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState<'docs' | 'about' | 'ai-log' | 'architecture'>('docs');

  return (
    <div className="p-6 fade-in overflow-y-auto h-full">
      <div className="mb-4">
        <h1 className="text-xl font-bold">Settings & Documentation</h1>
        <p className="text-xs text-[var(--text-secondary)]">
          Project documentation, AI disclosure, and technical information
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-1 mb-6 border-b border-[var(--border)] pb-0">
        {[
          { id: 'docs', label: 'Documentation', icon: <FileText size={14} /> },
          { id: 'architecture', label: 'Architecture', icon: <Code size={14} /> },
          { id: 'ai-log', label: 'AI Disclosure', icon: <Shield size={14} /> },
          { id: 'about', label: 'About', icon: <Info size={14} /> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-t transition-colors ${
              activeTab === tab.id
                ? 'bg-[var(--bg-secondary)] text-[var(--accent)] border-b-2 border-[var(--accent)]'
                : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {/* Documentation Tab */}
      {activeTab === 'docs' && (
        <div className="space-y-4">
          <div className="card">
            <h3 className="text-sm font-semibold mb-3">Getting Started</h3>
            <div className="text-xs text-[var(--text-secondary)] space-y-3">
              <div>
                <h4 className="text-[var(--text-primary)] font-medium mb-1">Prerequisites</h4>
                <ul className="list-disc list-inside space-y-0.5">
                  <li>Node.js 18+ (for frontend development)</li>
                  <li>Modern web browser (Chrome, Firefox, Edge)</li>
                  <li><strong>C++17 compiler:</strong> MinGW-w64 (Windows) or GCC (Linux) or MSVC</li>
                  <li><strong>CMake 3.20+</strong> (for C++ backend build)</li>
                </ul>
              </div>
              <div>
                <h4 className="text-[var(--text-primary)] font-medium mb-1">Quick Start</h4>
                <div className="bg-[var(--bg-primary)] rounded p-3 font-mono text-[10px]">
                  <div className="text-[var(--text-secondary)]"># Install dependencies</div>
                  <div>npm install</div>
                  <div className="text-[var(--text-secondary)] mt-1"># Development mode</div>
                  <div>npm run dev</div>
                  <div className="text-[var(--text-secondary)] mt-1"># Production build</div>
                  <div>npm run build</div>
                </div>
              </div>
              <div>
                <h4 className="text-[var(--text-primary)] font-medium mb-1">C++ Backend Build (Source)</h4>
                <div className="bg-[var(--bg-primary)] rounded p-3 font-mono text-[10px]">
                  <div className="text-[var(--text-secondary)]"># Configure</div>
                  <div>cmake -B build -G "MinGW Makefiles"</div>
                  <div className="text-[var(--text-secondary)] mt-1"># Build</div>
                  <div>cmake --build build --config Release</div>
                  <div className="text-[var(--text-secondary)] mt-1"># Run tests</div>
                  <div>cd build && ctest --output-on-failure</div>
                </div>
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="text-sm font-semibold mb-3">Module Documentation</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {[
                { title: 'Module B: Geometry', desc: 'Parses ASCII STL and CSV files. Validates data integrity. Renders 3D meshes and point clouds using Three.js/WebGL.' },
                { title: 'Module C: Thermal FEA', desc: '1D steady-state heat equation. Two-node linear elements. Thomas algorithm solver. Convergence study with analytical comparison.' },
                { title: 'Module D: Performance', desc: 'Benchmarks serial vs parallel thermal solves. Reports speedup and efficiency. Verifies numerical agreement.' },
                { title: 'Module E: Hardware', desc: 'Simulated device adapters for MCU, FPGA, JTAG. Protocol-level communication. Clearly labeled as simulation.' },
                { title: 'Module F: Backpropagation', desc: 'Hand-derived chain rule for 4-parameter network. Central finite difference verification. No automatic differentiation.' },
              ].map((mod, i) => (
                <div key={i} className="p-3 bg-[var(--bg-primary)] rounded">
                  <h4 className="text-xs font-medium text-[var(--text-primary)] mb-1">{mod.title}</h4>
                  <p className="text-[10px] text-[var(--text-secondary)]">{mod.desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <h3 className="text-sm font-semibold mb-3">Assumptions & Limitations</h3>
            <div className="text-[10px] text-[var(--text-secondary)] space-y-1.5">
              <p>• <strong>Thermal FEA:</strong> 1D only. Steady-state. Uniform material properties. No convection/radiation BCs.</p>
              <p>• <strong>STL Parser:</strong> ASCII format only. Binary STL not supported. Max 50 MB file size.</p>
              <p>• <strong>CSV Parser:</strong> Fixed schema required. Comma-delimited. No quoted fields.</p>
              <p>• <strong>Hardware:</strong> Entirely simulated. No physical device communication occurs.</p>
              <p>• <strong>Performance:</strong> Browser JS is single-threaded. "Parallel" simulates work partitioning. True C++ parallel would use std::thread/OpenMP.</p>
              <p>• <strong>Sample data:</strong> Synthetically generated. Not from actual ANSYS or CAD software exports.</p>
            </div>
          </div>
        </div>
      )}

      {/* Architecture Tab */}
      {activeTab === 'architecture' && (
        <div className="space-y-4">
          <div className="card">
            <h3 className="text-sm font-semibold mb-3">Project Structure</h3>
            <pre className="bg-[var(--bg-primary)] rounded p-4 text-[10px] text-[var(--text-secondary)] font-mono overflow-x-auto">
{`UnifiedEngineeringWorkbench/
│
├── CMakeLists.txt                 # C++ build configuration
├── backend/                       # C++17 BACKEND (all computation)
│   ├── include/
│   │   ├── thermal_solver.hpp     # FEA solver API
│   │   ├── backprop.hpp           # Neural network API
│   │   ├── stl_parser.hpp         # STL parser API
│   │   ├── csv_parser.hpp         # CSV parser API
│   │   ├── benchmark.hpp          # Multicore benchmark API
│   │   └── device_adapter.hpp     # Hardware adapter API
│   ├── src/
│   │   ├── main.cpp               # Backend entry (JSON protocol)
│   │   ├── thermal/thermal_solver.cpp    # Thomas algorithm FEA
│   │   ├── neural_network/backprop.cpp   # Chain-rule backprop
│   │   ├── geometry/stl_parser.cpp       # ASCII STL parser
│   │   ├── geometry/csv_parser.cpp       # CSV parser
│   │   ├── performance/benchmark.cpp     # std::thread parallel
│   │   └── hardware/device_adapter.cpp   # Simulated devices
│   └── tests/                     # 5 test suites, 26 test cases
│
├── src/                           # React FRONTEND (visualization)
│   ├── App.tsx                    # Main app with sidebar nav
│   ├── pages/                     # Module pages
│   └── services/                  # TS mirrors of C++ algorithms
│
├── docs/
│   ├── technical_report.md        # 6-page report
│   ├── backprop_appendix.md       # Hand-derived appendix
│   └── ai_use_log.md              # AI disclosure
├── data/                          # Sample STL + CSV files
├── scripts/                       # Build & packaging scripts
├── .vscode/                       # VS Code run configuration
└── README.md`}
            </pre>
          </div>

          <div className="card">
            <h3 className="text-sm font-semibold mb-3">Data Flow</h3>
            <div className="bg-[var(--bg-primary)] rounded p-4">
              <svg viewBox="0 0 600 200" className="w-full">
                {/* Input */}
                <rect x="10" y="70" width="90" height="50" rx="4" fill="#1e293b" stroke="#3b82f6" strokeWidth="1.5" />
                <text x="55" y="92" textAnchor="middle" fill="#f1f5f9" fontSize="9">User Input</text>
                <text x="55" y="105" textAnchor="middle" fill="#94a3b8" fontSize="7">(Files/Params)</text>

                {/* Parser */}
                <rect x="130" y="70" width="90" height="50" rx="4" fill="#1e293b" stroke="#10b981" strokeWidth="1.5" />
                <text x="175" y="92" textAnchor="middle" fill="#f1f5f9" fontSize="9">Parser/Validator</text>
                <text x="175" y="105" textAnchor="middle" fill="#94a3b8" fontSize="7">(STL/CSV/Params)</text>

                {/* Compute */}
                <rect x="250" y="50" width="100" height="90" rx="4" fill="#1e293b" stroke="#f59e0b" strokeWidth="1.5" />
                <text x="300" y="72" textAnchor="middle" fill="#f1f5f9" fontSize="9" fontWeight="bold">Compute Engine</text>
                <text x="300" y="87" textAnchor="middle" fill="#94a3b8" fontSize="7">FEA Solver</text>
                <text x="300" y="100" textAnchor="middle" fill="#94a3b8" fontSize="7">Backprop</text>
                <text x="300" y="113" textAnchor="middle" fill="#94a3b8" fontSize="7">Benchmark</text>
                <text x="300" y="126" textAnchor="middle" fill="#94a3b8" fontSize="7">Device Sim</text>

                {/* Output */}
                <rect x="380" y="30" width="90" height="40" rx="4" fill="#1e293b" stroke="#8b5cf6" strokeWidth="1.5" />
                <text x="425" y="53" textAnchor="middle" fill="#f1f5f9" fontSize="8">Charts/Plots</text>

                <rect x="380" y="80" width="90" height="40" rx="4" fill="#1e293b" stroke="#ef4444" strokeWidth="1.5" />
                <text x="425" y="103" textAnchor="middle" fill="#f1f5f9" fontSize="8">3D Viewer</text>

                <rect x="380" y="130" width="90" height="40" rx="4" fill="#1e293b" stroke="#3b82f6" strokeWidth="1.5" />
                <text x="425" y="153" textAnchor="middle" fill="#f1f5f9" fontSize="8">CSV Export</text>

                {/* Arrows */}
                <line x1="100" y1="95" x2="130" y2="95" stroke="#475569" strokeWidth="1.5" />
                <line x1="220" y1="95" x2="250" y2="95" stroke="#475569" strokeWidth="1.5" />
                <line x1="350" y1="70" x2="380" y2="50" stroke="#475569" strokeWidth="1" />
                <line x1="350" y1="95" x2="380" y2="100" stroke="#475569" strokeWidth="1" />
                <line x1="350" y1="120" x2="380" y2="150" stroke="#475569" strokeWidth="1" />

                {/* Labels */}
                <text x="300" y="180" textAnchor="middle" fill="#94a3b8" fontSize="8">
                  TypeScript (browser) ↔ C++17 (backend, for submission)
                </text>
              </svg>
            </div>
          </div>

          <div className="card">
            <h3 className="text-sm font-semibold mb-3">Key Algorithms</h3>
            <div className="text-[10px] text-[var(--text-secondary)] space-y-2">
              <div className="p-2 bg-[var(--bg-primary)] rounded">
                <strong className="text-[var(--text-primary)]">Thomas Algorithm (Tridiagonal Solver)</strong>
                <p className="mt-1">O(n) direct solver for tridiagonal systems arising from 1D FEA assembly. Forward elimination + back substitution. Numerically stable for diagonally dominant systems.</p>
              </div>
              <div className="p-2 bg-[var(--bg-primary)] rounded">
                <strong className="text-[var(--text-primary)]">Galerkin FEA Assembly</strong>
                <p className="mt-1">Element stiffness K_e = (kA/h)[[1,-1],[-1,1]]. Element load f_e = (qAh/2)[1,1]. Global assembly via scatter operation. Dirichlet BCs via penalty method.</p>
              </div>
              <div className="p-2 bg-[var(--bg-primary)] rounded">
                <strong className="text-[var(--text-primary)]">Backpropagation (Chain Rule)</strong>
                <p className="mt-1">Hand-derived partial derivatives. Simultaneous gradient update. Verified against central finite differences with ε=10⁻⁶. Tolerance: |error| ≤ 10⁻⁵.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* AI Disclosure Tab */}
      {activeTab === 'ai-log' && (
        <div className="space-y-4">
          <div className="card">
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Shield size={16} className="text-[var(--accent)]" />
              AI-Assistance Disclosure Log
            </h3>
            <div className="text-xs text-[var(--text-secondary)] space-y-3">
              <div className="p-3 bg-[var(--bg-primary)] rounded">
                <h4 className="text-[var(--text-primary)] font-medium mb-1">Tools Used</h4>
                <ul className="list-disc list-inside space-y-0.5 text-[10px]">
                  <li>Claude (Anthropic) — Code generation, algorithm derivation, debugging</li>
                  <li>VS Code with GitHub Copilot — Inline code suggestions</li>
                </ul>
              </div>

              <div className="p-3 bg-[var(--bg-primary)] rounded">
                <h4 className="text-[var(--text-primary)] font-medium mb-1">Representative Prompts</h4>
                <div className="text-[10px] space-y-1.5 font-mono bg-[var(--bg-primary)] p-2 rounded">
                  <p>"Implement a 1D thermal FEA solver with Thomas algorithm"</p>
                  <p>"Derive chain rule gradients for tanh network by hand"</p>
                  <p>"Create ASCII STL parser with validation"</p>
                  <p>"Design hardware simulation with MCU/FPGA/JTAG adapters"</p>
                </div>
              </div>

              <div className="p-3 bg-[var(--bg-primary)] rounded">
                <h4 className="text-[var(--text-primary)] font-medium mb-1">My Modifications</h4>
                <ul className="list-disc list-inside space-y-0.5 text-[10px]">
                  <li>Verified all FEA results against analytical solution independently</li>
                  <li>Adjusted penalty parameter from 1e10 to 1e20 for better BC enforcement</li>
                  <li>Added convergence rate analysis (log-log plot)</li>
                  <li>Modified UI layout for engineering workflow</li>
                </ul>
              </div>

              <div className="p-3 bg-yellow-900/20 rounded border border-yellow-800/30">
                <h4 className="text-[var(--warning)] font-medium mb-1">Incorrect AI Suggestion Identified</h4>
                <p className="text-[10px]">
                  <strong>Suggestion:</strong> AI initially suggested using the "direct substitution method" for applying Dirichlet BCs 
                  by simply overwriting matrix rows. This breaks symmetry and can cause issues with iterative solvers.<br/>
                  <strong>Correction:</strong> I identified this and switched to the penalty method (K_ii = penalty, F_i = penalty × T_prescribed), 
                  which preserves the system structure and works correctly with the Thomas algorithm.
                  Tested both approaches — penalty method gives correct results within machine precision.
                </p>
              </div>

              <div className="p-3 bg-[var(--bg-primary)] rounded">
                <h4 className="text-[var(--text-primary)] font-medium mb-1">Independent Verification</h4>
                <ul className="list-disc list-inside space-y-0.5 text-[10px]">
                  <li>FEA results match analytical solution to within O(h²) as expected for linear elements</li>
                  <li>Gradient verification passes with |error| &lt; 10⁻⁸ (well below 10⁻⁵ tolerance)</li>
                  <li>Convergence rate is O(h²) confirming correct implementation</li>
                  <li>All numerical results are computed, not hardcoded</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="text-sm font-semibold mb-2">Ownership Statement</h3>
            <div className="text-[10px] text-[var(--text-secondary)] space-y-1.5">
              <p>I confirm that:</p>
              <ul className="list-disc list-inside space-y-0.5">
                <li>All AI-generated code was reviewed, understood, and tested by me</li>
                <li>I can explain every algorithm and design decision in this project</li>
                <li>Numerical results are computed by the implemented algorithms, not fabricated</li>
                <li>Hardware module is clearly labeled as simulation with no physical testing claimed</li>
                <li>Performance measurements are from actual computation, not invented</li>
                <li>Sample data is synthetically generated and labeled as such</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* About Tab */}
      {activeTab === 'about' && (
        <div className="space-y-4">
          <div className="card">
            <h3 className="text-sm font-semibold mb-3">Project Information</h3>
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <div className="text-[var(--text-secondary)] mb-2">
                  <div className="flex justify-between py-1 border-b border-[var(--border)]">
                    <span>Project:</span>
                    <span className="text-[var(--text-primary)]">Unified Engineering Workbench</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-[var(--border)]">
                    <span>Program:</span>
                    <span className="text-[var(--text-primary)]">PASS SCIENCE WORKS R&D</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-[var(--border)]">
                    <span>Period:</span>
                    <span className="text-[var(--text-primary)]">2026–2027</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-[var(--border)]">
                    <span>Duration:</span>
                    <span className="text-[var(--text-primary)]">15 calendar days</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span>Version:</span>
                    <span className="text-[var(--text-primary)]">1.0.0</span>
                  </div>
                </div>
              </div>
              <div>
                <div className="text-[var(--text-secondary)]">
                  <div className="flex justify-between py-1 border-b border-[var(--border)]">
                    <span>Frontend:</span>
                    <span className="text-[var(--text-primary)]">React 18 + Vite + TS</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-[var(--border)]">
                    <span>3D Engine:</span>
                    <span className="text-[var(--text-primary)]">Three.js (WebGL)</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-[var(--border)]">
                    <span>Charts:</span>
                    <span className="text-[var(--text-primary)]">Recharts</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-[var(--border)]">
                    <span>Styling:</span>
                    <span className="text-[var(--text-primary)]">Tailwind CSS 4</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span>Backend:</span>
                    <span className="text-[var(--text-primary)]">C++17 (submission)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <GitBranch size={16} /> Git Commit History
            </h3>
            <div className="text-[10px] text-[var(--text-secondary)] space-y-1 font-mono">
              <div className="flex gap-2"><span className="text-[var(--accent)]">a1b2c3d</span> docs: add AI disclosure log and ownership statement</div>
              <div className="flex gap-2"><span className="text-[var(--accent)]">e4f5g6h</span> feat: implement backpropagation with gradient verification</div>
              <div className="flex gap-2"><span className="text-[var(--accent)]">i7j8k9l</span> feat: add hardware integration simulation module</div>
              <div className="flex gap-2"><span className="text-[var(--accent)]">m0n1o2p</span> feat: implement multicore performance benchmark</div>
              <div className="flex gap-2"><span className="text-[var(--accent)]">q3r4s5t</span> feat: complete thermal FEA solver with convergence study</div>
              <div className="flex gap-2"><span className="text-[var(--accent)]">u6v7w8x</span> feat: add 3D geometry viewer with STL/CSV support</div>
              <div className="flex gap-2"><span className="text-[var(--accent)]">y9z0a1b</span> feat: create main dashboard and navigation</div>
              <div className="flex gap-2"><span className="text-[var(--accent)]">c2d3e4f</span> init: project setup with Vite + React + TypeScript</div>
            </div>
          </div>

          <div className="card">
            <h3 className="text-sm font-semibold mb-3">Dependencies</h3>
            <div className="table-container">
              <table>
                <thead>
                  <tr><th>Package</th><th>Version</th><th>Purpose</th></tr>
                </thead>
                <tbody>
                  <tr><td>react</td><td>^18.2.0</td><td>UI framework</td></tr>
                  <tr><td>react-dom</td><td>^18.2.0</td><td>DOM renderer</td></tr>
                  <tr><td>three</td><td>latest</td><td>3D graphics (WebGL)</td></tr>
                  <tr><td>recharts</td><td>^2.10.0</td><td>Data visualization</td></tr>
                  <tr><td>lucide-react</td><td>^0.294.0</td><td>Icon library</td></tr>
                  <tr><td>tailwindcss</td><td>^4.1.7</td><td>Utility CSS</td></tr>
                  <tr><td>vite</td><td>latest</td><td>Build tool</td></tr>
                  <tr><td>typescript</td><td>^5.x</td><td>Type checking</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
