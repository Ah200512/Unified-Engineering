import { Box, Thermometer, Cpu, CircuitBoard, Brain, ArrowRight, Zap, Activity, Shield } from 'lucide-react';
import { GlassCard, Gauge, StatusLight, Metric } from '../components/UI';

type Page = 'dashboard' | 'geometry' | 'thermal' | 'performance' | 'hardware' | 'neural' | 'settings';

interface Props {
  onNavigate: (page: Page) => void;
}

const modules = [
  {
    id: 'geometry' as Page,
    title: 'Geometry Lab',
    desc: 'STL mesh & CSV point cloud in WebGL',
    icon: <Box size={22} />,
    tag: 'Module B',
    gradient: 'from-cyan-500 to-blue-500',
    accentColor: '#06b6d4',
    className: 'module-geometry',
  },
  {
    id: 'thermal' as Page,
    title: 'Thermal FEA',
    desc: '1D steady-state solver + convergence',
    icon: <Thermometer size={22} />,
    tag: 'Module C',
    gradient: 'from-orange-500 to-red-500',
    accentColor: '#ef4444',
    className: 'module-thermal',
  },
  {
    id: 'performance' as Page,
    title: 'Benchmark',
    desc: 'std::thread multicore analysis',
    icon: <Cpu size={22} />,
    tag: 'Module D',
    gradient: 'from-emerald-500 to-teal-500',
    accentColor: '#10b981',
    className: 'module-perf',
  },
  {
    id: 'hardware' as Page,
    title: 'Hardware Sim',
    desc: 'MCU / FPGA / JTAG adapters',
    icon: <CircuitBoard size={22} />,
    tag: 'Module E',
    gradient: 'from-amber-500 to-pink-500',
    accentColor: '#f59e0b',
    className: 'module-hw',
  },
  {
    id: 'neural' as Page,
    title: 'Neural Net',
    desc: 'Hand-derived backpropagation',
    icon: <Brain size={22} />,
    tag: 'Module F',
    gradient: 'from-purple-500 to-pink-500',
    accentColor: '#a855f7',
    className: 'module-neural',
  },
];

export default function Dashboard({ onNavigate }: Props) {
  return (
    <div className="p-6 max-w-[1600px] mx-auto fade-in-up">
      {/* Hero Section */}
      <div className="relative mb-8 overflow-hidden rounded-2xl">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-purple-600/10 to-pink-600/20" />
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(59, 130, 246, 0.3), transparent 50%), radial-gradient(circle at 80% 80%, rgba(168, 85, 247, 0.2), transparent 50%)'
        }} />
        <div className="relative glass p-8 border border-[var(--border)]">
          <div className="flex items-start justify-between flex-wrap gap-6">
            <div className="flex-1 min-w-[300px]">
              <div className="flex items-center gap-2 mb-3">
                <div className="px-2 py-0.5 rounded-md bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-blue-500/30">
                  <span className="text-[10px] font-bold tracking-widest text-blue-400">PASS SCIENCE WORKS</span>
                </div>
                <div className="px-2 py-0.5 rounded-md bg-black/30 border border-[var(--border)]">
                  <span className="text-[10px] font-mono text-[var(--text-muted)]">R&D 2026–27</span>
                </div>
              </div>
              <h1 className="text-4xl font-bold mb-2">
                <span className="gradient-text">Unified Engineering</span>
                <br />
                <span className="text-white">Workbench</span>
              </h1>
              <p className="text-sm text-[var(--text-secondary)] max-w-xl">
                A modular C++17 engineering platform combining finite element analysis,
                multicore benchmarking, embedded simulation, and neural network training.
              </p>
              <div className="flex items-center gap-3 mt-5">
                <button onClick={() => onNavigate('thermal')} className="btn-neon flex items-center gap-2">
                  <Zap size={14} /> Launch FEA Solver
                </button>
                <button onClick={() => onNavigate('geometry')} className="btn-ghost flex items-center gap-2">
                  Explore Modules <ArrowRight size={14} />
                </button>
              </div>
            </div>

            {/* Gauges */}
            <div className="flex gap-4">
              <Gauge value={100} label="Modules" unit="/5" color="#3b82f6" size={90} />
              <Gauge value={26} label="Tests" unit="✓" color="#10b981" size={90} />
              <Gauge value={100} label="C++17" unit="%" color="#a855f7" size={90} />
            </div>
          </div>
        </div>
      </div>

      {/* System Status Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
        <GlassCard className="p-4">
          <Metric label="Backend" value="C++17" color="var(--neon-blue)" />
          <div className="flex items-center gap-1.5 mt-2">
            <StatusLight status="online" />
            <span className="text-[10px] text-[var(--text-muted)]">Operational</span>
          </div>
        </GlassCard>
        <GlassCard className="p-4">
          <Metric label="Concurrency" value="std::thread" color="var(--neon-green)" />
          <div className="flex items-center gap-1.5 mt-2">
            <StatusLight status="online" />
            <span className="text-[10px] text-[var(--text-muted)]">Active</span>
          </div>
        </GlassCard>
        <GlassCard className="p-4">
          <Metric label="FEA Solver" value="Thomas" color="var(--neon-amber)" />
          <div className="flex items-center gap-1.5 mt-2">
            <StatusLight status="online" />
            <span className="text-[10px] text-[var(--text-muted)]">O(n) complexity</span>
          </div>
        </GlassCard>
        <GlassCard className="p-4">
          <Metric label="Hardware" value="SIM" color="var(--neon-pink)" />
          <div className="flex items-center gap-1.5 mt-2">
            <StatusLight status="warning" />
            <span className="text-[10px] text-[var(--text-muted)]">Simulated only</span>
          </div>
        </GlassCard>
      </div>

      {/* Module Cards */}
      <div className="mb-6 flex items-center justify-between">
        <div className="section-label">Modules</div>
        <div className="text-[10px] text-[var(--text-muted)] font-mono">5 ACTIVE / 6 TOTAL</div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {modules.map((mod, idx) => (
          <button
            key={mod.id}
            onClick={() => onNavigate(mod.id)}
            className={`glass glass-hover module-card ${mod.className} p-5 text-left group`}
            style={{ animationDelay: `${idx * 80}ms` }}
          >
            <div className="flex items-start justify-between mb-4">
              <div
                className={`w-12 h-12 rounded-xl bg-gradient-to-br ${mod.gradient} flex items-center justify-center shadow-lg`}
                style={{ boxShadow: `0 8px 24px ${mod.accentColor}40` }}
              >
                <div className="text-white">{mod.icon}</div>
              </div>
              <div className="badge badge-neon-blue">{mod.tag}</div>
            </div>
            <h3 className="text-base font-bold mb-1 group-hover:gradient-text transition-all">
              {mod.title}
            </h3>
            <p className="text-xs text-[var(--text-secondary)] mb-4">{mod.desc}</p>
            <div className="flex items-center justify-between">
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 rounded-full" style={{ background: mod.accentColor }} />
                <div className="w-1.5 h-1.5 rounded-full bg-[var(--text-muted)]" />
                <div className="w-1.5 h-1.5 rounded-full bg-[var(--text-muted)]" />
              </div>
              <div className="flex items-center gap-1 text-xs opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: mod.accentColor }}>
                Open <ArrowRight size={12} />
              </div>
            </div>
          </button>
        ))}

        {/* Architecture Card */}
        <GlassCard className="p-5 border-dashed">
          <div className="h-full flex flex-col items-center justify-center text-center">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-slate-700 to-slate-900 flex items-center justify-center mb-3">
              <Shield size={22} className="text-[var(--text-muted)]" />
            </div>
            <h3 className="text-sm font-bold mb-1">Full Documentation</h3>
            <p className="text-xs text-[var(--text-secondary)] mb-3">
              Technical report, backprop appendix, AI disclosure
            </p>
            <button onClick={() => onNavigate('settings')} className="btn-ghost text-xs">
              View Docs
            </button>
          </div>
        </GlassCard>
      </div>

      {/* Architecture Overview */}
      <GlassCard className="p-6">
        <div className="section-label mb-4">Architecture</div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)] mb-3">Technology Stack</h4>
            <div className="space-y-2">
              {[
                { label: 'Backend', value: 'C++17 (GCC/MSVC)', color: '#3b82f6' },
                { label: 'Frontend', value: 'React 18 + Vite + TS', color: '#06b6d4' },
                { label: '3D Engine', value: 'Three.js (WebGL)', color: '#a855f7' },
                { label: 'Charts', value: 'Recharts', color: '#10b981' },
                { label: 'Concurrency', value: 'std::thread', color: '#f59e0b' },
                { label: 'Build', value: 'CMake 3.20+', color: '#ec4899' },
              ].map(item => (
                <div key={item.label} className="flex items-center justify-between py-1.5 border-b border-[var(--border)]">
                  <span className="text-xs text-[var(--text-secondary)]">{item.label}</span>
                  <span className="text-xs font-mono font-semibold" style={{ color: item.color }}>{item.value}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)] mb-3">Implemented Algorithms</h4>
            <div className="space-y-2 text-xs">
              {[
                { name: 'Thomas Algorithm', desc: 'O(n) tridiagonal FEA solver' },
                { name: 'Galerkin FEA', desc: '2-node linear element assembly' },
                { name: 'Chain-Rule Backprop', desc: 'Hand-derived 4-param gradient' },
                { name: 'Finite-Diff Verify', desc: 'Central diff, ε=1e-6' },
                { name: 'ASCII STL Parser', desc: 'Validation + bounds tracking' },
                { name: 'CSV Parser', desc: 'Schema + non-finite rejection' },
              ].map(item => (
                <div key={item.name} className="flex items-start gap-2 p-2 rounded-lg bg-black/20">
                  <div className="w-1 h-1 rounded-full bg-[var(--neon-cyan)] mt-1.5 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-[var(--text-primary)]">{item.name}</div>
                    <div className="text-[var(--text-muted)] text-[11px]">{item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </GlassCard>
    </div>
  );
}
