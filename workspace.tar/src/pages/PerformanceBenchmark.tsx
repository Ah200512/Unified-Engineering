import { useState, useCallback } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Play, Info, CheckCircle2, AlertCircle, Cpu } from 'lucide-react';
import { solveThermalCustom } from '../services/thermalSolver';

interface BenchmarkResult {
  workers: number;
  times: number[];
  median: number;
  speedup: number;
  efficiency: number;
}

export default function PerformanceBenchmark() {
  const [caseCount, setCaseCount] = useState(50);
  const [meshSize, setMeshSize] = useState(1000);
  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState<BenchmarkResult[] | null>(null);
  const [verificationPassed, setVerificationPassed] = useState<boolean | null>(null);
  const [progress, setProgress] = useState(0);
  const [systemInfo] = useState({
    platform: navigator.platform,
    cores: navigator.hardwareConcurrency || 'unknown',
    userAgent: navigator.userAgent.substring(0, 60) + '...',
    memory: (navigator as any).deviceMemory || 'unknown',
  });

  // Seeded random number generator (deterministic)
  const seededRandom = (seed: number) => {
    let s = seed;
    return () => {
      s = (s * 1664525 + 1013904223) & 0xffffffff;
      return (s >>> 0) / 0xffffffff;
    };
  };

  // Generate test cases with fixed seed
  const generateCases = useCallback((count: number) => {
    const rng = seededRandom(42); // Fixed seed for reproducibility
    const cases = [];
    for (let i = 0; i < count; i++) {
      cases.push({
        k: 1 + rng() * 50,      // k ∈ [1, 51] W/(m·K)
        q: 1000 + rng() * 50000, // q ∈ [1000, 51000] W/m³
      });
    }
    return cases;
  }, []);

  // Run serial computation
  const runSerial = useCallback((cases: { k: number; q: number }[], N: number): number[][] => {
    const results: number[][] = [];
    for (const c of cases) {
      const T = solveThermalCustom(1.0, 1e-4, c.k, c.q, 100, 20, N);
      results.push(T);
    }
    return results;
  }, []);

  // Run parallel computation (simulated with Web Workers concept)
  // In browser, we simulate parallel by chunking work
  const runParallel = useCallback(async (
    cases: { k: number; q: number }[],
    N: number,
    workers: number,
    onProgress: (p: number) => void
  ): Promise<number[][]> => {
    const results: number[][] = new Array(cases.length);
    const chunkSize = Math.ceil(cases.length / workers);
    
    // Simulate parallel execution with batched async work
    const promises: Promise<void>[] = [];
    
    for (let w = 0; w < workers; w++) {
      const start = w * chunkSize;
      const end = Math.min(start + chunkSize, cases.length);
      
      promises.push(new Promise<void>((resolve) => {
        // Use setTimeout to simulate concurrent execution
        setTimeout(() => {
          for (let i = start; i < end; i++) {
            const c = cases[i];
            results[i] = solveThermalCustom(1.0, 1e-4, c.k, c.q, 100, 20, N);
          }
          resolve();
        }, 0);
      }));
    }

    // Wait for all "workers"
    await Promise.all(promises);
    onProgress(100);
    return results;
  }, []);

  // Measure execution time
  const measureTime = (fn: () => void): number => {
    const start = performance.now();
    fn();
    const end = performance.now();
    return end - start;
  };

  // Run benchmark
  const runBenchmark = async () => {
    setIsRunning(true);
    setResults(null);
    setVerificationPassed(null);
    setProgress(0);

    const cases = generateCases(caseCount);
    const workerCounts = [1, 2, 3, 4].filter(w => w <= (systemInfo.cores as number || 4));
    const repetitions = 5;
    const benchmarkResults: BenchmarkResult[] = [];

    // Warm-up run
    solveThermalCustom(1.0, 1e-4, 10, 10000, 100, 20, 100);

    let serialReference: number[][] = [];

    for (let wIdx = 0; wIdx < workerCounts.length; wIdx++) {
      const workers = workerCounts[wIdx];
      const times: number[] = [];

      for (let rep = 0; rep < repetitions; rep++) {
        const t0 = performance.now();
        if (workers === 1) {
          serialReference = runSerial(cases, meshSize);
        } else {
          await runParallel(cases, meshSize, workers, () => {});
        }
        const t1 = performance.now();
        times.push(t1 - t0);
      }

      // Median time
      const sorted = [...times].sort((a, b) => a - b);
      const median = sorted[Math.floor(sorted.length / 2)];

      const t1_median = benchmarkResults.length > 0 ? benchmarkResults[0].median : median;
      const speedup = t1_median / median;
      const efficiency = speedup / workers;

      benchmarkResults.push({ workers, times, median, speedup, efficiency });
      setProgress(((wIdx + 1) / workerCounts.length) * 100);
    }

    // Verify serial/parallel agreement
    const parallelResult = await runParallel(cases.slice(0, 5), meshSize, 2, () => {});
    const serialResult = runSerial(cases.slice(0, 5), meshSize);
    
    let maxDiff = 0;
    for (let i = 0; i < 5; i++) {
      for (let j = 0; j < serialResult[i].length; j++) {
        maxDiff = Math.max(maxDiff, Math.abs(serialResult[i][j] - parallelResult[i][j]));
      }
    }
    setVerificationPassed(maxDiff < 1e-8);

    setResults(benchmarkResults);
    setIsRunning(false);
  };

  return (
    <div className="p-6 fade-in-up overflow-y-auto h-full">
      {/* Header */}
      <div className="relative mb-6 overflow-hidden rounded-2xl">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-600/20 via-teal-600/10 to-cyan-600/20" />
        <div className="glass p-6 relative border border-[var(--border)] rounded-2xl">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg" style={{ boxShadow: '0 8px 24px rgba(16, 185, 129, 0.4)' }}>
                <Cpu size={28} className="text-white" />
              </div>
              <div>
                <div className="badge badge-neon-green mb-1">MODULE D</div>
                <h1 className="text-2xl font-bold">Multicore Benchmark</h1>
                <p className="text-xs text-[var(--text-secondary)]">
                  std::thread parallelism • Speedup & efficiency analysis
                </p>
              </div>
            </div>
            <button onClick={runBenchmark} disabled={isRunning} className="btn-neon flex items-center gap-2">
              <Play size={14} /> {isRunning ? 'Running...' : 'Run Benchmark'}
            </button>
          </div>
        </div>
      </div>

      {isRunning && (
        <div className="mb-4">
          <div className="flex justify-between text-xs text-[var(--text-secondary)] mb-1">
            <span>Benchmarking...</span>
            <span>{progress.toFixed(0)}%</span>
          </div>
          <div className="progress-bar">
            <div className="progress-bar-fill" style={{ width: `${progress}%` }} />
          </div>
        </div>
      )}

      <div className="grid grid-cols-12 gap-4">
        {/* Configuration */}
        <div className="col-span-3">
          <div className="card mb-4">
            <h3 className="text-xs font-medium text-[var(--text-secondary)] mb-3">CONFIGURATION</h3>
            <div className="space-y-2.5">
              <div>
                <label className="text-[10px] text-[var(--text-secondary)]">Test cases</label>
                <input type="number" className="input-field mt-0.5" value={caseCount}
                  onChange={e => setCaseCount(parseInt(e.target.value) || 50)} min={10} max={500} />
              </div>
              <div>
                <label className="text-[10px] text-[var(--text-secondary)]">Mesh size (N elements)</label>
                <input type="number" className="input-field mt-0.5" value={meshSize}
                  onChange={e => setMeshSize(parseInt(e.target.value) || 1000)} min={100} max={10000} />
              </div>
              <div>
                <label className="text-[10px] text-[var(--text-secondary)]">Repetitions</label>
                <input type="number" className="input-field mt-0.5" value={5} disabled />
              </div>
              <div>
                <label className="text-[10px] text-[var(--text-secondary)]">Random seed</label>
                <input type="number" className="input-field mt-0.5" value={42} disabled />
              </div>
            </div>
          </div>

          <div className="card mb-4">
            <h3 className="text-xs font-medium text-[var(--text-secondary)] mb-2 flex items-center gap-1">
              <Info size={12} /> SYSTEM INFO
            </h3>
            <div className="text-[10px] text-[var(--text-secondary)] space-y-1">
              <div className="flex justify-between">
                <span>Platform:</span>
                <span className="truncate ml-2">{systemInfo.platform}</span>
              </div>
              <div className="flex justify-between">
                <span>Logical cores:</span>
                <span>{systemInfo.cores}</span>
              </div>
              <div className="flex justify-between">
                <span>Memory:</span>
                <span>{systemInfo.memory} GB</span>
              </div>
              <div className="flex justify-between">
                <span>Engine:</span>
                <span>JS (browser)</span>
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="text-xs font-medium text-[var(--text-secondary)] mb-2">METHODOLOGY</h3>
            <div className="text-[10px] text-[var(--text-secondary)] space-y-1">
              <p>• Fixed random seed (42) for reproducibility</p>
              <p>• Varied k ∈ [1,51], q ∈ [1000,51000]</p>
              <p>• 5 repetitions, median reported</p>
              <p>• Warm-up run excluded from timing</p>
              <p>• Speedup = T₁/Tₚ</p>
              <p>• Efficiency = Speedup/p</p>
              <p>• Verification: |T_serial - T_parallel| &lt; 10⁻⁸ °C</p>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="col-span-9">
          {!results ? (
            <div className="card flex items-center justify-center h-96">
              <div className="text-center text-[var(--text-secondary)]">
                <Play size={32} className="mx-auto mb-2 opacity-30" />
                <p className="text-sm">Configure and run the benchmark</p>
                <p className="text-xs mt-1">Tests serial vs parallel execution</p>
              </div>
            </div>
          ) : (
            <>
              {/* Verification Status */}
              {verificationPassed !== null && (
                <div className={`card mb-4 flex items-center gap-3 ${verificationPassed ? 'border-green-800' : 'border-red-800'}`}>
                  {verificationPassed ? (
                    <CheckCircle2 size={20} className="text-[var(--success)]" />
                  ) : (
                    <AlertCircle size={20} className="text-[var(--error)]" />
                  )}
                  <div>
                    <div className="text-sm font-medium">
                      Serial/Parallel Agreement: {verificationPassed ? 'PASSED' : 'FAILED'}
                    </div>
                    <div className="text-xs text-[var(--text-secondary)]">
                      Maximum difference: {verificationPassed ? '< 1e-8 °C' : '> 1e-8 °C'}
                    </div>
                  </div>
                </div>
              )}

              {/* Speedup Chart */}
              <div className="card mb-4">
                <h3 className="text-sm font-semibold mb-3">Speedup & Efficiency</h3>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={results}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="workers" label={{ value: 'Workers (p)', position: 'bottom', offset: -5, style: { fill: '#94a3b8', fontSize: 11 } }} stroke="#94a3b8" />
                    <YAxis yAxisId="left" label={{ value: 'Speedup', angle: -90, position: 'insideLeft', style: { fill: '#94a3b8', fontSize: 11 } }} stroke="#94a3b8" />
                    <YAxis yAxisId="right" orientation="right" label={{ value: 'Efficiency', angle: 90, position: 'insideRight', style: { fill: '#94a3b8', fontSize: 11 } }} stroke="#94a3b8" />
                    <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #475569', borderRadius: 6, fontSize: 11 }} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Bar yAxisId="left" dataKey="speedup" fill="#3b82f6" name="Speedup" radius={[2, 2, 0, 0]} />
                    <Bar yAxisId="right" dataKey="efficiency" fill="#10b981" name="Efficiency" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Timing Chart */}
              <div className="card mb-4">
                <h3 className="text-sm font-semibold mb-3">Execution Time (median)</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={results}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="workers" stroke="#94a3b8" />
                    <YAxis label={{ value: 'Time [ms]', angle: -90, position: 'insideLeft', style: { fill: '#94a3b8', fontSize: 11 } }} stroke="#94a3b8" />
                    <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #475569', borderRadius: 6, fontSize: 11 }}
                      formatter={(v: number) => `${v.toFixed(2)} ms`} />
                    <Line dataKey="median" stroke="#f59e0b" dot={{ fill: '#f59e0b' }} name="Median Time (ms)" />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Results Table */}
              <div className="card">
                <h3 className="text-sm font-semibold mb-3">Detailed Results</h3>
                <div className="table-container">
                  <table>
                    <thead>
                      <tr>
                        <th>Workers (p)</th>
                        <th>Rep 1 [ms]</th>
                        <th>Rep 2 [ms]</th>
                        <th>Rep 3 [ms]</th>
                        <th>Rep 4 [ms]</th>
                        <th>Rep 5 [ms]</th>
                        <th>Median [ms]</th>
                        <th>Speedup</th>
                        <th>Efficiency</th>
                      </tr>
                    </thead>
                    <tbody>
                      {results.map(r => (
                        <tr key={r.workers}>
                          <td className="font-medium">{r.workers}</td>
                          {r.times.map((t, i) => (
                            <td key={i}>{t.toFixed(2)}</td>
                          ))}
                          <td className="font-bold text-[var(--accent)]">{r.median.toFixed(2)}</td>
                          <td className="text-[var(--success)]">{r.speedup.toFixed(3)}</td>
                          <td className="text-[var(--warning)]">{(r.efficiency * 100).toFixed(1)}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Notes */}
              <div className="card mt-4 border-yellow-800/50">
                <h3 className="text-xs font-medium text-[var(--warning)] mb-2">⚠ IMPORTANT: BROWSER VS C++ BACKEND</h3>
                <div className="text-[10px] text-[var(--text-secondary)] space-y-1">
                  <p>• <strong className="text-[var(--text-primary)]">This browser benchmark is a PROTOTYPE.</strong> JavaScript is single-threaded; the "parallel" execution here simulates work partitioning via async batching.</p>
                  <p>• <strong className="text-[var(--text-primary)]">The C++ backend</strong> (<code>backend/src/performance/benchmark.cpp</code>) uses actual <code>std::thread</code> for CPU-level parallelism with real concurrent execution.</p>
                  <p>• <strong className="text-[var(--text-primary)]">For the official submission</strong>, run the C++ backend: <code>cmake --build build && ./build/workbench_backend</code> and issue the <code>BENCHMARK</code> command.</p>
                  <p>• C++ parallel FEA: each worker thread solves an independent partition of test cases with no shared mutable state.</p>
                  <p>• Overhead sources in C++: thread creation, synchronization, cache contention, memory bandwidth.</p>
                  <p>• For small problems, serial may outperform parallel due to overhead dominance (Amdahl's law).</p>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
