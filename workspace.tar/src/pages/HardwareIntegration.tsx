import { useState } from 'react';
import { Wifi, WifiOff, AlertTriangle, Cpu, CircuitBoard, Usb, RefreshCw, Info } from 'lucide-react';

interface DeviceState {
  id: string;
  type: 'mcu' | 'fpga' | 'jtag';
  name: string;
  status: 'disconnected' | 'connecting' | 'connected' | 'error';
  lastTelemetry?: string;
  error?: string;
}

const initialDevices: DeviceState[] = [
  { id: 'mcu-001', type: 'mcu', name: 'STM32F407 Discovery', status: 'disconnected' },
  { id: 'fpga-001', type: 'fpga', name: 'Xilinx Artix-7 (Simulated)', status: 'disconnected' },
  { id: 'jtag-001', type: 'jtag', name: 'SEGGER J-Link EDU', status: 'disconnected' },
];

export default function HardwareIntegration() {
  const [devices, setDevices] = useState<DeviceState[]>(initialDevices);
  const [logs, setLogs] = useState<string[]>(['[System] Hardware simulation module initialized']);

  const addLog = (msg: string) => {
    setLogs(prev => [...prev.slice(-50), `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  const connectDevice = (deviceId: string) => {
    setDevices(prev => prev.map(d =>
      d.id === deviceId ? { ...d, status: 'connecting' } : d
    ));
    addLog(`Connecting to ${deviceId}...`);

    // Simulate connection with potential timeout
    setTimeout(() => {
      const shouldFail = Math.random() < 0.15; // 15% failure rate for realism
      if (shouldFail) {
        setDevices(prev => prev.map(d =>
          d.id === deviceId ? { ...d, status: 'error', error: 'Connection timeout (simulated)' } : d
        ));
        addLog(`⚠ Connection to ${deviceId} timed out (simulated failure)`);
      } else {
        setDevices(prev => prev.map(d =>
          d.id === deviceId ? { ...d, status: 'connected', error: undefined, lastTelemetry: 'OK' } : d
        ));
        addLog(`✓ ${deviceId} connected successfully`);
      }
    }, 1500);
  };

  const disconnectDevice = (deviceId: string) => {
    setDevices(prev => prev.map(d =>
      d.id === deviceId ? { ...d, status: 'disconnected', lastTelemetry: undefined } : d
    ));
    addLog(`Disconnected ${deviceId}`);
  };

  const sendTelemetry = (deviceId: string) => {
    const device = devices.find(d => d.id === deviceId);
    if (device?.status !== 'connected') return;

    const messages: Record<string, string> = {
      'mcu-001': `MCU: CPU=${(30 + Math.random() * 40).toFixed(0)}%, Temp=${(25 + Math.random() * 15).toFixed(1)}°C, Uptime=${(Math.random() * 3600).toFixed(0)}s`,
      'fpga-001': `FPGA: Logic=${(20 + Math.random() * 60).toFixed(0)}%, BRAM=${(10 + Math.random() * 80).toFixed(0)}%, CLK=100MHz`,
      'jtag-001': `JTAG: Target halted at 0x08001234, SWD clock=4MHz, Flash: 1MB`,
    };

    const msg = messages[deviceId] || 'Telemetry N/A';
    setDevices(prev => prev.map(d =>
      d.id === deviceId ? { ...d, lastTelemetry: msg } : d
    ));
    addLog(`${deviceId}: ${msg}`);
  };

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case 'mcu': return <Cpu size={20} />;
      case 'fpga': return <CircuitBoard size={20} />;
      case 'jtag': return <Usb size={20} />;
      default: return <Cpu size={20} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'var(--success)';
      case 'connecting': return 'var(--warning)';
      case 'error': return 'var(--error)';
      default: return 'var(--text-secondary)';
    }
  };

  return (
    <div className="p-6 fade-in-up overflow-y-auto h-full">
      {/* Header */}
      <div className="relative mb-6 overflow-hidden rounded-2xl">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-600/20 via-pink-600/10 to-orange-600/20" />
        <div className="glass p-6 relative border border-[var(--border)] rounded-2xl">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500 to-pink-600 flex items-center justify-center shadow-lg" style={{ boxShadow: '0 8px 24px rgba(245, 158, 11, 0.4)' }}>
                <CircuitBoard size={28} className="text-white" />
              </div>
              <div>
                <div className="badge badge-neon-amber mb-1">MODULE E</div>
                <h1 className="text-2xl font-bold">Hardware Integration</h1>
                <p className="text-xs text-[var(--text-secondary)]">
                  MCU / FPGA / JTAG adapters • Protocol simulation
                </p>
              </div>
            </div>
            <span className="badge badge-neon-amber flex items-center gap-1">
              <AlertTriangle size={12} /> SIMULATED — No Physical Hardware
            </span>
          </div>
        </div>
      </div>

      {/* Block Diagram */}
      <div className="card mb-4">
        <h3 className="text-sm font-semibold mb-3">System Block Diagram</h3>
        <div className="bg-[var(--bg-primary)] rounded-lg p-6 overflow-x-auto">
          <svg viewBox="0 0 800 280" className="w-full max-w-3xl mx-auto" style={{ minWidth: 600 }}>
            {/* Host PC */}
            <rect x="20" y="100" width="120" height="60" rx="4" fill="#1e293b" stroke="#3b82f6" strokeWidth="2" />
            <text x="80" y="125" textAnchor="middle" fill="#f1f5f9" fontSize="11" fontWeight="bold">Host PC</text>
            <text x="80" y="142" textAnchor="middle" fill="#94a3b8" fontSize="9">Windows 11 x64</text>

            {/* USB/SWD connections */}
            <line x1="140" y1="120" x2="220" y2="80" stroke="#3b82f6" strokeWidth="1.5" strokeDasharray="4 2" />
            <line x1="140" y1="130" x2="220" y2="130" stroke="#10b981" strokeWidth="1.5" strokeDasharray="4 2" />
            <line x1="140" y1="140" x2="220" y2="180" stroke="#f59e0b" strokeWidth="1.5" strokeDasharray="4 2" />

            {/* JTAG Adapter */}
            <rect x="220" y="155" width="130" height="55" rx="4" fill="#1e293b" stroke="#f59e0b" strokeWidth="2" />
            <text x="285" y="177" textAnchor="middle" fill="#f1f5f9" fontSize="10" fontWeight="bold">JTAG Adapter</text>
            <text x="285" y="193" textAnchor="middle" fill="#94a3b8" fontSize="8">SEGGER J-Link</text>
            <text x="285" y="204" textAnchor="middle" fill="#94a3b8" fontSize="7">SWD: SWCLK, SWDIO</text>

            {/* MCU */}
            <rect x="420" y="55" width="150" height="65" rx="4" fill="#1e293b" stroke="#3b82f6" strokeWidth="2" />
            <text x="495" y="77" textAnchor="middle" fill="#f1f5f9" fontSize="10" fontWeight="bold">MCU (STM32F407)</text>
            <text x="495" y="92" textAnchor="middle" fill="#94a3b8" fontSize="8">ARM Cortex-M4, 168MHz</text>
            <text x="495" y="105" textAnchor="middle" fill="#94a3b8" fontSize="7">3.3V domain, 1MB Flash</text>

            {/* FPGA */}
            <rect x="420" y="140" width="150" height="65" rx="4" fill="#1e293b" stroke="#10b981" strokeWidth="2" />
            <text x="495" y="162" textAnchor="middle" fill="#f1f5f9" fontSize="10" fontWeight="bold">FPGA (Artix-7)</text>
            <text x="495" y="177" textAnchor="middle" fill="#94a3b8" fontSize="8">Xilinx, 100MHz CLK</text>
            <text x="495" y="190" textAnchor="middle" fill="#94a3b8" fontSize="7">1.0V core, 3.3V I/O</text>

            {/* JTAG connections to targets */}
            <line x1="350" y1="170" x2="420" y2="90" stroke="#f59e0b" strokeWidth="1.5" />
            <line x1="350" y1="185" x2="420" y2="170" stroke="#f59e0b" strokeWidth="1.5" />
            <text x="385" y="115" fill="#f59e0b" fontSize="7" transform="rotate(-25, 385, 115)">JTAG/SWD</text>
            <text x="385" y="185" fill="#f59e0b" fontSize="7">JTAG</text>

            {/* UART between MCU and FPGA */}
            <line x1="495" y1="120" x2="495" y2="140" stroke="#8b5cf6" strokeWidth="1.5" />
            <text x="510" y="133" fill="#8b5cf6" fontSize="7">UART/TX-RX</text>

            {/* Power supply */}
            <rect x="640" y="90" width="100" height="80" rx="4" fill="#1e293b" stroke="#ef4444" strokeWidth="1.5" />
            <text x="690" y="115" textAnchor="middle" fill="#f1f5f9" fontSize="9" fontWeight="bold">Power Supply</text>
            <text x="690" y="130" textAnchor="middle" fill="#94a3b8" fontSize="7">5V USB → 3.3V LDO</text>
            <text x="690" y="142" textAnchor="middle" fill="#94a3b8" fontSize="7">3.3V → 1.0V (FPGA)</text>
            <text x="690" y="154" textAnchor="middle" fill="#94a3b8" fontSize="7">Common GND</text>

            <line x1="570" y1="85" x2="640" y2="110" stroke="#ef4444" strokeWidth="1" strokeDasharray="3 2" />
            <line x1="570" y1="170" x2="640" y2="145" stroke="#ef4444" strokeWidth="1" strokeDasharray="3 2" />

            {/* Level shifter note */}
            <rect x="580" y="210" width="140" height="40" rx="4" fill="#1e293b" stroke="#475569" strokeWidth="1" strokeDasharray="3 2" />
            <text x="650" y="228" textAnchor="middle" fill="#94a3b8" fontSize="8">Level Shifter (if needed)</text>
            <text x="650" y="240" textAnchor="middle" fill="#94a3b8" fontSize="7">3.3V ↔ 1.0V FPGA I/O</text>

            {/* Legend */}
            <text x="20" y="260" fill="#94a3b8" fontSize="8">
              ─── Signal path  --- Debug/Config  ··· Power
            </text>
          </svg>
        </div>
      </div>

      {/* Device Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        {devices.map(device => (
          <div key={device.id} className="card">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg" style={{
                background: `${getStatusColor(device.status)}20`,
                color: getStatusColor(device.status)
              }}>
                {getDeviceIcon(device.type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{device.name}</div>
                <div className="text-[10px] text-[var(--text-secondary)]">{device.id}</div>
              </div>
              <div className="w-2 h-2 rounded-full" style={{ background: getStatusColor(device.status) }} />
            </div>

            {/* Capabilities */}
            <div className="text-[10px] text-[var(--text-secondary)] mb-3 space-y-0.5">
              {device.type === 'mcu' && (
                <>
                  <div>• ARM Cortex-M4, 168 MHz</div>
                  <div>• 1MB Flash, 192KB SRAM</div>
                  <div>• GPIO, ADC, SPI, I2C, UART</div>
                  <div>• Operating voltage: 3.3V</div>
                </>
              )}
              {device.type === 'fpga' && (
                <>
                  <div>• 100K logic cells (simulated)</div>
                  <div>• 4.9 Mb Block RAM</div>
                  <div>• 100 MHz system clock</div>
                  <div>• Core: 1.0V, I/O: 3.3V</div>
                </>
              )}
              {device.type === 'jtag' && (
                <>
                  <div>• Debug interface (NOT a compute board)</div>
                  <div>• SWD: SWCLK + SWDIO</div>
                  <div>• JTAG: TCK, TMS, TDI, TDO, TRST</div>
                  <div>• Max SWD clock: 50 MHz</div>
                </>
              )}
            </div>

            {/* Telemetry */}
            {device.lastTelemetry && (
              <div className="p-2 bg-[var(--bg-primary)] rounded text-[10px] text-[var(--text-secondary)] mb-3">
                {device.lastTelemetry}
              </div>
            )}

            {device.error && (
              <div className="p-2 bg-red-900/20 rounded text-[10px] text-red-400 mb-3">
                {device.error}
              </div>
            )}

            {/* Controls */}
            <div className="flex gap-2">
              {device.status === 'disconnected' || device.status === 'error' ? (
                <button onClick={() => connectDevice(device.id)} className="btn-primary text-xs flex-1 flex items-center justify-center gap-1">
                  <Wifi size={12} /> Connect
                </button>
              ) : device.status === 'connecting' ? (
                <button disabled className="btn-secondary text-xs flex-1 flex items-center justify-center gap-1">
                  <RefreshCw size={12} className="animate-spin" /> Connecting...
                </button>
              ) : (
                <>
                  <button onClick={() => sendTelemetry(device.id)} className="btn-secondary text-xs flex-1 flex items-center justify-center gap-1">
                    <Info size={12} /> Telemetry
                  </button>
                  <button onClick={() => disconnectDevice(device.id)} className="btn-secondary text-xs flex items-center justify-center gap-1">
                    <WifiOff size={12} />
                  </button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Pin/Voltage Table */}
      <div className="card mb-4">
        <h3 className="text-sm font-semibold mb-3">Interface & Pin-Voltage Table</h3>
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Interface</th>
                <th>Signal</th>
                <th>Direction</th>
                <th>Voltage</th>
                <th>Connector</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>
              <tr><td>SWD</td><td>SWCLK</td><td>→ Target</td><td>3.3V</td><td>10-pin ARM</td><td>JTAG adapter drives clock</td></tr>
              <tr><td>SWD</td><td>SWDIO</td><td>Bidir</td><td>3.3V</td><td>10-pin ARM</td><td>Serial wire data</td></tr>
              <tr><td>JTAG</td><td>TCK</td><td>→ Target</td><td>3.3V</td><td>20-pin ARM</td><td>Test clock</td></tr>
              <tr><td>JTAG</td><td>TMS</td><td>→ Target</td><td>3.3V</td><td>20-pin ARM</td><td>Test mode select</td></tr>
              <tr><td>JTAG</td><td>TDI</td><td>→ Target</td><td>3.3V</td><td>20-pin ARM</td><td>Test data in</td></tr>
              <tr><td>JTAG</td><td>TDO</td><td>← Target</td><td>3.3V</td><td>20-pin ARM</td><td>Test data out</td></tr>
              <tr><td>UART</td><td>TX/RX</td><td>Bidir</td><td>3.3V</td><td>Header</td><td>MCU ↔ FPGA comms</td></tr>
              <tr><td>Power</td><td>VCC</td><td>→ Target</td><td>3.3V/5V</td><td>USB/Barrel</td><td>From host or supply</td></tr>
              <tr><td>Power</td><td>GND</td><td>Common</td><td>0V</td><td>All</td><td>Common ground reference</td></tr>
              <tr><td>FPGA Core</td><td>VCCINT</td><td>→ FPGA</td><td>1.0V</td><td>On-board LDO</td><td>Internal logic only</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Activity Log */}
      <div className="card">
        <h3 className="text-sm font-semibold mb-3">Activity Log</h3>
        <div className="bg-[var(--bg-primary)] rounded p-3 max-h-40 overflow-y-auto font-mono text-[10px] text-[var(--text-secondary)]">
          {logs.map((log, i) => (
            <div key={i} className="py-0.5">{log}</div>
          ))}
        </div>
      </div>

      {/* Important Notes */}
      <div className="card mt-4 border-yellow-800/50">
        <h3 className="text-xs font-medium text-[var(--warning)] mb-2 flex items-center gap-1">
          <AlertTriangle size={12} /> IMPORTANT NOTES
        </h3>
        <div className="text-[10px] text-[var(--text-secondary)] space-y-1.5">
          <p>• <strong>All behavior is simulated.</strong> No physical hardware is connected or tested.</p>
          <p>• <strong>JTAG is a debug interface</strong>, not an interchangeable compute board. It provides access to the target's internal state (registers, memory, breakpoints) via IEEE 1149.1 standard signals. It does not execute user code independently.</p>
          <p>• <strong>Voltage domains must match.</strong> The FPGA core runs at 1.0V while I/O uses 3.3V. A level shifter is required if connecting 3.3V MCU GPIO directly to FPGA core-voltage pins.</p>
          <p>• <strong>Pin assignments are device-specific.</strong> Actual pinouts depend on the specific board revision and FPGA package. Refer to manufacturer documentation for real hardware.</p>
          <p>• <strong>Power and grounding:</strong> All devices share a common ground. Power sequencing matters for FPGA (core before I/O).</p>
        </div>
      </div>
    </div>
  );
}
