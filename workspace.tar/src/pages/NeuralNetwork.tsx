import { useState, useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Play, CheckCircle2, XCircle, BookOpen, Brain } from 'lucide-react';
import {
  train, verifyGradients, getFirstStepDerivation,
  INITIAL_PARAMS, X_INPUT, Y_TARGET, LEARNING_RATE
} from '../services/backpropagation';
import type { TrainingStep } from '../services/backpropagation';

export default function NeuralNetwork() {
  const [history, setHistory] = useState<TrainingStep[] | null>(null);
  const [showDerivation, setShowDerivation] = useState(false);
  const [showVerification, setShowVerification] = useState(false);
  const [numSteps, setNumSteps] = useState(100);

  const verificationResults = useMemo(() => {
    return verifyGradients(X_INPUT, Y_TARGET, INITIAL_PARAMS, 1e-6);
  }, []);

  const allGradientsPassed = verificationResults.every(r => r.passed);

  const runTraining = () => {
    const result = train(X_INPUT, Y_TARGET, INITIAL_PARAMS, LEARNING_RATE, numSteps);
    setHistory(result);
  };

  const derivation = useMemo(() => getFirstStepDerivation(), []);

  // Chart data
  const chartData = useMemo(() => {
    if (!history) return [];
    return history.map(step => ({
      step: step.step,
      loss: step.loss,
      w: step.w,
      b: step.b,
      v: step.v,
      c: step.c,
      y_hat: step.y_hat,
    }));
  }, [history]);

  const paramNames = ['w', 'b', 'v', 'c'] as const;
  const paramColors: Record<string, string> = { w: '#3b82f6', b: '#10b981', v: '#f59e0b', c: '#ef4444' };

  return (
    <div className="p-6 fade-in-up overflow-y-auto h-full">
      {/* Header */}
      <div className="relative mb-6 overflow-hidden rounded-2xl">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 via-pink-600/10 to-violet-600/20" />
        <div className="glass p-6 relative border border-[var(--border)] rounded-2xl">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center shadow-lg" style={{ boxShadow: '0 8px 24px rgba(168, 85, 247, 0.4)' }}>
                <Brain size={28} className="text-white" />
              </div>
              <div>
                <div className="badge badge-neon-purple mb-1">MODULE F</div>
                <h1 className="text-2xl font-bold">Handwritten Backpropagation</h1>
                <p className="text-xs text-[var(--text-secondary)]">
                  Chain-rule derivatives • Finite-difference verification • No autodiff
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => setShowDerivation(!showDerivation)} className="btn-ghost flex items-center gap-2">
                <BookOpen size={14} /> {showDerivation ? 'Hide' : 'Show'} Derivation
              </button>
              <button onClick={runTraining} className="btn-neon flex items-center gap-2">
                <Play size={14} /> Train {numSteps} Steps
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Network Architecture */}
      <div className="grid grid-cols-12 gap-4">
        <div className="col-span-4">
          {/* Architecture Card */}
          <div className="card mb-4">
            <h3 className="text-xs font-medium text-[var(--text-secondary)] mb-3">NETWORK ARCHITECTURE</h3>
            <div className="bg-[var(--bg-primary)] rounded p-4 text-center">
              <svg viewBox="0 0 300 200" className="w-full max-w-xs mx-auto">
                {/* Input */}
                <circle cx="50" cy="100" r="20" fill="#1e293b" stroke="#3b82f6" strokeWidth="2" />
                <text x="50" y="97" textAnchor="middle" fill="#f1f5f9" fontSize="10">x</text>
                <text x="50" y="110" textAnchor="middle" fill="#94a3b8" fontSize="8">= {X_INPUT}</text>

                {/* Hidden */}
                <circle cx="150" cy="100" r="20" fill="#1e293b" stroke="#10b981" strokeWidth="2" />
                <text x="150" y="97" textAnchor="middle" fill="#f1f5f9" fontSize="9">tanh</text>
                <text x="150" y="110" textAnchor="middle" fill="#94a3b8" fontSize="7">(wx+b)</text>

                {/* Output */}
                <circle cx="250" cy="100" r="20" fill="#1e293b" stroke="#f59e0b" strokeWidth="2" />
                <text x="250" y="97" textAnchor="middle" fill="#f1f5f9" fontSize="8">ŷ=vh+c</text>
                <text x="250" y="110" textAnchor="middle" fill="#94a3b8" fontSize="7">target={Y_TARGET}</text>

                {/* Connections */}
                <line x1="70" y1="100" x2="130" y2="100" stroke="#475569" strokeWidth="1.5" markerEnd="url(#arrow)" />
                <line x1="170" y1="100" x2="230" y2="100" stroke="#475569" strokeWidth="1.5" markerEnd="url(#arrow)" />

                {/* Parameters */}
                <text x="100" y="70" textAnchor="middle" fill="#3b82f6" fontSize="8">w={INITIAL_PARAMS.w}, b={INITIAL_PARAMS.b}</text>
                <text x="200" y="70" textAnchor="middle" fill="#f59e0b" fontSize="8">v={INITIAL_PARAMS.v}, c={INITIAL_PARAMS.c}</text>

                {/* Loss */}
                <rect x="110" y="155" width="80" height="25" rx="4" fill="#1e293b" stroke="#ef4444" strokeWidth="1.5" />
                <text x="150" y="171" textAnchor="middle" fill="#ef4444" fontSize="8">J = ½(ŷ-y)²</text>
                <line x1="150" y1="120" x2="150" y2="155" stroke="#475569" strokeWidth="1" strokeDasharray="3 2" />

                <defs>
                  <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                    <path d="M 0 0 L 10 5 L 0 10 z" fill="#475569" />
                  </marker>
                </defs>
              </svg>
            </div>
            <div className="mt-3 text-[10px] text-[var(--text-secondary)] space-y-1">
              <div className="flex justify-between">
                <span>Learning rate (η):</span>
                <span className="font-mono">{LEARNING_RATE}</span>
              </div>
              <div className="flex justify-between">
                <span>Training steps:</span>
                <input
                  type="number"
                  value={numSteps}
                  onChange={e => setNumSteps(parseInt(e.target.value) || 100)}
                  className="w-16 bg-[var(--bg-primary)] border border-[var(--border)] rounded px-1 text-right text-[var(--text-primary)]"
                  min={1}
                  max={1000}
                />
              </div>
            </div>
          </div>

          {/* Gradient Verification */}
          <div className="card mb-4">
            <h3 className="text-xs font-medium text-[var(--text-secondary)] mb-2 flex items-center gap-1">
              GRADIENT VERIFICATION (ε=10⁻⁶)
            </h3>
            <div className="space-y-2">
              {verificationResults.map((r, i) => (
                <div key={i} className="flex items-center gap-2 text-[10px]">
                  {r.passed ? <CheckCircle2 size={12} className="text-[var(--success)]" /> : <XCircle size={12} className="text-[var(--error)]" />}
                  <span className="font-mono w-8">∂J/∂{paramNames[i]}</span>
                  <span className="text-[var(--text-secondary)]">
                    anal={r.analytical.toFixed(6)}, num={r.numerical.toFixed(6)}
                  </span>
                  <span className={`ml-auto ${r.passed ? 'text-[var(--success)]' : 'text-[var(--error)]'}`}>
                    err={r.error.toExponential(2)}
                  </span>
                </div>
              ))}
            </div>
            <div className={`mt-2 text-[10px] font-medium ${allGradientsPassed ? 'text-[var(--success)]' : 'text-[var(--error)]'}`}>
              {allGradientsPassed ? '✓ All gradients verified (error ≤ 10⁻⁵)' : '✗ Gradient verification FAILED'}
            </div>
          </div>

          {/* Initial State */}
          <div className="card">
            <h3 className="text-xs font-medium text-[var(--text-secondary)] mb-2">INITIAL PARAMETERS</h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {paramNames.map(p => (
                <div key={p} className="p-2 bg-[var(--bg-primary)] rounded">
                  <span className="text-[var(--text-secondary)]">{p} = </span>
                  <span className="font-mono font-bold" style={{ color: paramColors[p] }}>
                    {INITIAL_PARAMS[p]}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="col-span-8">
          {!history ? (
            <div className="card flex items-center justify-center h-96">
              <div className="text-center text-[var(--text-secondary)]">
                <Play size={32} className="mx-auto mb-2 opacity-30" />
                <p className="text-sm">Click "Train" to run gradient descent</p>
                <p className="text-xs mt-1">Loss will decrease over training steps</p>
              </div>
            </div>
          ) : (
            <>
              {/* Loss Chart */}
              <div className="card mb-4">
                <h3 className="text-sm font-semibold mb-3">Loss Over Training Steps</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="step" label={{ value: 'Step', position: 'bottom', offset: -5, style: { fill: '#94a3b8', fontSize: 11 } }} stroke="#94a3b8" />
                    <YAxis label={{ value: 'J (loss)', angle: -90, position: 'insideLeft', style: { fill: '#94a3b8', fontSize: 11 } }} stroke="#94a3b8" />
                    <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #475569', borderRadius: 6, fontSize: 11 }} />
                    <Line dataKey="loss" stroke="#ef4444" dot={false} strokeWidth={2} name="Loss J" />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Parameter Evolution */}
              <div className="card mb-4">
                <h3 className="text-sm font-semibold mb-3">Parameter Evolution</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="step" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" />
                    <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #475569', borderRadius: 6, fontSize: 11 }} />
                    {paramNames.map(p => (
                      <Line key={p} dataKey={p} stroke={paramColors[p]} dot={false} strokeWidth={1.5} name={p} />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Training History Table */}
              <div className="card">
                <h3 className="text-sm font-semibold mb-3">Training History (first 10 + last 5 steps)</h3>
                <div className="table-container max-h-64 overflow-y-auto">
                  <table>
                    <thead>
                      <tr>
                        <th>Step</th>
                        <th>w</th>
                        <th>b</th>
                        <th>v</th>
                        <th>c</th>
                        <th>ŷ</th>
                        <th>Loss</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[...history.slice(0, 10), ...history.slice(-5)].map((step, i) => (
                        <tr key={`${step.step}-${i}`} className={i === 10 ? 'border-t-2 border-[var(--border)]' : ''}>
                          <td className="font-medium">{step.step}</td>
                          <td style={{ color: paramColors.w }}>{step.w.toFixed(6)}</td>
                          <td style={{ color: paramColors.b }}>{step.b.toFixed(6)}</td>
                          <td style={{ color: paramColors.v }}>{step.v.toFixed(6)}</td>
                          <td style={{ color: paramColors.c }}>{step.c.toFixed(6)}</td>
                          <td>{step.y_hat.toFixed(6)}</td>
                          <td className="text-[var(--error)]">{step.loss.toFixed(6)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-3 text-[10px] text-[var(--text-secondary)]">
                  <strong>Final state:</strong> ŷ = {history[history.length - 1].y_hat.toFixed(4)}, 
                  Loss = {history[history.length - 1].loss.toFixed(6)}, 
                  Target y = {Y_TARGET}
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Derivation Panel */}
      {showDerivation && (
        <div className="card mt-4 fade-in">
          <h3 className="text-sm font-semibold mb-3">Step-by-Step Derivation (First Training Step)</h3>
          <pre className="bg-[var(--bg-primary)] rounded p-4 text-[11px] text-[var(--text-secondary)] overflow-x-auto whitespace-pre-wrap font-mono leading-relaxed">
            {derivation}
          </pre>
          <div className="mt-3 p-3 bg-blue-900/20 rounded border border-blue-800/30">
            <h4 className="text-xs font-medium text-blue-400 mb-1">Gradient Direction Explanation</h4>
            <div className="text-[10px] text-[var(--text-secondary)] space-y-1">
              <p>• <strong>∂J/∂w &lt; 0:</strong> Increasing w decreases loss → gradient descent increases w (moves toward target)</p>
              <p>• <strong>∂J/∂c &lt; 0:</strong> Output needs to increase to reach y=2 → c increases</p>
              <p>• <strong>∂J/∂v &lt; 0:</strong> Scaling factor v needs to increase to amplify hidden activation toward target</p>
              <p>• <strong>∂J/∂b:</strong> Bias shift depends on tanh operating point; near zero input, tanh is approximately linear</p>
              <p className="pt-1 border-t border-blue-800/30">
                The simultaneous update ensures all four parameters are adjusted using gradients computed from the SAME forward pass,
                preventing information leakage between parameter updates within a single step.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
