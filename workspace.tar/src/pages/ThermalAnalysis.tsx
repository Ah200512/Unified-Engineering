import { useState, useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Play, Download, Info, Flame, Activity } from 'lucide-react';
import { solveThermalFEA, convergenceStudy, exportResultsCSV, analyticalSolution, DEFAULT_PARAMS } from '../services/thermalSolver';
import type { ThermalParams, ThermalResult } from '../services/thermalSolver';
import { GlassCard, Gauge, StatusLight, Metric } from '../components/UI';

export default function ThermalAnalysis() {
  const [params, setParams] = useState<ThermalParams>(DEFAULT_PARAMS);
  const [meshSizes, setMeshSizes] = useState<number[]>([10, 20, 40, 80]);
  const [results, setResults] = useState<ThermalResult[] | null>(null);
  const [selectedMesh, setSelectedMesh] = useState<number>(40);
  const [isComputing, setIsComputing] = useState(false);

  const runSolver = () => {
    setIsComputing(true);
    // Use setTimeout to allow UI to update
    setTimeout(() => {
      const res = convergenceStudy(params, meshSizes);
      setResults(res);
      setIsComputing(false);
    }, 50);
  };

  const currentResult = useMemo(() => {
    if (!results) return null;
    return results.find(r => r.N === selectedMesh) || results[results.length - 1];
  }, [results, selectedMesh]);

  // Chart data for temperature profiles
  const profileData = useMemo(() => {
    if (!results) return [];
    const data: Record<string, number>[] = [];
    const maxNodes = Math.max(...results.map(r => r.nodes.length));
    
    for (let i = 0; i < maxNodes; i++) {
      const point: Record<string, number> = {};
      for (const r of results) {
        if (i < r.nodes.length) {
          point.x = r.nodes[i];
          point[`N=${r.N}`] = parseFloat(r.temperatures[i].toFixed(4));
        }
      }
      // Add exact solution
      if (point.x !== undefined) {
        point['Exact'] = parseFloat(analyticalSolution(point.x, params).toFixed(4));
      }
      if (point.x !== undefined) data.push(point);
    }
    return data;
  }, [results, params]);

  // Convergence data
  const convergenceData = useMemo(() => {
    if (!results) return [];
    return results.map(r => ({
      N: r.N,
      h: r.h,
      maxError: r.maxError,
      logH: Math.log10(r.h),
      logError: Math.log10(Math.max(r.maxError, 1e-16)),
    }));
  }, [results]);

  // Detailed node data for selected mesh
  const nodeData = useMemo(() => {
    if (!currentResult) return [];
    return currentResult.nodes.map((x, i) => ({
      node: i,
      x: parseFloat(x.toFixed(4)),
      T_FE: parseFloat(currentResult.temperatures[i].toFixed(4)),
      T_exact: parseFloat(currentResult.exactTemperatures[i].toFixed(4)),
      error: parseFloat(currentResult.errors[i].toExponential(3)),
    }));
  }, [currentResult]);

  const handleExport = () => {
    if (!results) return;
    const csv = exportResultsCSV(results, params);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'thermal_fea_results.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const updateParam = (key: keyof ThermalParams, value: string) => {
    const num = parseFloat(value);
    if (!isNaN(num)) {
      setParams(prev => ({ ...prev, [key]: num }));
    }
  };

  const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <div className="p-6 fade-in-up overflow-y-auto h-full">
      {/* Header */}
      <div className="relative mb-6 overflow-hidden rounded-2xl">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-600/20 via-red-600/10 to-amber-600/20" />
        <GlassCard className="p-6 relative">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center shadow-lg" style={{ boxShadow: '0 8px 24px rgba(239, 68, 68, 0.4)' }}>
                <Flame size={28} className="text-white" />
              </div>
              <div>
                <div className="badge badge-neon-amber mb-1">MODULE C</div>
                <h1 className="text-2xl font-bold">Thermal FEA Solver</h1>
                <p className="text-xs text-[var(--text-secondary)]">
                  1D steady-state • Thomas algorithm • O(h²) convergence
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={runSolver} disabled={isComputing} className="btn-neon flex items-center gap-2">
                <Play size={14} /> {isComputing ? 'Computing...' : 'Run Solver'}
              </button>
              {results && (
                <button onClick={handleExport} className="btn-ghost flex items-center gap-2">
                  <Download size={14} /> Export CSV
                </button>
              )}
            </div>
          </div>
        </GlassCard>
      </div>

      <div className="grid grid-cols-12 gap-4">
        {/* Parameters Panel */}
        <div className="col-span-3">
          <GlassCard className="p-4 mb-4">
            <div className="section-label mb-3">Problem Parameters</div>
            <div className="space-y-2.5">
              <div>
                <label className="text-[10px] text-[var(--text-secondary)]">L (domain length) [m]</label>
                <input type="number" className="input-neon mt-0.5" value={params.L}
                  onChange={e => updateParam('L', e.target.value)} step="0.1" />
              </div>
              <div>
                <label className="text-[10px] text-[var(--text-secondary)]">A (cross-section) [m²]</label>
                <input type="number" className="input-neon mt-0.5" value={params.A}
                  onChange={e => updateParam('A', e.target.value)} step="1e-5" />
              </div>
              <div>
                <label className="text-[10px] text-[var(--text-secondary)]">k (conductivity) [W/(m·K)]</label>
                <input type="number" className="input-neon mt-0.5" value={params.k}
                  onChange={e => updateParam('k', e.target.value)} step="1" />
              </div>
              <div>
                <label className="text-[10px] text-[var(--text-secondary)]">q (heat gen.) [W/m³]</label>
                <input type="number" className="input-neon mt-0.5" value={params.q}
                  onChange={e => updateParam('q', e.target.value)} step="1000" />
              </div>
              <div>
                <label className="text-[10px] text-[var(--text-secondary)]">T(0) left BC [°C]</label>
                <input type="number" className="input-neon mt-0.5" value={params.T_left}
                  onChange={e => updateParam('T_left', e.target.value)} />
              </div>
              <div>
                <label className="text-[10px] text-[var(--text-secondary)]">T(L) right BC [°C]</label>
                <input type="number" className="input-neon mt-0.5" value={params.T_right}
                  onChange={e => updateParam('T_right', e.target.value)} />
              </div>
            </div>
          </GlassCard>

          <GlassCard className="p-4 mb-4">
            <div className="section-label mb-3">Mesh Sizes</div>
            <div className="flex flex-wrap gap-1.5">
              {[10, 20, 40, 80, 160].map(n => (
                <label key={n} className="flex items-center gap-1 text-xs cursor-pointer px-2 py-1 rounded bg-black/20 hover:bg-black/40 transition-colors">
                  <input
                    type="checkbox"
                    checked={meshSizes.includes(n)}
                    onChange={e => {
                      if (e.target.checked) setMeshSizes([...meshSizes, n].sort((a, b) => a - b));
                      else setMeshSizes(meshSizes.filter(m => m !== n));
                    }}
                    className="rounded"
                  />
                  N={n}
                </label>
              ))}
            </div>
          </GlassCard>

          {/* Theory */}
          <GlassCard className="p-4">
            <div className="section-label mb-2 flex items-center gap-1">
              <Info size={12} /> Theory
            </div>
            <div className="text-[10px] text-[var(--text-secondary)] space-y-1.5">
              <p><strong className="text-[var(--text-primary)]">Governing:</strong> -d/dx(kA·dT/dx) = qA</p>
              <p><strong className="text-[var(--text-primary)]">Elements:</strong> 2-node linear</p>
              <p><strong className="text-[var(--text-primary)]">K<sub>e</sub> = (kA/h)·[[1,-1],[-1,1]]</strong></p>
              <p><strong className="text-[var(--text-primary)]">f<sub>e</sub> = (qAh/2)·[1,1]ᵀ</strong></p>
              <p><strong className="text-[var(--text-primary)]">BCs:</strong> Dirichlet (penalty method)</p>
              <p><strong className="text-[var(--text-primary)]">Solver:</strong> Thomas algorithm (O(n))</p>
              <p className="pt-1 border-t border-[var(--border)]">
                <strong className="text-[var(--text-primary)]">Analytical:</strong><br/>
                T(x) = T₀ + (T_L-T₀)x/L + q·x(L-x)/(2k)
              </p>
            </div>
          </GlassCard>
        </div>

        {/* Results */}
        <div className="col-span-9">
          {!results ? (
            <GlassCard className="p-8 flex items-center justify-center h-96">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-orange-500/20 to-red-500/20 border border-orange-500/30 flex items-center justify-center float">
                  <Flame size={28} className="neon-text-amber" />
                </div>
                <p className="text-sm text-[var(--text-primary)] mb-1">Configure parameters and click "Run Solver"</p>
                <p className="text-xs text-[var(--text-muted)]">Default parameters are pre-loaded</p>
              </div>
            </GlassCard>
          ) : (
            <>
              {/* Temperature Profile Chart */}
              <GlassCard className="p-5 mb-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="section-label">Temperature Distribution T(x)</div>
                  <div className="flex gap-2">
                    {results.map((r, i) => (
                      <button
                        key={r.N}
                        onClick={() => setSelectedMesh(r.N)}
                        className={`text-xs px-2 py-0.5 rounded ${
                          selectedMesh === r.N ? 'bg-[var(--accent)] text-white' : 'bg-[var(--bg-tertiary)] text-[var(--text-secondary)]'
                        }`}
                      >
                        N={r.N}
                      </button>
                    ))}
                  </div>
                </div>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={profileData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="x" label={{ value: 'x [m]', position: 'bottom', offset: -5, style: { fill: '#94a3b8', fontSize: 11 } }} stroke="#94a3b8" />
                    <YAxis label={{ value: 'T [°C]', angle: -90, position: 'insideLeft', style: { fill: '#94a3b8', fontSize: 11 } }} stroke="#94a3b8" />
                    <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #475569', borderRadius: 6, fontSize: 11 }} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    {results.map((r, i) => (
                      <Line key={r.N} dataKey={`N=${r.N}`} stroke={colors[i % colors.length]}
                        dot={r.N <= 20} strokeWidth={r.N === selectedMesh ? 2 : 1}
                        strokeOpacity={r.N === selectedMesh ? 1 : 0.5} />
                    ))}
                    <Line dataKey="Exact" stroke="#ffffff" strokeWidth={2} strokeDasharray="5 5" dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </GlassCard>

              {/* Convergence Chart */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <GlassCard className="p-4">
                  <div className="section-label mb-3">Mesh Convergence</div>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={convergenceData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis dataKey="N" label={{ value: 'N elements', position: 'bottom', offset: -5, style: { fill: '#94a3b8', fontSize: 10 } }} stroke="#94a3b8" />
                      <YAxis label={{ value: 'Max Error [°C]', angle: -90, position: 'insideLeft', style: { fill: '#94a3b8', fontSize: 10 } }} stroke="#94a3b8" tickFormatter={v => v.toExponential(0)} />
                      <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #475569', borderRadius: 6, fontSize: 11 }}
                        formatter={(v: number) => v.toExponential(4)} />
                      <Bar dataKey="maxError" fill="#3b82f6" radius={[2, 2, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </GlassCard>

                <GlassCard className="p-4">
                  <div className="section-label mb-3">Convergence Rate (log-log)</div>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={convergenceData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis dataKey="logH" label={{ value: 'log₁₀(h)', position: 'bottom', offset: -5, style: { fill: '#94a3b8', fontSize: 10 } }} stroke="#94a3b8" />
                      <YAxis dataKey="logError" label={{ value: 'log₁₀(error)', angle: -90, position: 'insideLeft', style: { fill: '#94a3b8', fontSize: 10 } }} stroke="#94a3b8" />
                      <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #475569', borderRadius: 6, fontSize: 11 }} />
                      <Line dataKey="logError" stroke="#10b981" dot={{ fill: '#10b981' }} />
                    </LineChart>
                  </ResponsiveContainer>
                </GlassCard>
              </div>

              {/* Results Table */}
              <GlassCard className="p-5">
                <div className="section-label mb-3">
                  Nodal Results (N={selectedMesh}, h={currentResult?.h.toFixed(4)} m)
                </div>
                <div className="table-container max-h-64 overflow-y-auto">
                  <table>
                    <thead>
                      <tr>
                        <th>Node</th>
                        <th>x [m]</th>
                        <th>T_FE [°C]</th>
                        <th>T_exact [°C]</th>
                        <th>|Error| [°C]</th>
                      </tr>
                    </thead>
                    <tbody>
                      {nodeData.map(row => (
                        <tr key={row.node}>
                          <td>{row.node}</td>
                          <td>{row.x}</td>
                          <td>{row.T_FE}</td>
                          <td>{row.T_exact}</td>
                          <td className="text-[var(--warning)]">{row.error}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Summary */}
                <div className="mt-3 grid grid-cols-4 gap-3">
                  {results.map((r, i) => (
                    <div key={r.N} className="p-2 bg-[var(--bg-primary)] rounded text-center">
                      <div className="text-[10px] text-[var(--text-secondary)]">N={r.N}</div>
                      <div className="text-xs font-bold" style={{ color: colors[i] }}>
                        {r.maxError.toExponential(2)} °C
                      </div>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
