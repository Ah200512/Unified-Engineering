import { useState } from 'react';
import {
  LayoutDashboard, Box, Thermometer, Cpu, CircuitBoard,
  Brain, Settings, Zap, Activity, Wifi
} from 'lucide-react';
import { StatusLight } from './components/UI';
import Dashboard from './pages/Dashboard';
import GeometryViewer from './pages/GeometryViewer';
import ThermalAnalysis from './pages/ThermalAnalysis';
import PerformanceBenchmark from './pages/PerformanceBenchmark';
import HardwareIntegration from './pages/HardwareIntegration';
import NeuralNetwork from './pages/NeuralNetwork';
import SettingsPage from './pages/Settings';

type Page = 'dashboard' | 'geometry' | 'thermal' | 'performance' | 'hardware' | 'neural' | 'settings';

const navItems: { id: Page; label: string; shortLabel: string; icon: React.ReactNode; color: string }[] = [
  { id: 'dashboard', label: 'Command Center', shortLabel: 'HQ', icon: <LayoutDashboard size={18} />, color: '#3b82f6' },
  { id: 'geometry', label: 'Geometry Lab', shortLabel: '3D', icon: <Box size={18} />, color: '#06b6d4' },
  { id: 'thermal', label: 'Thermal FEA', shortLabel: 'FEA', icon: <Thermometer size={18} />, color: '#ef4444' },
  { id: 'performance', label: 'Benchmark', shortLabel: 'CPU', icon: <Cpu size={18} />, color: '#10b981' },
  { id: 'hardware', label: 'Hardware Sim', shortLabel: 'HW', icon: <CircuitBoard size={18} />, color: '#f59e0b' },
  { id: 'neural', label: 'Neural Net', shortLabel: 'AI', icon: <Brain size={18} />, color: '#a855f7' },
  { id: 'settings', label: 'Settings', shortLabel: 'SET', icon: <Settings size={18} />, color: '#64748b' },
];

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [collapsed, setCollapsed] = useState(false);

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard': return <Dashboard onNavigate={setCurrentPage} />;
      case 'geometry': return <GeometryViewer />;
      case 'thermal': return <ThermalAnalysis />;
      case 'performance': return <PerformanceBenchmark />;
      case 'hardware': return <HardwareIntegration />;
      case 'neural': return <NeuralNetwork />;
      case 'settings': return <SettingsPage />;
      default: return <Dashboard onNavigate={setCurrentPage} />;
    }
  };

  const currentModule = navItems.find(n => n.id === currentPage);

  return (
    <>
      {/* Sidebar */}
      <aside className={`sidebar ${collapsed ? 'w-20' : 'w-64'}`}>
        {/* Logo */}
        <div className="p-4 border-b border-[var(--border)]">
          <div className="flex items-center gap-3">
            <div className="relative w-10 h-10 flex items-center justify-center flex-shrink-0">
              <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 opacity-80 spin-slow" />
              <div className="relative w-8 h-8 rounded-lg bg-[var(--bg-void)] flex items-center justify-center">
                <Zap size={16} className="neon-text-cyan" />
              </div>
            </div>
            {!collapsed && (
              <div className="fade-in-up">
                <div className="text-xs font-bold gradient-text tracking-wider">WORKBENCH</div>
                <div className="text-[9px] text-[var(--text-muted)] tracking-widest">PASS R&D 2026</div>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-3 overflow-y-auto">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setCurrentPage(item.id)}
              className={`nav-item w-[calc(100%-1rem)] ${currentPage === item.id ? 'active' : ''}`}
              style={{ ['--accent' as any]: item.color }}
            >
              <div className="icon-wrap" style={{
                background: currentPage === item.id ? `linear-gradient(135deg, ${item.color}, ${item.color}aa)` : undefined,
                boxShadow: currentPage === item.id ? `0 4px 12px ${item.color}40` : undefined,
              }}>
                {item.icon}
              </div>
              {!collapsed && (
                <div className="flex-1 text-left">
                  <div className="text-sm">{item.label}</div>
                </div>
              )}
            </button>
          ))}
        </nav>

        {/* Collapse toggle */}
        <div className="p-3 border-t border-[var(--border)]">
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="btn-ghost w-full flex items-center justify-center gap-2"
          >
            <div className={`transition-transform ${collapsed ? 'rotate-180' : ''}`}>◂</div>
            {!collapsed && <span className="text-xs">Collapse</span>}
          </button>
        </div>
      </aside>

      {/* Main area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Topbar */}
        <div className="topbar">
          <div className="flex items-center gap-3 flex-1">
            <div
              className="w-2 h-2 rounded-full"
              style={{ background: currentModule?.color, boxShadow: `0 0 10px ${currentModule?.color}` }}
            />
            <div>
              <div className="text-sm font-bold tracking-wide">{currentModule?.label}</div>
              <div className="text-[10px] text-[var(--text-muted)] uppercase tracking-widest">
                Module {navItems.findIndex(n => n.id === currentPage) === 0 ? 'A' : String.fromCharCode(65 + navItems.findIndex(n => n.id === currentPage))}
              </div>
            </div>
          </div>

          {/* Live status indicators */}
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-4 px-3 py-1.5 rounded-lg bg-black/30 border border-[var(--border)]">
              <StatusLight status="online" label="C++17" />
              <div className="w-px h-4 bg-[var(--border)]" />
              <StatusLight status="online" label="FEA" />
              <div className="w-px h-4 bg-[var(--border)]" />
              <StatusLight status="online" label="Threads" />
            </div>
            <div className="flex items-center gap-2 text-xs text-[var(--text-muted)]">
              <Activity size={12} className="neon-text-green" />
              <span className="font-mono">v1.0.0</span>
            </div>
          </div>
        </div>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto relative">
          {renderPage()}
        </main>
      </div>
    </>
  );
}
