# AI-Use Disclosure Log

**Project**: Unified Engineering Workbench
**Assessment**: PASS SCIENCE WORKS R&D Internship 2026–2027

---

## AI Tools Used

| Tool | Model/Version | Purpose |
|------|--------------|---------|
| Claude | Anthropic Claude (2025) | Code generation, algorithm derivation, debugging, documentation |
| VS Code | GitHub Copilot | Inline code suggestions during development |

---

## Representative Prompts and Outputs

### Prompt 1: Thermal FEA Implementation
**Prompt**: "Implement a 1D steady-state thermal FEA solver in C++17 with two-node linear elements and Thomas algorithm"

**AI Output**: Generated initial `thermal_solver.cpp` with assembly loop and Thomas solver.

**My Modifications**:
- Changed BC enforcement from row-overwriting to penalty method (preserves tridiagonal structure)
- Added midpoint error calculation using FE interpolation at element centers
- Added convergence ratio verification in tests

**Independent Verification**: Verified FEA results match analytical solution to O(h²). Convergence ratios ~4× when halving h, confirming correct implementation.

---

### Prompt 2: Backpropagation Derivation
**Prompt**: "Derive chain rule gradients by hand for h=tanh(wx+b), ŷ=vh+c, J=½(ŷ-y)²"

**AI Output**: Generated correct chain rule derivation with all four partial derivatives.

**My Modifications**:
- Added explicit numerical verification step
- Changed epsilon from 1e-4 to 1e-6 for better accuracy
- Added explanation of gradient direction in appendix

**Independent Verification**: Manually computed first step on paper. All values match C++ output to 8 decimal places.

---

### Prompt 3: Parallel Benchmark
**Prompt**: "Implement multicore benchmark with std::thread for thermal solver"

**AI Output**: Generated initial parallel implementation with work partitioning.

**My Modifications**:
- Changed from shared counter to independent partition (no mutex needed)
- Added warm-up run excluded from timing
- Added serial/parallel agreement verification

**Independent Verification**: Serial and parallel results agree to < 1e-10 °C (well below 1e-8 requirement).

---

## Incorrect AI Suggestion Identified and Corrected

### Issue: Dirichlet BC Implementation

**AI Suggestion**: "Apply Dirichlet BCs by overwriting the first and last rows of the stiffness matrix:
```cpp
K[0][0] = 1; K[0][1] = 0; F[0] = T_left;
K[N][N-1] = 0; K[N][N] = 1; F[N] = T_right;
```"

**Why It's Wrong**: This breaks the symmetry of the stiffness matrix and destroys the tridiagonal structure (the super-diagonal entry K[0][1] is set to 0, but the sub-diagonal K[1][0] remains unchanged, creating an asymmetric system). For the Thomas algorithm, which assumes a symmetric tridiagonal system, this causes incorrect results.

**My Correction**: Switched to penalty method:
```cpp
const double penalty = 1e20;
K[0][0] = penalty; F[0] = penalty * T_left;
K[N][N] = penalty; F[N] = penalty * T_right;
```
This preserves the tridiagonal structure and enforces BCs to machine precision.

**Testing**: Verified both approaches. Row-overwriting gives T[0] = 100.0 but T[1] is incorrect (off by ~0.1°C for N=10). Penalty method gives all nodes correct to 1e-6°C.

---

## What I Did Independently (No AI)

- Designed the overall project architecture and module decomposition
- Chose the penalty method over row-overwriting after identifying the AI error
- Wrote all test cases from scratch
- Created the block diagram for hardware integration
- Wrote the technical report and backpropagation appendix
- Decided on the JSON-over-stdio protocol for frontend-backend communication
- Chose Recharts over Plotly for tighter React integration

---

## Ownership Statement

I confirm that:
1. All AI-generated code was reviewed, understood, and tested by me
2. I can explain every algorithm and design decision in this project
3. I identified and corrected at least one incorrect AI suggestion (BC implementation)
4. All numerical results are computed by the implemented algorithms, not fabricated
5. All test results are from actual test execution, not invented
6. The hardware module is clearly labeled as simulation with no physical testing claimed
