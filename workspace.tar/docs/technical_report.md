# Technical Report — Unified Engineering Workbench

**PASS SCIENCE WORKS R&D Internship 2026–2027**
**Candidate Assessment — 15-Day Assignment**

---

## 1. Introduction

This report documents the design, implementation, and verification of the Unified Engineering Workbench — a modular engineering application combining geometry visualization, thermal finite element analysis, multicore benchmarking, embedded hardware simulation, and neural network training.

The project satisfies the PASS SCIENCE WORKS R&D Internship assessment requirements across six modules (A–F), with all numerical computation implemented in **C++17** and the user interface delivered as a React/Vite web application.

## 2. Architecture

### 2.1 System Overview

The application uses a client-server architecture where the React frontend communicates with a C++17 backend via a JSON-over-stdin/stdout protocol. The frontend handles visualization (Three.js for 3D, Recharts for plots) while the backend performs all numerical computation.

```
┌─────────────────┐     JSON/stdio     ┌──────────────────┐
│  React Frontend │ ◄────────────────► │  C++17 Backend   │
│  (Vite + TS)    │                    │  (std::thread)   │
│  Three.js       │                    │  Eigen-free      │
│  Recharts       │                    │  Thomas solver   │
└─────────────────┘                    └──────────────────┘
```

### 2.2 Design Decisions

- **No external C++ dependencies**: The FEA solver uses a hand-written Thomas algorithm rather than requiring Eigen or similar, ensuring portability.
- **Penalty method for BCs**: Dirichlet boundary conditions are enforced via penalty method (K_ii = 10²⁰, F_i = 10²⁰ × T_prescribed) to preserve the tridiagonal structure.
- **Deterministic parallelism**: Each worker thread operates on an independent partition of test cases with no shared mutable state, ensuring reproducibility.

## 3. Module Implementations

### 3.1 Module B — Geometry Visualization

**STL Parser**: Reads ASCII STL line-by-line, extracting facet normals and vertex coordinates. Validates all values are finite. Bounds are computed during parsing. Maximum file size: 50 MB.

**CSV Parser**: Reads header row to map column names to indices. Validates required schema (`node_id,x_m,y_m,z_m,temperature_C`). Rejects non-finite values with warnings. Empty files and missing columns produce clear error messages.

**Visualization**: Three.js renders STL as a triangle mesh with Phong shading and wireframe overlay. CSV data renders as a colored point cloud with temperature mapped to a blue→red gradient.

### 3.2 Module C — Thermal FEA

**Governing equation**: `-d/dx(kA dT/dx) = qA`

**Element matrices** (2-node linear, length h):
- Stiffness: `K_e = (kA/h) [[1,-1],[-1,1]]`
- Load: `f_e = (qAh/2) [1, 1]ᵀ`

**Assembly**: Standard scatter operation into global tridiagonal system.

**Solver**: Thomas algorithm — O(n) forward elimination + back substitution.

**Boundary conditions**: Penalty method with penalty = 10²⁰. This preserves tridiagonal structure (no fill-in) and achieves BC enforcement to machine precision.

**Analytical solution**: `T(x) = T₀ + (T_L - T₀)x/L + q·x(L-x)/(2k)`

**Midpoint error**: At element midpoint x_mid = (e+0.5)h, FE interpolation gives T_mid = 0.5(T_e + T_{e+1}). Error = |T_mid - T_exact(x_mid)|.

**Convergence**: Linear elements yield O(h²) convergence. Verified: halving h reduces error by ~4×.

### 3.3 Module D — Performance Benchmark

**Implementation**: Uses `std::thread` for actual CPU-level parallelism. Each worker thread solves an independent partition of test cases.

**Test case generation**: Seeded PRNG (seed=42) generates k ∈ [1, 51] W/(m·K) and q ∈ [1000, 51000] W/m³.

**Timing**: `std::chrono::high_resolution_clock`. Warm-up run excluded. 5 repetitions per configuration, median reported.

**Metrics**:
- Speedup = T₁ / Tₚ
- Efficiency = Speedup / p

**Verification**: Serial and parallel results compared element-wise. Maximum absolute difference must be < 10⁻⁸ °C.

**Limitations**: Speedup is bounded by Amdahl's law. For small problems, thread creation overhead may dominate. True scaling requires sufficiently large workloads.

### 3.4 Module E — Hardware Integration

**Simulated adapters** for three device types:
1. **MCU** (STM32F407): ARM Cortex-M4, 168 MHz, 3.3V domain
2. **FPGA** (Artix-7): 100K logic cells, 1.0V core / 3.3V I/O
3. **JTAG** (SEGGER J-Link): Debug interface with SWD/JTAG protocols

**Important**: All behavior is simulated. No physical hardware is accessed. The JTAG adapter is correctly classified as a debug interface, not a compute board.

**Block diagram** shows voltage domains, level shifting requirements, and signal ownership for JTAG pins (TCK/TMS/TDI/TDO are adapter-owned; TRST is optional).

### 3.5 Module F — Backpropagation

**Network**: `h = tanh(wx + b)`, `ŷ = vh + c`, `J = ½(ŷ - y)²`

**Hand-derived gradients**:
```
δ_out = ŷ - y
∂J/∂v = δ_out · h
∂J/∂c = δ_out
δ_hid = δ_out · v · (1 - h²)
∂J/∂w = δ_hid · x
∂J/∂b = δ_hid
```

**Verification**: Central finite differences with ε = 10⁻⁶. All four gradients must satisfy |analytical - numerical| ≤ 10⁻⁵.

**Training**: 100 steps with η = 0.1, simultaneous parameter update.

## 4. Testing Strategy

Five test suites with 26 total test cases:

| Suite | Tests | Coverage |
|-------|-------|----------|
| test_thermal | 7 | BCs, convergence, midpoint error, CSV export, invalid params |
| test_backprop | 6 | Forward pass, loss, gradient verification, training, simultaneous update |
| test_parsers | 8 | Valid/invalid STL, valid/invalid CSV, empty files, non-finite values |
| test_hardware | 5 | Discovery, connect/disconnect, telemetry, JTAG classification |
| test_benchmark | 6 | Determinism, positivity, serial/parallel, agreement < 1e-8 |

All tests pass. No external test framework required.

## 5. Packaging & Distribution

The final submission ZIP (`CandidateID_Workbench.zip`) contains:
- `Launch.exe` — Standalone launcher (no terminal/admin/install required)
- `dist/` — Packaged frontend (Vite production build)
- `bin/` — Compiled C++ backend
- `src/` — Complete source code
- `CMakeLists.txt` — Build configuration
- `docs/` — Technical report, backprop appendix, AI-use log
- `data/` — Sample input files with provenance
- `results/` — Test outputs and labelled plots
- `.vscode/` — VS Code run configuration
- `README.md` — Setup and usage instructions

## 6. Conclusions

All six modules are implemented, tested, and verified. The C++17 backend handles all numerical computation with actual `std::thread` parallelism. The frontend provides professional visualization and interaction. The project is fully reproducible from source.
